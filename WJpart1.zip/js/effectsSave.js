function varC1() {
	valueSaveSS0 = "valueSaveSS0";
	var valuewjA = document.getElementById("menu0").value;
	localStorage.setItem(valueSaveSS0, valuewjA);
 };
function varC2() {
	valueSaveSS1 = "valueSaveSS1";
	var valuewjB = document.getElementById("menu1").value;
	localStorage.setItem(valueSaveSS1, valuewjB);
};
function varC3() {
	valueSaveSS2 = "valueSaveSS2";
	var valuewjC = document.getElementById("menu2").value;
	localStorage.setItem(valueSaveSS2, valuewjC);
};
function varC4() {
	valueSaveSS3 = "valueSaveSS3";
	var valuewjD = document.getElementById("menu3").value;
	localStorage.setItem(valueSaveSS3, valuewjD);
};
function varC5() {
	valueSaveSS4 = "valueSaveSS4";
	var valuewjE = document.getElementById("menu4").value;
	localStorage.setItem(valueSaveSS4, valuewjE);
	};
function varC6() {
	valueSaveSS5 = "valueSaveSS5";
	var valuewjF = document.getElementById("menu5").value;
	localStorage.setItem(valueSaveSS5, valuewjF);
	};
function varC7() {
	valueSaveSS6 = "valueSaveSS6";
	var valuewjG = document.getElementById("menu12").value;
	localStorage.setItem(valueSaveSS6, valuewjG);
	};
function varC8() {
	valueSaveSS7 = "valueSaveSS7";
	var valuewjH = document.getElementById("menu13").value;
	localStorage.setItem(valueSaveSS7, valuewjH);
	};
function varC9() {
	valueSaveSS8 = "valueSaveSS8";
	var valuewjI = document.getElementById("menu7").value;
	localStorage.setItem(valueSaveSS8, valuewjI);
	};
function varC10() {
	valueSaveSS9 = "valueSaveSS9";
	var valuewjJ = document.getElementById("menu8").value;
	localStorage.setItem(valueSaveSS9, valuewjJ);
	};
function varC11() {
	valueSaveSS10 = "valueSaveSS10";
	var valuewjK = document.getElementById("menu9").value;
	localStorage.setItem(valueSaveSS10, valuewjK);
	};
function varC12() {
	valueSaveSS11 = "valueSaveSS11";
	var valuewjL = document.getElementById("menu10").value;
	localStorage.setItem(valueSaveSS11, valuewjL);
	};
function varC13() {
	valueSaveSS12 = "valueSaveSS12";
	var valuewjM = document.getElementById("menu11").value;
	localStorage.setItem(valueSaveSS12, valuewjM);
	};
function varC14() {
	valueSaveSS13 = "valueSaveSS13";
	var valuewjN = document.getElementById("menuB1").value;
	localStorage.setItem(valueSaveSS13, valuewjN);
	};
function varC15() {
	valueSaveSS14 = "valueSaveSS14";
	var valuewjO = document.getElementById("menu6").value;
	localStorage.setItem(valueSaveSS14, valuewjO);
	};
function varC16() {
    valueSaveSS15 = "valueSaveSS15";
	var valuewjA1 = document.getElementById("Background_Color2-R").value;
	localStorage.setItem(valueSaveSS15, valuewjA1);
	};
function varC17() {
	valueSaveSS16 = "valueSaveSS16";
	var valuewjB1 = document.getElementById("Background_Color2-G").value;
	localStorage.setItem(valueSaveSS16, valuewjB1);
	};
function varC18() {
	valueSaveSS17 = "valueSaveSS17";
	var valuewjC1 = document.getElementById("Background_Color2-B").value;
	localStorage.setItem(valueSaveSS17, valuewjC1);
	};
function varC19() {
	valueSaveSS18 = "valueSaveSS18";
	var valuewjD1 = document.getElementById("Font_Color-R").value;
	localStorage.setItem(valueSaveSS18, valuewjD1);
	};
function varC20() {
	valueSaveSS19 = "valueSaveSS19";
	var valuewjE1 = document.getElementById("Font_Color-G").value;
	localStorage.setItem(valueSaveSS19, valuewjE1);
	};
function varC21() {
	valueSaveSS20 = "valueSaveSS20";
	var valuewjF1 = document.getElementById("Font_Color-B").value;
	localStorage.setItem(valueSaveSS20, valuewjF1);
	};
	
function varC22() {
    valueSaveSS21 = "valueSaveSS21";
	var valuewjA1 = document.getElementById("Background_Color3-R").value;
	localStorage.setItem(valueSaveSS21, valuewjA1);
	};
function varC23() {
	valueSaveSS22 = "valueSaveSS22";
	var valuewjB1 = document.getElementById("Background_Color3-G").value;
	localStorage.setItem(valueSaveSS22, valuewjB1);
	};
function varC24() {
	valueSaveSS23 = "valueSaveSS23";
	var valuewjC1 = document.getElementById("Background_Color3-B").value;
	localStorage.setItem(valueSaveSS23, valuewjC1);
	};
function varC25() {
	valueSaveSS24 = "valueSaveSS24";
	var valuewjD1 = document.getElementById("Font_Color_1-R").value;
	localStorage.setItem(valueSaveSS24, valuewjD1);
	};
function varC26() {
	valueSaveSS25 = "valueSaveSS25";
	var valuewjE1 = document.getElementById("Font_Color_1-G").value;
	localStorage.setItem(valueSaveSS25, valuewjE1);
	};
function varC27() {
	valueSaveSS26 = "valueSaveSS26";
	var valuewjF1 = document.getElementById("Font_Color_1-B").value;
	localStorage.setItem(valueSaveSS26, valuewjF1);
	};
	
function varC28() {
    valueSaveSS27 = "valueSaveSS27";
	var valuewjA1 = document.getElementById("Font_Color_2-R").value;
	localStorage.setItem(valueSaveSS27, valuewjA1);
	};
function varC29() {
	valueSaveSS28 = "valueSaveSS28";
	var valuewjB1 = document.getElementById("Font_Color_2-G").value;
	localStorage.setItem(valueSaveSS28, valuewjB1);
	};
function varC30() {
	valueSaveSS29 = "valueSaveSS29";
	var valuewjC1 = document.getElementById("Font_Color_2-B").value;
	localStorage.setItem(valueSaveSS29, valuewjC1);
	};
function varC31() {
	valueSaveSS30 = "valueSaveSS30";
	var valuewjD1 = document.getElementById("Border_Color-R").value;
	localStorage.setItem(valueSaveSS30, valuewjD1);
	};
function varC32() {
	valueSaveSS31 = "valueSaveSS31";
	var valuewjE1 = document.getElementById("Border_Color-G").value;
	localStorage.setItem(valueSaveSS31, valuewjE1);
	};
function varC33() {
	valueSaveSS32 = "valueSaveSS32";
	var valuewjF1 = document.getElementById("Border_Color-B").value;
	localStorage.setItem(valueSaveSS32, valuewjF1);
	};
	
function varC34() {
    valueSaveSS33 = "valueSaveSS33";
	var valuewjA1 = document.getElementById("Box_Color-R").value;
	localStorage.setItem(valueSaveSS33, valuewjA1);
	};
function varC35() {
	valueSaveSS34 = "valueSaveSS34";
	var valuewjB1 = document.getElementById("Box_Color-G").value;
	localStorage.setItem(valueSaveSS34, valuewjB1);
	};
function varC36() {
	valueSaveSS35 = "valueSaveSS35";
	var valuewjC1 = document.getElementById("Box_Color-B").value;
	localStorage.setItem(valueSaveSS35, valuewjC1);
	};
	
function varC37() {
	valueSaveSS36 = "valueSaveSS36";
	var valuewjF1 = document.getElementById("menuB").value;
	localStorage.setItem(valueSaveSS36, valuewjF1);
	};
function varC38() {
    valueSaveSS37 = "valueSaveSS37";
	var valuewjA1 = document.getElementById("menuB2").value;
	localStorage.setItem(valueSaveSS37, valuewjA1);
	};
function varC39() {
	valueSaveSS38 = "valueSaveSS38";
	var valuewjB1 = document.getElementById("menuB3").value;
	localStorage.setItem(valueSaveSS38, valuewjB1);
	};
function varC40() {
	valueSaveSS39 = "valueSaveSS39";
	var valuewjC1 = document.getElementById("menuB4").value;
	localStorage.setItem(valueSaveSS39, valuewjC1);
	};

function varD1() {
	valuewjA = "valueSaveSS0";
	var tripleZeroZ1 = localStorage.getItem(valuewjA);
	
	document.getElementById("menu0").value = tripleZeroZ1;
	};
function varD2() {
	
    valuewjB = "valueSaveSS1";
	var tripleZeroZ2 = localStorage.getItem(valuewjB);
	
	document.getElementById("menu1").value = tripleZeroZ2;
	};
function varD3() {
	
    valuewjC = "valueSaveSS2";
	var tripleZeroZ3 = localStorage.getItem(valuewjC);
	
	document.getElementById("menu2").value = tripleZeroZ3;
	};
function varD4() {
	
    valuewjD = "valueSaveSS3";
	var tripleZeroZ4 = localStorage.getItem(valuewjD);
	
	document.getElementById("menu3").value = tripleZeroZ4;
	};
function varD5() {
	
    valuewjE = "valueSaveSS4";
	var tripleZeroZ5 = localStorage.getItem(valuewjE);
	
	document.getElementById("menu4").value = tripleZeroZ5;
	};
function varD6() {
	
    valuewjF = "valueSaveSS5";
	var tripleZeroZ6 = localStorage.getItem(valuewjF);
	
	document.getElementById("menu5").value = tripleZeroZ6;
	};
function varD7() {
	
    valuewjG = "valueSaveSS6";
	var tripleZeroZ7 = localStorage.getItem(valuewjG);
	
	document.getElementById("menu12").value = tripleZeroZ7;
	};
function varD8() {
	
    valuewjH = "valueSaveSS7";
	var tripleZeroZ8 = localStorage.getItem(valuewjH);
	
	document.getElementById("menu13").value = tripleZeroZ8;
	};
function varD9() {
	
    valuewjI = "valueSaveSS8";
	var tripleZeroZ9 = localStorage.getItem(valuewjI);
	
	document.getElementById("menu7").value = tripleZeroZ9;
	};
function varD10() {
	
    valuewjJ = "valueSaveSS9";
	var tripleZeroZ10 = localStorage.getItem(valuewjJ);
	
	document.getElementById("menu8").value = tripleZeroZ10;
	};
function varD11() {
	
    valuewjK = "valueSaveSS10";
	var tripleZeroZ11 = localStorage.getItem(valuewjK);
	
	document.getElementById("menu9").value = tripleZeroZ11;
	};
function varD12() {
	
    valuewjL = "valueSaveSS11";
	var tripleZeroZ12 = localStorage.getItem(valuewjL);
	
	document.getElementById("menu10").value = tripleZeroZ12;
	};
function varD13() {
	
    valuewjM = "valueSaveSS12";
	var tripleZeroZ13 = localStorage.getItem(valuewjM);
	
	document.getElementById("menu11").value = tripleZeroZ13;
	};
function varD14() {
	
    valuewjN = "valueSaveSS13";
	var tripleZeroZ14 = localStorage.getItem(valuewjN);
	
	document.getElementById("menuB1").value = tripleZeroZ14;
	};
function varD15() {
	
    valuewjO = "valueSaveSS14";
	var tripleZeroZ15 = localStorage.getItem(valuewjO);
	
	document.getElementById("menu6").value = tripleZeroZ15;
	};
function varD16() {
	
    valuewjA1 = "valueSaveSS15";
	var tripleZeroZ16 = localStorage.getItem(valuewjA1);
	
	document.getElementById("Background_Color2-R").value = tripleZeroZ16;
	};
function varD17() {
	
    valuewjB1 = "valueSaveSS16";
	var tripleZeroZ17 = localStorage.getItem(valuewjB1);
	
	document.getElementById("Background_Color2-G").value = tripleZeroZ17;
	document.getElementById("Background_Color2-G")
	};
function varD18() {
	
    valuewjC1 = "valueSaveSS17";
	var tripleZeroZ18 = localStorage.getItem(valuewjC1);
	
	document.getElementById("Background_Color2-B").value = tripleZeroZ18;
	document.getElementById("Background_Color2-B")
    
	};
function varD19() {
	
    valuewjD1 = "valueSaveSS18";
	var tripleZeroZ19 = localStorage.getItem(valuewjD1);
	
	document.getElementById("Font_Color-R").value = tripleZeroZ19;
	};
function varD20() {
	
    valuewjE1 = "valueSaveSS19";
	var tripleZeroZ20 = localStorage.getItem(valuewjE1);
	
	document.getElementById("Font_Color-G").value = tripleZeroZ20;
	};
function varD21() {
	
    valuewjF1 = "valueSaveSS20";
	var tripleZeroZ21 = localStorage.getItem(valuewjF1);
	
	document.getElementById("Font_Color-B").value = tripleZeroZ21;
	};
function varD22() {
	
    valuewjB = "valueSaveSS21";
	var tripleZeroZ2 = localStorage.getItem(valuewjB);
	
	document.getElementById("Background_Color3-R").value = tripleZeroZ2;
	};
function varD23() {
	
    valuewjC = "valueSaveSS22";
	var tripleZeroZ3 = localStorage.getItem(valuewjC);
	
	document.getElementById("Background_Color3-G").value = tripleZeroZ3;
	};
function varD24() {
	
    valuewjD = "valueSaveSS23";
	var tripleZeroZ4 = localStorage.getItem(valuewjD);
	
	document.getElementById("Background_Color3-B").value = tripleZeroZ4;
	};
function varD25() {
	
    valuewjE = "valueSaveSS24";
	var tripleZeroZ5 = localStorage.getItem(valuewjE);
	
	document.getElementById("Font_Color_1-R").value = tripleZeroZ5;
	};
function varD26() {
	
    valuewjF = "valueSaveSS25";
	var tripleZeroZ6 = localStorage.getItem(valuewjF);
	
	document.getElementById("Font_Color_1-G").value = tripleZeroZ6;
	};
function varD27() {
	
    valuewjG = "valueSaveSS26";
	var tripleZeroZ7 = localStorage.getItem(valuewjG);
	
	document.getElementById("Font_Color_1-B").value = tripleZeroZ7;
	};
function varD28() {
	
    valuewjH = "valueSaveSS27";
	var tripleZeroZ8 = localStorage.getItem(valuewjH);
	
	document.getElementById("Font_Color_2-R").value = tripleZeroZ8;
	};
function varD29() {
	
    valuewjI = "valueSaveSS28";
	var tripleZeroZ9 = localStorage.getItem(valuewjI);
	
	document.getElementById("Font_Color_2-G").value = tripleZeroZ9;
	};
function varD30() {
	
    valuewjJ = "valueSaveSS29";
	var tripleZeroZ10 = localStorage.getItem(valuewjJ);
	
	document.getElementById("Font_Color_2-B").value = tripleZeroZ10;
	};
function varD31() {
	
    valuewjK = "valueSaveSS30";
	var tripleZeroZ11 = localStorage.getItem(valuewjK);
	
	document.getElementById("Border_Color-R").value = tripleZeroZ11;
	};
function varD32() {
	
    valuewjL = "valueSaveSS31";
	var tripleZeroZ12 = localStorage.getItem(valuewjL);
	
	document.getElementById("Border_Color-G").value = tripleZeroZ12;
	};
function varD33() {
	
    valuewjM = "valueSaveSS32";
	var tripleZeroZ13 = localStorage.getItem(valuewjM);
	
	document.getElementById("Border_Color-B").value = tripleZeroZ13;
	};
function varD34() {
	
    valuewjN = "valueSaveSS33";
	var tripleZeroZ14 = localStorage.getItem(valuewjN);
	
	document.getElementById("Box_Color-R").value = tripleZeroZ14;
	};
function varD35() {
	
    valuewjO = "valueSaveSS34";
	var tripleZeroZ15 = localStorage.getItem(valuewjO);
	
	document.getElementById("Box_Color-G").value = tripleZeroZ15;
	};
function varD36() {
	
    valuewjA1 = "valueSaveSS35";
	var tripleZeroZ16 = localStorage.getItem(valuewjA1);
	
	document.getElementById("Box_Color-B").value = tripleZeroZ16;
	
	};

function varD37() {
	
    valuewjM = "valueSaveSS36";
	var tripleZeroZ13 = localStorage.getItem(valuewjM);
	
	document.getElementById("menuB").value = tripleZeroZ13;
	};
function varD38() {
	
    valuewjN = "valueSaveSS37";
	var tripleZeroZ14 = localStorage.getItem(valuewjN);
	
	document.getElementById("menuB2").value = tripleZeroZ14;
	};
function varD39() {
	
    valuewjO = "valueSaveSS38";
	var tripleZeroZ15 = localStorage.getItem(valuewjO);
	
	document.getElementById("menuB3").value = tripleZeroZ15;
	};
function varD40() {
	
    valuewjA1 = "valueSaveSS39";
	var tripleZeroZ16 = localStorage.getItem(valuewjA1);
	
	document.getElementById("menuB4").value = tripleZeroZ16;
	
	};
function varA() {
	varC1();
	varC2();
	varC3();
	varC4();
	varC5();
	varC6();
	varC7();
	varC8();
	varC9();
	varC10();
	varC11();
	varC12();
	varC13();
	varC14();
	varC15();
	varC16();
	varC17();
	varC18();
	varC19();
	varC20();
	varC21();
	varC22();
	varC23();
	varC24();
	varC25();
	varC26();
	varC27();
	varC28();
	varC29();
	varC30();
	varC31();
	varC32();
	varC33();
	varC34();
	varC35();
	varC36();
	varC37();
	varC38();
	varC39();
	varC40();
	alert("Effects Saved.");
	
}
function varB() {
	varD1();
	varD2();
	varD3();
	varD4();
	varD5();
	varD6();
	varD7();
	varD8();
	varD9();
	varD10();
	varD11();
	varD12();
	varD13();
	varD14();
	varD15();
	varD16();
	varD17();
	varD18();
	varD19();
	varD20();
	varD21();
	varD22();
	varD23();
	varD24();
	varD25();
	varD26();
	varD27();
	varD28();
	varD29();
	varD30();
	varD31();
	varD32();
	varD33();
	varD34();
	varD35();
	varD36();
	varD37();
	varD38();
	varD39();
	varD40();
	alert("Effects.");
	
}