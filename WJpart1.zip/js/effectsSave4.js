function varC1() {
	valueSaveSS80 = "valueSaveSS80";
	var valuewjA = document.getElementById("blur").value;
	localStorage.setItem(valueSaveSS80, valuewjA);
 };
function varC2() {
	valueSaveSS81 = "valueSaveSS81";
	var valuewjB = document.getElementById("brightness").value;
	localStorage.setItem(valueSaveSS81, valuewjB);
};
function varC3() {
	valueSaveSS82 = "valueSaveSS82";
	var valuewjC = document.getElementById("contrast").value;
	localStorage.setItem(valueSaveSS82, valuewjC);
};
function varC4() {
	valueSaveSS83 = "valueSaveSS83";
	var valuewjD = document.getElementById("grayscale").value;
	localStorage.setItem(valueSaveSS83, valuewjD);
};
function varC5() {
	valueSaveSS84 = "valueSaveSS84";
	var valuewjE = document.getElementById("huerotate").value;
	localStorage.setItem(valueSaveSS84, valuewjE);
	};
function varC6() {
	valueSaveSS85 = "valueSaveSS85";
	var valuewjF = document.getElementById("invert").value;
	localStorage.setItem(valueSaveSS85, valuewjF);
	};
function varC7() {
	valueSaveSS86 = "valueSaveSS86";
	var valuewjG = document.getElementById("opacity").value;
	localStorage.setItem(valueSaveSS86, valuewjG);
	};
function varC8() {
	valueSaveSS87 = "valueSaveSS87";
	var valuewjH = document.getElementById("saturate").value;
	localStorage.setItem(valueSaveSS87, valuewjH);
	};
function varC9() {
	valueSaveSS88 = "valueSaveSS88";
	var valuewjI = document.getElementById("sepia").value;
	localStorage.setItem(valueSaveSS88, valuewjI);
	};
function varC10() {
	valueSaveSS89 = "valueSaveSS89";
	var valuewjJ = document.getElementById("widthNheight").value;
	localStorage.setItem(valueSaveSS89, valuewjJ);
	};
function varC11() {
	valueSaveSS90 = "valueSaveSS90";
	var valuewjK = document.getElementById("Background_Color-R").value;
	localStorage.setItem(valueSaveSS90, valuewjK);
	};
function varC12() {
	valueSaveSS91 = "valueSaveSS91";
	var valuewjL = document.getElementById("Background_Color-G").value;
	localStorage.setItem(valueSaveSS91, valuewjL);
	};
function varC13() {
	valueSaveSS92 = "valueSaveSS92";
	var valuewjM = document.getElementById("Background_Color-B").value;
	localStorage.setItem(valueSaveSS92, valuewjM);
	};
function varC14() {
	valueSaveSS93 = "valueSaveSS93";
	var valuewjN = document.getElementById("Font_Color-R").value;
	localStorage.setItem(valueSaveSS93, valuewjN);
	};
function varC15() {
	valueSaveSS94 = "valueSaveSS94";
	var valuewjO = document.getElementById("Font_Color-G").value;
	localStorage.setItem(valueSaveSS94, valuewjO);
	};
function varC16() {
    valueSaveSS95 = "valueSaveSS95";
	var valuewjA1 = document.getElementById("Font_Color-B").value;
	localStorage.setItem(valueSaveSS95, valuewjA1);
	};
function varD1() {
	valuewjA = "valueSaveSS80";
	var tripleZeroZ1 = localStorage.getItem(valuewjA);
	
	document.getElementById("blur").value = tripleZeroZ1;
	};
function varD2() {
	
    valuewjB = "valueSaveSS81";
	var tripleZeroZ2 = localStorage.getItem(valuewjB);
	
	document.getElementById("brightness").value = tripleZeroZ2;
	};
function varD3() {
	
    valuewjC = "valueSaveSS82";
	var tripleZeroZ3 = localStorage.getItem(valuewjC);
	
	document.getElementById("contrast").value = tripleZeroZ3;
	};
function varD4() {
	
    valuewjD = "valueSaveSS83";
	var tripleZeroZ4 = localStorage.getItem(valuewjD);
	
	document.getElementById("grayscale").value = tripleZeroZ4;
	};
function varD5() {
	
    valuewjE = "valueSaveSS84";
	var tripleZeroZ5 = localStorage.getItem(valuewjE);
	
	document.getElementById("huerotate").value = tripleZeroZ5;
	};
function varD6() {
	
    valuewjF = "valueSaveSS85";
	var tripleZeroZ6 = localStorage.getItem(valuewjF);
	
	document.getElementById("invert").value = tripleZeroZ6;
	};
function varD7() {
	
    valuewjG = "valueSaveSS86";
	var tripleZeroZ7 = localStorage.getItem(valuewjG);
	
	document.getElementById("opacity").value = tripleZeroZ7;
	};
function varD8() {
	
    valuewjH = "valueSaveSS87";
	var tripleZeroZ8 = localStorage.getItem(valuewjH);
	
	document.getElementById("saturate").value = tripleZeroZ8;
	};
function varD9() {
	
    valuewjI = "valueSaveSS88";
	var tripleZeroZ9 = localStorage.getItem(valuewjI);
	
	document.getElementById("sepia").value = tripleZeroZ9;
	};
function varD10() {
	
    valuewjJ = "valueSaveSS89";
	var tripleZeroZ10 = localStorage.getItem(valuewjJ);
	
	document.getElementById("widthNheight").value = tripleZeroZ10;
	};
function varD11() {
	
    valuewjK = "valueSaveSS90";
	var tripleZeroZ11 = localStorage.getItem(valuewjK);
	
	document.getElementById("Background_Color-R").value = tripleZeroZ11;
	};
function varD12() {
	
    valuewjL = "valueSaveSS91";
	var tripleZeroZ12 = localStorage.getItem(valuewjL);
	
	document.getElementById("Background_Color-G").value = tripleZeroZ12;
	};
function varD13() {
	
    valuewjM = "valueSaveSS92";
	var tripleZeroZ13 = localStorage.getItem(valuewjM);
	
	document.getElementById("Background_Color-B").value = tripleZeroZ13;
	};
function varD14() {
	
    valuewjN = "valueSaveSS93";
	var tripleZeroZ14 = localStorage.getItem(valuewjN);
	
	document.getElementById("Font_Color-R").value = tripleZeroZ14;
	};
function varD15() {
	
    valuewjO = "valueSaveSS94";
	var tripleZeroZ15 = localStorage.getItem(valuewjO);
	
	document.getElementById("Font_Color-G").value = tripleZeroZ15;
	};
function varD16() {
	
    valuewjA1 = "valueSaveSS95";
	var tripleZeroZ16 = localStorage.getItem(valuewjA1);
	
	document.getElementById("Font_Color-B").value = tripleZeroZ16;
	};
function varD() {
	varC1();
	varC2();
	varC3();
	varC4();
	varC5();
	varC6();
	varC7();
	varC8();
	varC9();
	varC10();
	varC11();
	varC12();
	varC13();
	varC14();
	varC15();
	varC16();
	alert("Effects Saved.");
	
};
function varE() {
	varD1();
	varD2();
	varD3();
	varD4();
	varD5();
	varD6();
	varD7();
	varD8();
	varD9();
	varD10();
	varD11();
	varD12();
	varD13();
	varD14();
	varD15();
	varD16();
	alert("Effects.");
	backgroundCrgb()
	fontCrgb()
	someCocepts()
	someCocepts2()
	someCoceptsA()
	someCocepts8()
	
};