function varC1() {
	valueSaveSS140 = "valueSaveSS140";
	var valuewjA = document.getElementById("blur").value;
	localStorage.setItem(valueSaveSS140, valuewjA);
 };
function varC2() {
	valueSaveSS141 = "valueSaveSS141";
	var valuewjB = document.getElementById("brightness").value;
	localStorage.setItem(valueSaveSS141, valuewjB);
};
function varC3() {
	valueSaveSS142 = "valueSaveSS142";
	var valuewjC = document.getElementById("contrast").value;
	localStorage.setItem(valueSaveSS142, valuewjC);
};
function varC4() {
	valueSaveSS143 = "valueSaveSS143";
	var valuewjD = document.getElementById("grayscale").value;
	localStorage.setItem(valueSaveSS143, valuewjD);
};
function varC5() {
	valueSaveSS144 = "valueSaveSS144";
	var valuewjE = document.getElementById("huerotate").value;
	localStorage.setItem(valueSaveSS144, valuewjE);
	};
function varC6() {
	valueSaveSS145 = "valueSaveSS145";
	var valuewjF = document.getElementById("invert").value;
	localStorage.setItem(valueSaveSS145, valuewjF);
	};
function varC7() {
	valueSaveSS146 = "valueSaveSS146";
	var valuewjG = document.getElementById("opacity").value;
	localStorage.setItem(valueSaveSS146, valuewjG);
	};
function varC8() {
	valueSaveSS147 = "valueSaveSS147";
	var valuewjH = document.getElementById("saturate").value;
	localStorage.setItem(valueSaveSS147, valuewjH);
	};
function varC9() {
	valueSaveSS148 = "valueSaveSS148";
	var valuewjI = document.getElementById("sepia").value;
	localStorage.setItem(valueSaveSS148, valuewjI);
	};
function varC10() {
	valueSaveSS149 = "valueSaveSS149";
	var valuewjJ = document.getElementById("widthNheight").value;
	localStorage.setItem(valueSaveSS149, valuewjJ);
	};
function varC11() {
	valueSaveSS150 = "valueSaveSS150";
	var valuewjK = document.getElementById("Background_Color-R").value;
	localStorage.setItem(valueSaveSS150, valuewjK);
	};
function varC12() {
	valueSaveSS151 = "valueSaveSS151";
	var valuewjL = document.getElementById("Background_Color-G").value;
	localStorage.setItem(valueSaveSS151, valuewjL);
	};
function varC13() {
	valueSaveSS152 = "valueSaveSS152";
	var valuewjM = document.getElementById("Background_Color-B").value;
	localStorage.setItem(valueSaveSS152, valuewjM);
	};
function varC14() {
	valueSaveSS153 = "valueSaveSS153";
	var valuewjN = document.getElementById("Font_Color-R").value;
	localStorage.setItem(valueSaveSS153, valuewjN);
	};
function varC15() {
	valueSaveSS154 = "valueSaveSS154";
	var valuewjO = document.getElementById("Font_Color-G").value;
	localStorage.setItem(valueSaveSS154, valuewjO);
	};
function varC16() {
    valueSaveSS155 = "valueSaveSS155";
	var valuewjA1 = document.getElementById("Font_Color-B").value;
	localStorage.setItem(valueSaveSS155, valuewjA1);
	};
function varC17() {
	valueSaveSS156 = "valueSaveSS156";
	var valuewjJ = document.getElementById("widthNheight2").value;
	localStorage.setItem(valueSaveSS156, valuewjJ);
	};
function varD1() {
	valuewjA = "valueSaveSS140";
	var tripleZeroZ1 = localStorage.getItem(valuewjA);
	
	document.getElementById("blur").value = tripleZeroZ1;
	};
function varD2() {
	
    valuewjB = "valueSaveSS141";
	var tripleZeroZ2 = localStorage.getItem(valuewjB);
	
	document.getElementById("brightness").value = tripleZeroZ2;
	};
function varD3() {
	
    valuewjC = "valueSaveSS142";
	var tripleZeroZ3 = localStorage.getItem(valuewjC);
	
	document.getElementById("contrast").value = tripleZeroZ3;
	};
function varD4() {
	
    valuewjD = "valueSaveSS143";
	var tripleZeroZ4 = localStorage.getItem(valuewjD);
	
	document.getElementById("grayscale").value = tripleZeroZ4;
	};
function varD5() {
	
    valuewjE = "valueSaveSS144";
	var tripleZeroZ5 = localStorage.getItem(valuewjE);
	
	document.getElementById("huerotate").value = tripleZeroZ5;
	};
function varD6() {
	
    valuewjF = "valueSaveSS145";
	var tripleZeroZ6 = localStorage.getItem(valuewjF);
	
	document.getElementById("invert").value = tripleZeroZ6;
	};
function varD7() {
	
    valuewjG = "valueSaveSS146";
	var tripleZeroZ7 = localStorage.getItem(valuewjG);
	
	document.getElementById("opacity").value = tripleZeroZ7;
	};
function varD8() {
	
    valuewjH = "valueSaveSS147";
	var tripleZeroZ8 = localStorage.getItem(valuewjH);
	
	document.getElementById("saturate").value = tripleZeroZ8;
	};
function varD9() {
	
    valuewjI = "valueSaveSS148";
	var tripleZeroZ9 = localStorage.getItem(valuewjI);
	
	document.getElementById("sepia").value = tripleZeroZ9;
	};
function varD10() {
	
    valuewjJ = "valueSaveSS149";
	var tripleZeroZ10 = localStorage.getItem(valuewjJ);
	
	document.getElementById("widthNheight").value = tripleZeroZ10;
	};
function varD11() {
	
    valuewjK = "valueSaveSS150";
	var tripleZeroZ11 = localStorage.getItem(valuewjK);
	
	document.getElementById("Background_Color-R").value = tripleZeroZ11;
	};
function varD12() {
	
    valuewjL = "valueSaveSS151";
	var tripleZeroZ12 = localStorage.getItem(valuewjL);
	
	document.getElementById("Background_Color-G").value = tripleZeroZ12;
	};
function varD13() {
	
    valuewjM = "valueSaveSS152";
	var tripleZeroZ13 = localStorage.getItem(valuewjM);
	
	document.getElementById("Background_Color-B").value = tripleZeroZ13;
	};
function varD14() {
	
    valuewjN = "valueSaveSS153";
	var tripleZeroZ14 = localStorage.getItem(valuewjN);
	
	document.getElementById("Font_Color-R").value = tripleZeroZ14;
	};
function varD15() {
	
    valuewjO = "valueSaveSS154";
	var tripleZeroZ15 = localStorage.getItem(valuewjO);
	
	document.getElementById("Font_Color-G").value = tripleZeroZ15;
	};
function varD16() {
	
    valuewjA1 = "valueSaveSS155";
	var tripleZeroZ16 = localStorage.getItem(valuewjA1);
	
	document.getElementById("Font_Color-B").value = tripleZeroZ16;
	};
function varD17() {
	
    valuewjJ = "valueSaveSS156";
	var tripleZeroZ10 = localStorage.getItem(valuewjJ);
	
	document.getElementById("widthNheight2").value = tripleZeroZ10;
	};
function varD() {
	varC1();
	varC2();
	varC3();
	varC4();
	varC5();
	varC6();
	varC7();
	varC8();
	varC9();
	varC10();
	varC11();
	varC12();
	varC13();
	varC14();
	varC15();
	varC16();
	varC17();
	alert("Effects Saved.");
	
};
function varE() {
	varD1();
	varD2();
	varD3();
	varD4();
	varD5();
	varD6();
	varD7();
	varD8();
	varD9();
	varD10();
	varD11();
	varD12();
	varD13();
	varD14();
	varD15();
	varD16();
	varD17();
	alert("Effects.");
	backgroundCrgb()
	fontCrgb()
	someCtsA()
	allFilters()
	
};