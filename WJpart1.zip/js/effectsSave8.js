function varC1() {
	valueSaveSS160 = "valueSaveSS160";
	var valuewjA = document.getElementById("blur").value;
	localStorage.setItem(valueSaveSS160, valuewjA);
 };
function varC2() {
	valueSaveSS161 = "valueSaveSS161";
	var valuewjB = document.getElementById("brightness").value;
	localStorage.setItem(valueSaveSS161, valuewjB);
};
function varC3() {
	valueSaveSS162 = "valueSaveSS162";
	var valuewjC = document.getElementById("contrast").value;
	localStorage.setItem(valueSaveSS162, valuewjC);
};
function varC4() {
	valueSaveSS163 = "valueSaveSS163";
	var valuewjD = document.getElementById("grayscale").value;
	localStorage.setItem(valueSaveSS163, valuewjD);
};
function varC5() {
	valueSaveSS164 = "valueSaveSS164";
	var valuewjE = document.getElementById("huerotate").value;
	localStorage.setItem(valueSaveSS164, valuewjE);
	};
function varC6() {
	valueSaveSS165 = "valueSaveSS165";
	var valuewjF = document.getElementById("invert").value;
	localStorage.setItem(valueSaveSS165, valuewjF);
	};
function varC7() {
	valueSaveSS166 = "valueSaveSS166";
	var valuewjG = document.getElementById("opacity").value;
	localStorage.setItem(valueSaveSS166, valuewjG);
	};
function varC8() {
	valueSaveSS167 = "valueSaveSS167";
	var valuewjH = document.getElementById("saturate").value;
	localStorage.setItem(valueSaveSS167, valuewjH);
	};
function varC9() {
	valueSaveSS168 = "valueSaveSS168";
	var valuewjI = document.getElementById("sepia").value;
	localStorage.setItem(valueSaveSS168, valuewjI);
	};
function varC10() {
	valueSaveSS169 = "valueSaveSS169";
	var valuewjJ = document.getElementById("widthNheight").value;
	localStorage.setItem(valueSaveSS169, valuewjJ);
	};
function varC11() {
	valueSaveSS170 = "valueSaveSS170";
	var valuewjK = document.getElementById("Background_Color-R").value;
	localStorage.setItem(valueSaveSS170, valuewjK);
	};
function varC12() {
	valueSaveSS171 = "valueSaveSS171";
	var valuewjL = document.getElementById("Background_Color-G").value;
	localStorage.setItem(valueSaveSS171, valuewjL);
	};
function varC13() {
	valueSaveSS172 = "valueSaveSS172";
	var valuewjM = document.getElementById("Background_Color-B").value;
	localStorage.setItem(valueSaveSS172, valuewjM);
	};
function varC14() {
	valueSaveSS173 = "valueSaveSS173";
	var valuewjN = document.getElementById("Font_Color-R").value;
	localStorage.setItem(valueSaveSS173, valuewjN);
	};
function varC15() {
	valueSaveSS174 = "valueSaveSS174";
	var valuewjO = document.getElementById("Font_Color-G").value;
	localStorage.setItem(valueSaveSS174, valuewjO);
	};
function varC16() {
    valueSaveSS175 = "valueSaveSS175";
	var valuewjA1 = document.getElementById("Font_Color-B").value;
	localStorage.setItem(valueSaveSS175, valuewjA1);
	};
function varC17() {
	valueSaveSS176 = "valueSaveSS176";
	var valuewjJ = document.getElementById("widthNheight2").value;
	localStorage.setItem(valueSaveSS176, valuewjJ);
	};
function varD1() {
	valuewjA = "valueSaveSS160";
	var tripleZeroZ1 = localStorage.getItem(valuewjA);
	
	document.getElementById("blur").value = tripleZeroZ1;
	};
function varD2() {
	
    valuewjB = "valueSaveSS161";
	var tripleZeroZ2 = localStorage.getItem(valuewjB);
	
	document.getElementById("brightness").value = tripleZeroZ2;
	};
function varD3() {
	
    valuewjC = "valueSaveSS162";
	var tripleZeroZ3 = localStorage.getItem(valuewjC);
	
	document.getElementById("contrast").value = tripleZeroZ3;
	};
function varD4() {
	
    valuewjD = "valueSaveSS163";
	var tripleZeroZ4 = localStorage.getItem(valuewjD);
	
	document.getElementById("grayscale").value = tripleZeroZ4;
	};
function varD5() {
	
    valuewjE = "valueSaveSS164";
	var tripleZeroZ5 = localStorage.getItem(valuewjE);
	
	document.getElementById("huerotate").value = tripleZeroZ5;
	};
function varD6() {
	
    valuewjF = "valueSaveSS165";
	var tripleZeroZ6 = localStorage.getItem(valuewjF);
	
	document.getElementById("invert").value = tripleZeroZ6;
	};
function varD7() {
	
    valuewjG = "valueSaveSS166";
	var tripleZeroZ7 = localStorage.getItem(valuewjG);
	
	document.getElementById("opacity").value = tripleZeroZ7;
	};
function varD8() {
	
    valuewjH = "valueSaveSS167";
	var tripleZeroZ8 = localStorage.getItem(valuewjH);
	
	document.getElementById("saturate").value = tripleZeroZ8;
	};
function varD9() {
	
    valuewjI = "valueSaveSS168";
	var tripleZeroZ9 = localStorage.getItem(valuewjI);
	
	document.getElementById("sepia").value = tripleZeroZ9;
	};
function varD10() {
	
    valuewjJ = "valueSaveSS169";
	var tripleZeroZ10 = localStorage.getItem(valuewjJ);
	
	document.getElementById("widthNheight").value = tripleZeroZ10;
	};
function varD11() {
	
    valuewjK = "valueSaveSS170";
	var tripleZeroZ11 = localStorage.getItem(valuewjK);
	
	document.getElementById("Background_Color-R").value = tripleZeroZ11;
	};
function varD12() {
	
    valuewjL = "valueSaveSS171";
	var tripleZeroZ12 = localStorage.getItem(valuewjL);
	
	document.getElementById("Background_Color-G").value = tripleZeroZ12;
	};
function varD13() {
	
    valuewjM = "valueSaveSS172";
	var tripleZeroZ13 = localStorage.getItem(valuewjM);
	
	document.getElementById("Background_Color-B").value = tripleZeroZ13;
	};
function varD14() {
	
    valuewjN = "valueSaveSS173";
	var tripleZeroZ14 = localStorage.getItem(valuewjN);
	
	document.getElementById("Font_Color-R").value = tripleZeroZ14;
	};
function varD15() {
	
    valuewjO = "valueSaveSS174";
	var tripleZeroZ15 = localStorage.getItem(valuewjO);
	
	document.getElementById("Font_Color-G").value = tripleZeroZ15;
	};
function varD16() {
	
    valuewjA1 = "valueSaveSS175";
	var tripleZeroZ16 = localStorage.getItem(valuewjA1);
	
	document.getElementById("Font_Color-B").value = tripleZeroZ16;
	};
function varD17() {
	
    valuewjJ = "valueSaveSS176";
	var tripleZeroZ10 = localStorage.getItem(valuewjJ);
	
	document.getElementById("widthNheight2").value = tripleZeroZ10;
	};
function varD() {
	varC1();
	varC2();
	varC3();
	varC4();
	varC5();
	varC6();
	varC7();
	varC8();
	varC9();
	varC10();
	varC11();
	varC12();
	varC13();
	varC14();
	varC15();
	varC16();
	varC17();
	alert("Effects Saved.");
	
};
function varE() {
	varD1();
	varD2();
	varD3();
	varD4();
	varD5();
	varD6();
	varD7();
	varD8();
	varD9();
	varD10();
	varD11();
	varD12();
	varD13();
	varD14();
	varD15();
	varD16();
	varD17();
	alert("Effects.");
	backgroundCrgb()
	fontCrgb()
	someCtsA()
	allFilters()
	
};