function varC1() {
	valueSaveSS60 = "valueSaveSS60";
	var valuewjA = document.getElementById("blur").value;
	localStorage.setItem(valueSaveSS60, valuewjA);
 };
function varC2() {
	valueSaveSS61 = "valueSaveSS61";
	var valuewjB = document.getElementById("brightness").value;
	localStorage.setItem(valueSaveSS61, valuewjB);
};
function varC3() {
	valueSaveSS62 = "valueSaveSS62";
	var valuewjC = document.getElementById("contrast").value;
	localStorage.setItem(valueSaveSS62, valuewjC);
};
function varC4() {
	valueSaveSS63 = "valueSaveSS63";
	var valuewjD = document.getElementById("grayscale").value;
	localStorage.setItem(valueSaveSS63, valuewjD);
};
function varC5() {
	valueSaveSS64 = "valueSaveSS64";
	var valuewjE = document.getElementById("huerotate").value;
	localStorage.setItem(valueSaveSS64, valuewjE);
	};
function varC6() {
	valueSaveSS65 = "valueSaveSS65";
	var valuewjF = document.getElementById("invert").value;
	localStorage.setItem(valueSaveSS65, valuewjF);
	};
function varC7() {
	valueSaveSS66 = "valueSaveSS66";
	var valuewjG = document.getElementById("opacity").value;
	localStorage.setItem(valueSaveSS66, valuewjG);
	};
function varC8() {
	valueSaveSS67 = "valueSaveSS67";
	var valuewjH = document.getElementById("saturate").value;
	localStorage.setItem(valueSaveSS67, valuewjH);
	};
function varC9() {
	valueSaveSS68 = "valueSaveSS68";
	var valuewjI = document.getElementById("sepia").value;
	localStorage.setItem(valueSaveSS68, valuewjI);
	};
function varC10() {
	valueSaveSS69 = "valueSaveSS69";
	var valuewjJ = document.getElementById("widthNheight").value;
	localStorage.setItem(valueSaveSS69, valuewjJ);
	};
function varC11() {
	valueSaveSS70 = "valueSaveSS70";
	var valuewjK = document.getElementById("Background_Color-R").value;
	localStorage.setItem(valueSaveSS70, valuewjK);
	};
function varC12() {
	valueSaveSS71 = "valueSaveSS71";
	var valuewjL = document.getElementById("Background_Color-G").value;
	localStorage.setItem(valueSaveSS71, valuewjL);
	};
function varC13() {
	valueSaveSS72 = "valueSaveSS72";
	var valuewjM = document.getElementById("Background_Color-B").value;
	localStorage.setItem(valueSaveSS72, valuewjM);
	};
function varC14() {
	valueSaveSS73 = "valueSaveSS73";
	var valuewjN = document.getElementById("Font_Color-R").value;
	localStorage.setItem(valueSaveSS73, valuewjN);
	};
function varC15() {
	valueSaveSS74 = "valueSaveSS74";
	var valuewjO = document.getElementById("Font_Color-G").value;
	localStorage.setItem(valueSaveSS74, valuewjO);
	};
function varC16() {
    valueSaveSS75 = "valueSaveSS75";
	var valuewjA1 = document.getElementById("Font_Color-B").value;
	localStorage.setItem(valueSaveSS75, valuewjA1);
	};
function varD1() {
	valuewjA = "valueSaveSS60";
	var tripleZeroZ1 = localStorage.getItem(valuewjA);
	
	document.getElementById("blur").value = tripleZeroZ1;
	};
function varD2() {
	
    valuewjB = "valueSaveSS61";
	var tripleZeroZ2 = localStorage.getItem(valuewjB);
	
	document.getElementById("brightness").value = tripleZeroZ2;
	};
function varD3() {
	
    valuewjC = "valueSaveSS62";
	var tripleZeroZ3 = localStorage.getItem(valuewjC);
	
	document.getElementById("contrast").value = tripleZeroZ3;
	};
function varD4() {
	
    valuewjD = "valueSaveSS63";
	var tripleZeroZ4 = localStorage.getItem(valuewjD);
	
	document.getElementById("grayscale").value = tripleZeroZ4;
	};
function varD5() {
	
    valuewjE = "valueSaveSS64";
	var tripleZeroZ5 = localStorage.getItem(valuewjE);
	
	document.getElementById("huerotate").value = tripleZeroZ5;
	};
function varD6() {
	
    valuewjF = "valueSaveSS65";
	var tripleZeroZ6 = localStorage.getItem(valuewjF);
	
	document.getElementById("invert").value = tripleZeroZ6;
	};
function varD7() {
	
    valuewjG = "valueSaveSS66";
	var tripleZeroZ7 = localStorage.getItem(valuewjG);
	
	document.getElementById("opacity").value = tripleZeroZ7;
	};
function varD8() {
	
    valuewjH = "valueSaveSS67";
	var tripleZeroZ8 = localStorage.getItem(valuewjH);
	
	document.getElementById("saturate").value = tripleZeroZ8;
	};
function varD9() {
	
    valuewjI = "valueSaveSS68";
	var tripleZeroZ9 = localStorage.getItem(valuewjI);
	
	document.getElementById("sepia").value = tripleZeroZ9;
	};
function varD10() {
	
    valuewjJ = "valueSaveSS69";
	var tripleZeroZ10 = localStorage.getItem(valuewjJ);
	
	document.getElementById("widthNheight").value = tripleZeroZ10;
	};
function varD11() {
	
    valuewjK = "valueSaveSS70";
	var tripleZeroZ11 = localStorage.getItem(valuewjK);
	
	document.getElementById("Background_Color-R").value = tripleZeroZ11;
	};
function varD12() {
	
    valuewjL = "valueSaveSS71";
	var tripleZeroZ12 = localStorage.getItem(valuewjL);
	
	document.getElementById("Background_Color-G").value = tripleZeroZ12;
	};
function varD13() {
	
    valuewjM = "valueSaveSS72";
	var tripleZeroZ13 = localStorage.getItem(valuewjM);
	
	document.getElementById("Background_Color-B").value = tripleZeroZ13;
	};
function varD14() {
	
    valuewjN = "valueSaveSS73";
	var tripleZeroZ14 = localStorage.getItem(valuewjN);
	
	document.getElementById("Font_Color-R").value = tripleZeroZ14;
	};
function varD15() {
	
    valuewjO = "valueSaveSS74";
	var tripleZeroZ15 = localStorage.getItem(valuewjO);
	
	document.getElementById("Font_Color-G").value = tripleZeroZ15;
	};
function varD16() {
	
    valuewjA1 = "valueSaveSS75";
	var tripleZeroZ16 = localStorage.getItem(valuewjA1);
	
	document.getElementById("Font_Color-B").value = tripleZeroZ16;
	};
function varD() {
	varC1();
	varC2();
	varC3();
	varC4();
	varC5();
	varC6();
	varC7();
	varC8();
	varC9();
	varC10();
	varC11();
	varC12();
	varC13();
	varC14();
	varC15();
	varC16();
	alert("Effects Saved.");
	
};
function varE() {
	varD1();
	varD2();
	varD3();
	varD4();
	varD5();
	varD6();
	varD7();
	varD8();
	varD9();
	varD10();
	varD11();
	varD12();
	varD13();
	varD14();
	varD15();
	varD16();
	alert("Effects.");
	backgroundCrgb()
	fontCrgb()
	someCocepts()
	someCocepts2()
	someCoceptsA()
	someCocepts8()
	
};