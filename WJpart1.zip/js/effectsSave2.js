function varC1() {
	valueSaveSS40 = "valueSaveSS40";
	var valuewjA = document.getElementById("blur").value;
	localStorage.setItem(valueSaveSS40, valuewjA);
 };
function varC2() {
	valueSaveSS41 = "valueSaveSS41";
	var valuewjB = document.getElementById("brightness").value;
	localStorage.setItem(valueSaveSS41, valuewjB);
};
function varC3() {
	valueSaveSS42 = "valueSaveSS42";
	var valuewjC = document.getElementById("contrast").value;
	localStorage.setItem(valueSaveSS42, valuewjC);
};
function varC4() {
	valueSaveSS43 = "valueSaveSS43";
	var valuewjD = document.getElementById("grayscale").value;
	localStorage.setItem(valueSaveSS43, valuewjD);
};
function varC5() {
	valueSaveSS44 = "valueSaveSS44";
	var valuewjE = document.getElementById("huerotate").value;
	localStorage.setItem(valueSaveSS44, valuewjE);
	};
function varC6() {
	valueSaveSS45 = "valueSaveSS45";
	var valuewjF = document.getElementById("invert").value;
	localStorage.setItem(valueSaveSS45, valuewjF);
	};
function varC7() {
	valueSaveSS46 = "valueSaveSS46";
	var valuewjG = document.getElementById("opacity").value;
	localStorage.setItem(valueSaveSS46, valuewjG);
	};
function varC8() {
	valueSaveSS47 = "valueSaveSS47";
	var valuewjH = document.getElementById("saturate").value;
	localStorage.setItem(valueSaveSS47, valuewjH);
	};
function varC9() {
	valueSaveSS48 = "valueSaveSS48";
	var valuewjI = document.getElementById("sepia").value;
	localStorage.setItem(valueSaveSS48, valuewjI);
	};
function varC10() {
	valueSaveSS49 = "valueSaveSS49";
	var valuewjJ = document.getElementById("widthNheight").value;
	localStorage.setItem(valueSaveSS49, valuewjJ);
	};
function varC11() {
	valueSaveSS50 = "valueSaveSS50";
	var valuewjK = document.getElementById("Background_Color-R").value;
	localStorage.setItem(valueSaveSS50, valuewjK);
	};
function varC12() {
	valueSaveSS51 = "valueSaveSS51";
	var valuewjL = document.getElementById("Background_Color-G").value;
	localStorage.setItem(valueSaveSS51, valuewjL);
	};
function varC13() {
	valueSaveSS52 = "valueSaveSS52";
	var valuewjM = document.getElementById("Background_Color-B").value;
	localStorage.setItem(valueSaveSS52, valuewjM);
	};
function varC14() {
	valueSaveSS53 = "valueSaveSS53";
	var valuewjN = document.getElementById("Font_Color-R").value;
	localStorage.setItem(valueSaveSS53, valuewjN);
	};
function varC15() {
	valueSaveSS54 = "valueSaveSS54";
	var valuewjO = document.getElementById("Font_Color-G").value;
	localStorage.setItem(valueSaveSS54, valuewjO);
	};
function varC16() {
    valueSaveSS55 = "valueSaveSS55";
	var valuewjA1 = document.getElementById("Font_Color-B").value;
	localStorage.setItem(valueSaveSS55, valuewjA1);
	};
function varD1() {
	valuewjA = "valueSaveSS40";
	var tripleZeroZ1 = localStorage.getItem(valuewjA);
	
	document.getElementById("blur").value = tripleZeroZ1;
	};
function varD2() {
	
    valuewjB = "valueSaveSS41";
	var tripleZeroZ2 = localStorage.getItem(valuewjB);
	
	document.getElementById("brightness").value = tripleZeroZ2;
	};
function varD3() {
	
    valuewjC = "valueSaveSS42";
	var tripleZeroZ3 = localStorage.getItem(valuewjC);
	
	document.getElementById("contrast").value = tripleZeroZ3;
	};
function varD4() {
	
    valuewjD = "valueSaveSS43";
	var tripleZeroZ4 = localStorage.getItem(valuewjD);
	
	document.getElementById("grayscale").value = tripleZeroZ4;
	};
function varD5() {
	
    valuewjE = "valueSaveSS44";
	var tripleZeroZ5 = localStorage.getItem(valuewjE);
	
	document.getElementById("huerotate").value = tripleZeroZ5;
	};
function varD6() {
	
    valuewjF = "valueSaveSS45";
	var tripleZeroZ6 = localStorage.getItem(valuewjF);
	
	document.getElementById("invert").value = tripleZeroZ6;
	};
function varD7() {
	
    valuewjG = "valueSaveSS46";
	var tripleZeroZ7 = localStorage.getItem(valuewjG);
	
	document.getElementById("opacity").value = tripleZeroZ7;
	};
function varD8() {
	
    valuewjH = "valueSaveSS47";
	var tripleZeroZ8 = localStorage.getItem(valuewjH);
	
	document.getElementById("saturate").value = tripleZeroZ8;
	};
function varD9() {
	
    valuewjI = "valueSaveSS48";
	var tripleZeroZ9 = localStorage.getItem(valuewjI);
	
	document.getElementById("sepia").value = tripleZeroZ9;
	};
function varD10() {
	
    valuewjJ = "valueSaveSS49";
	var tripleZeroZ10 = localStorage.getItem(valuewjJ);
	
	document.getElementById("widthNheight").value = tripleZeroZ10;
	};
function varD11() {
	
    valuewjK = "valueSaveSS50";
	var tripleZeroZ11 = localStorage.getItem(valuewjK);
	
	document.getElementById("Background_Color-R").value = tripleZeroZ11;
	};
function varD12() {
	
    valuewjL = "valueSaveSS51";
	var tripleZeroZ12 = localStorage.getItem(valuewjL);
	
	document.getElementById("Background_Color-G").value = tripleZeroZ12;
	};
function varD13() {
	
    valuewjM = "valueSaveSS52";
	var tripleZeroZ13 = localStorage.getItem(valuewjM);
	
	document.getElementById("Background_Color-B").value = tripleZeroZ13;
	};
function varD14() {
	
    valuewjN = "valueSaveSS53";
	var tripleZeroZ14 = localStorage.getItem(valuewjN);
	
	document.getElementById("Font_Color-R").value = tripleZeroZ14;
	};
function varD15() {
	
    valuewjO = "valueSaveSS54";
	var tripleZeroZ15 = localStorage.getItem(valuewjO);
	
	document.getElementById("Font_Color-G").value = tripleZeroZ15;
	};
function varD16() {
	
    valuewjA1 = "valueSaveSS55";
	var tripleZeroZ16 = localStorage.getItem(valuewjA1);
	
	document.getElementById("Font_Color-B").value = tripleZeroZ16;
	};
function varD() {
	varC1();
	varC2();
	varC3();
	varC4();
	varC5();
	varC6();
	varC7();
	varC8();
	varC9();
	varC10();
	varC11();
	varC12();
	varC13();
	varC14();
	varC15();
	varC16();
	alert("Effects Saved.");
	
};
function varE() {
	varD1();
	varD2();
	varD3();
	varD4();
	varD5();
	varD6();
	varD7();
	varD8();
	varD9();
	varD10();
	varD11();
	varD12();
	varD13();
	varD14();
	varD15();
	varD16();
	alert("Effects.");
	backgroundCrgb()
	fontCrgb()
	sizeFilter()
	allFilters()
	
};