function varC1() {
	valueSaveSS100 = "valueSaveSS100";
	var valuewjA = document.getElementById("blur").value;
	localStorage.setItem(valueSaveSS100, valuewjA);
 };
function varC2() {
	valueSaveSS101 = "valueSaveSS101";
	var valuewjB = document.getElementById("brightness").value;
	localStorage.setItem(valueSaveSS101, valuewjB);
};
function varC3() {
	valueSaveSS102 = "valueSaveSS102";
	var valuewjC = document.getElementById("contrast").value;
	localStorage.setItem(valueSaveSS102, valuewjC);
};
function varC4() {
	valueSaveSS103 = "valueSaveSS103";
	var valuewjD = document.getElementById("grayscale").value;
	localStorage.setItem(valueSaveSS103, valuewjD);
};
function varC5() {
	valueSaveSS104 = "valueSaveSS104";
	var valuewjE = document.getElementById("huerotate").value;
	localStorage.setItem(valueSaveSS104, valuewjE);
	};
function varC6() {
	valueSaveSS105 = "valueSaveSS105";
	var valuewjF = document.getElementById("invert").value;
	localStorage.setItem(valueSaveSS105, valuewjF);
	};
function varC7() {
	valueSaveSS106 = "valueSaveSS106";
	var valuewjG = document.getElementById("opacity").value;
	localStorage.setItem(valueSaveSS106, valuewjG);
	};
function varC8() {
	valueSaveSS107 = "valueSaveSS107";
	var valuewjH = document.getElementById("saturate").value;
	localStorage.setItem(valueSaveSS107, valuewjH);
	};
function varC9() {
	valueSaveSS108 = "valueSaveSS108";
	var valuewjI = document.getElementById("sepia").value;
	localStorage.setItem(valueSaveSS108, valuewjI);
	};
function varC10() {
	valueSaveSS109 = "valueSaveSS109";
	var valuewjJ = document.getElementById("widthNheight").value;
	localStorage.setItem(valueSaveSS109, valuewjJ);
	};
function varC11() {
	valueSaveSS110 = "valueSaveSS110";
	var valuewjK = document.getElementById("Background_Color-R").value;
	localStorage.setItem(valueSaveSS110, valuewjK);
	};
function varC12() {
	valueSaveSS111 = "valueSaveSS111";
	var valuewjL = document.getElementById("Background_Color-G").value;
	localStorage.setItem(valueSaveSS111, valuewjL);
	};
function varC13() {
	valueSaveSS112 = "valueSaveSS112";
	var valuewjM = document.getElementById("Background_Color-B").value;
	localStorage.setItem(valueSaveSS112, valuewjM);
	};
function varC14() {
	valueSaveSS113 = "valueSaveSS113";
	var valuewjN = document.getElementById("Font_Color-R").value;
	localStorage.setItem(valueSaveSS113, valuewjN);
	};
function varC15() {
	valueSaveSS114 = "valueSaveSS114";
	var valuewjO = document.getElementById("Font_Color-G").value;
	localStorage.setItem(valueSaveSS114, valuewjO);
	};
function varC16() {
    valueSaveSS115 = "valueSaveSS115";
	var valuewjA1 = document.getElementById("Font_Color-B").value;
	localStorage.setItem(valueSaveSS115, valuewjA1);
	};
function varD1() {
	valuewjA = "valueSaveSS100";
	var tripleZeroZ1 = localStorage.getItem(valuewjA);
	
	document.getElementById("blur").value = tripleZeroZ1;
	};
function varD2() {
	
    valuewjB = "valueSaveSS101";
	var tripleZeroZ2 = localStorage.getItem(valuewjB);
	
	document.getElementById("brightness").value = tripleZeroZ2;
	};
function varD3() {
	
    valuewjC = "valueSaveSS102";
	var tripleZeroZ3 = localStorage.getItem(valuewjC);
	
	document.getElementById("contrast").value = tripleZeroZ3;
	};
function varD4() {
	
    valuewjD = "valueSaveSS103";
	var tripleZeroZ4 = localStorage.getItem(valuewjD);
	
	document.getElementById("grayscale").value = tripleZeroZ4;
	};
function varD5() {
	
    valuewjE = "valueSaveSS104";
	var tripleZeroZ5 = localStorage.getItem(valuewjE);
	
	document.getElementById("huerotate").value = tripleZeroZ5;
	};
function varD6() {
	
    valuewjF = "valueSaveSS105";
	var tripleZeroZ6 = localStorage.getItem(valuewjF);
	
	document.getElementById("invert").value = tripleZeroZ6;
	};
function varD7() {
	
    valuewjG = "valueSaveSS106";
	var tripleZeroZ7 = localStorage.getItem(valuewjG);
	
	document.getElementById("opacity").value = tripleZeroZ7;
	};
function varD8() {
	
    valuewjH = "valueSaveSS107";
	var tripleZeroZ8 = localStorage.getItem(valuewjH);
	
	document.getElementById("saturate").value = tripleZeroZ8;
	};
function varD9() {
	
    valuewjI = "valueSaveSS108";
	var tripleZeroZ9 = localStorage.getItem(valuewjI);
	
	document.getElementById("sepia").value = tripleZeroZ9;
	};
function varD10() {
	
    valuewjJ = "valueSaveSS109";
	var tripleZeroZ10 = localStorage.getItem(valuewjJ);
	
	document.getElementById("widthNheight").value = tripleZeroZ10;
	};
function varD11() {
	
    valuewjK = "valueSaveSS110";
	var tripleZeroZ11 = localStorage.getItem(valuewjK);
	
	document.getElementById("Background_Color-R").value = tripleZeroZ11;
	};
function varD12() {
	
    valuewjL = "valueSaveSS111";
	var tripleZeroZ12 = localStorage.getItem(valuewjL);
	
	document.getElementById("Background_Color-G").value = tripleZeroZ12;
	};
function varD13() {
	
    valuewjM = "valueSaveSS112";
	var tripleZeroZ13 = localStorage.getItem(valuewjM);
	
	document.getElementById("Background_Color-B").value = tripleZeroZ13;
	};
function varD14() {
	
    valuewjN = "valueSaveSS113";
	var tripleZeroZ14 = localStorage.getItem(valuewjN);
	
	document.getElementById("Font_Color-R").value = tripleZeroZ14;
	};
function varD15() {
	
    valuewjO = "valueSaveSS114";
	var tripleZeroZ15 = localStorage.getItem(valuewjO);
	
	document.getElementById("Font_Color-G").value = tripleZeroZ15;
	};
function varD16() {
	
    valuewjA1 = "valueSaveSS115";
	var tripleZeroZ16 = localStorage.getItem(valuewjA1);
	
	document.getElementById("Font_Color-B").value = tripleZeroZ16;
	};
function varD() {
	varC1();
	varC2();
	varC3();
	varC4();
	varC5();
	varC6();
	varC7();
	varC8();
	varC9();
	varC10();
	varC11();
	varC12();
	varC13();
	varC14();
	varC15();
	varC16();
	alert("Effects Saved.");
	
};
function varE() {
	varD1();
	varD2();
	varD3();
	varD4();
	varD5();
	varD6();
	varD7();
	varD8();
	varD9();
	varD10();
	varD11();
	varD12();
	varD13();
	varD14();
	varD15();
	varD16();
	alert("Effects.");
	backgroundCrgb()
	fontCrgb()
	someCocepts()
	someCocepts2()
	someCoceptsA()
	someCocepts8()
	
};