function square1(){

    var sQz1 = document.getElementById("aImgSqr1").src;

    value25aSave1 = "zSqrArtSpecz1";

    localStorage.setItem(value25aSave1, sQz1);
};

function square2(){

    var sQz2 = document.getElementById("aImgSqr2").src;

    value25aSave2 = "zSqrArtSpecz2";

    localStorage.setItem(value25aSave2, sQz2);
};

function square3(){

    var sQz3 = document.getElementById("aImgSqr3").src;

    value25aSave3 = "zSqrArtSpecz3";

    localStorage.setItem(value25aSave3, sQz3);
};

function square4(){

    var sQz4 = document.getElementById("aImgSqr4").src;

    value25aSave4 = "zSqrArtSpecz4";

    localStorage.setItem(value25aSave4, sQz4);
};

function square5(){

    var sQz5 = document.getElementById("aImgSqr5").src;

    value25aSave5 = "zSqrArtSpecz5";

    localStorage.setItem(value25aSave5, sQz5);
};

function square6(){

    var sQz6 = document.getElementById("aImgSqr6").src;

    value25aSave6 = "zSqrArtSpecz6";

    localStorage.setItem(value25aSave6, sQz6);
};

function square7(){

    var sQz7 = document.getElementById("aImgSqr7").src;

    value25aSave7 = "zSqrArtSpecz7";

    localStorage.setItem(value25aSave7, sQz7);
};

function square8(){

    var sQz8 = document.getElementById("aImgSqr8").src;

    value25aSave8 = "zSqrArtSpecz8";

    localStorage.setItem(value25aSave8, sQz8);
};

function square9(){

    var sQz9 = document.getElementById("aImgSqr9").src;

    value25aSave9 = "zSqrArtSpecz9";

    localStorage.setItem(value25aSave9, sQz9);
};

function square10(){

    var sQz10 = document.getElementById("aImgSqr10").src;

    value25aSave10 = "zSqrArtSpecz10";

    localStorage.setItem(value25aSave10, sQz10);
};

function square11(){

    var sQz11 = document.getElementById("aImgSqr11").src;

    value25aSave11 = "zSqrArtSpecz11";

    localStorage.setItem(value25aSave11, sQz11);
};

function square12(){

    var sQz12 = document.getElementById("aImgSqr12").src;

    value25aSave12 = "zSqrArtSpecz12";

    localStorage.setItem(value25aSave12, sQz12);
};

function square13(){

    var sQz13 = document.getElementById("aImgSqr13").src;

    value25aSave13 = "zSqrArtSpecz13";

    localStorage.setItem(value25aSave13, sQz13);
};

function square14(){

    var sQz14 = document.getElementById("aImgSqr14").src;

    value25aSave14 = "zSqrArtSpecz14";

    localStorage.setItem(value25aSave14, sQz14);
};

function square15(){

    var sQz15 = document.getElementById("aImgSqr15").src;

    value25aSave15 = "zSqrArtSpecz15";

    localStorage.setItem(value25aSave15, sQz15);
};

function square16(){

    var sQz16 = document.getElementById("aImgSqr16").src;

    value25aSave16 = "zSqrArtSpecz16";

    localStorage.setItem(value25aSave16, sQz16);
};

function square17(){

    var sQz17 = document.getElementById("aImgSqr17").src;

    value25aSave17 = "zSqrArtSpecz17";

    localStorage.setItem(value25aSave17, sQz17);
};

function square18(){

    var sQz18 = document.getElementById("aImgSqr18").src;

    value25aSave18 = "zSqrArtSpecz18";

    localStorage.setItem(value25aSave18, sQz18);
};

function square19(){

    var sQz19 = document.getElementById("aImgSqr19").src;

    value25aSave19 = "zSqrArtSpecz19";

    localStorage.setItem(value25aSave19, sQz19);
};

function square20(){

    var sQz20 = document.getElementById("aImgSqr20").src;

    value25aSave20 = "zSqrArtSpecz20";

    localStorage.setItem(value25aSave20, sQz20);
};

function square21(){

    var sQz21 = document.getElementById("aImgSqr21").src;

    value25aSave21 = "zSqrArtSpecz21";

    localStorage.setItem(value25aSave21, sQz21);
};

function square22(){

    var sQz22 = document.getElementById("aImgSqr22").src;

    value25aSave22 = "zSqrArtSpecz22";

    localStorage.setItem(value25aSave22, sQz22);
};

function square23(){

    var sQz23 = document.getElementById("aImgSqr23").src;

    value25aSave23 = "zSqrArtSpecz23";

    localStorage.setItem(value25aSave23, sQz23);
};

function square24(){

    var sQz24 = document.getElementById("aImgSqr24").src;

    value25aSave24 = "zSqrArtSpecz24";

    localStorage.setItem(value25aSave24, sQz24);
};

function square25(){

    var sQz25 = document.getElementById("aImgSqr25").src;

    value25aSave25 = "zSqrArtSpecz25";

    localStorage.setItem(value25aSave25, sQz25);
};

function square26(){

    var sQz26 = document.getElementById("aImgSqr26").src;

    value25aSave26 = "zSqrArtSpecz26";

    localStorage.setItem(value25aSave26, sQz26);
};

function square27(){

    var sQz27 = document.getElementById("aImgSqr27").src;

    value25aSave27 = "zSqrArtSpecz27";

    localStorage.setItem(value25aSave27, sQz27);
};

function square28(){

    var sQz28 = document.getElementById("aImgSqr28").src;

    value25aSave28 = "zSqrArtSpecz28";

    localStorage.setItem(value25aSave28, sQz28);
};

function square29(){

    var sQz29 = document.getElementById("aImgSqr29").src;

    value25aSave29 = "zSqrArtSpecz29";

    localStorage.setItem(value25aSave29, sQz29);
};

function square30(){

    var sQz30 = document.getElementById("aImgSqr30").src;

    value25aSave30 = "zSqrArtSpecz30";

    localStorage.setItem(value25aSave30, sQz30);
};

function square31(){

    var sQz31 = document.getElementById("aImgSqr31").src;

    value25aSave31 = "zSqrArtSpecz31";

    localStorage.setItem(value25aSave31, sQz31);
};

function square32(){

    var sQz32 = document.getElementById("aImgSqr32").src;

    value25aSave32 = "zSqrArtSpecz32";

    localStorage.setItem(value25aSave32, sQz32);
};

function square33(){

    var sQz33 = document.getElementById("aImgSqr33").src;

    value25aSave33 = "zSqrArtSpecz33";

    localStorage.setItem(value25aSave33, sQz33);
};

function square34(){

    var sQz34 = document.getElementById("aImgSqr34").src;

    value25aSave34 = "zSqrArtSpecz34";

    localStorage.setItem(value25aSave34, sQz34);
};

function square35(){

    var sQz35 = document.getElementById("aImgSqr35").src;

    value25aSave35 = "zSqrArtSpecz35";

    localStorage.setItem(value25aSave35, sQz35);
};

function square36(){

    var sQz36 = document.getElementById("aImgSqr36").src;

    value25aSave36 = "zSqrArtSpecz36";

    localStorage.setItem(value25aSave36, sQz36);
};

function square37(){

    var sQz37 = document.getElementById("aImgSqr37").src;

    value25aSave37 = "zSqrArtSpecz37";

    localStorage.setItem(value25aSave37, sQz37);
};

function square38(){

    var sQz38 = document.getElementById("aImgSqr38").src;

    value25aSave38 = "zSqrArtSpecz38";

    localStorage.setItem(value25aSave38, sQz38);
};

function square39(){

    var sQz39 = document.getElementById("aImgSqr39").src;

    value25aSave39 = "zSqrArtSpecz39";

    localStorage.setItem(value25aSave39, sQz39);
};

function square40(){

    var sQz40 = document.getElementById("aImgSqr40").src;

    value25aSave40 = "zSqrArtSpecz40";

    localStorage.setItem(value25aSave40, sQz40);
};

function square41(){

    var sQz41 = document.getElementById("aImgSqr41").src;

    value25aSave41 = "zSqrArtSpecz41";

    localStorage.setItem(value25aSave41, sQz41);
};

function square42(){

    var sQz42 = document.getElementById("aImgSqr42").src;

    value25aSave42 = "zSqrArtSpecz42";

    localStorage.setItem(value25aSave42, sQz42);
};

function square43(){

    var sQz43 = document.getElementById("aImgSqr43").src;

    value25aSave43 = "zSqrArtSpecz43";

    localStorage.setItem(value25aSave43, sQz43);
};

function square44(){

    var sQz44 = document.getElementById("aImgSqr44").src;

    value25aSave44 = "zSqrArtSpecz44";

    localStorage.setItem(value25aSave44, sQz44);
};

function square45(){

    var sQz45 = document.getElementById("aImgSqr45").src;

    value25aSave45 = "zSqrArtSpecz45";

    localStorage.setItem(value25aSave45, sQz45);
};

function square46(){

    var sQz46 = document.getElementById("aImgSqr46").src;

    value25aSave46 = "zSqrArtSpecz46";

    localStorage.setItem(value25aSave46, sQz46);
};

function square47(){

    var sQz47 = document.getElementById("aImgSqr47").src;

    value25aSave47 = "zSqrArtSpecz47";

    localStorage.setItem(value25aSave47, sQz47);
};

function square48(){

    var sQz48 = document.getElementById("aImgSqr48").src;

    value25aSave48 = "zSqrArtSpecz48";

    localStorage.setItem(value25aSave48, sQz48);
};

function square49(){

    var sQz49 = document.getElementById("aImgSqr49").src;

    value25aSave49 = "zSqrArtSpecz49";

    localStorage.setItem(value25aSave49, sQz49);
};

function square50(){

    var sQz50 = document.getElementById("aImgSqr50").src;

    value25aSave50 = "zSqrArtSpecz50";

    localStorage.setItem(value25aSave50, sQz50);
};

function square51(){

    var sQz51 = document.getElementById("aImgSqr51").src;

    value25aSave51 = "zSqrArtSpecz51";

    localStorage.setItem(value25aSave51, sQz51);
};

function square52(){

    var sQz52 = document.getElementById("aImgSqr52").src;

    value25aSave52 = "zSqrArtSpecz52";

    localStorage.setItem(value25aSave52, sQz52);
};

function square53(){

    var sQz53 = document.getElementById("aImgSqr53").src;

    value25aSave53 = "zSqrArtSpecz53";

    localStorage.setItem(value25aSave53, sQz53);
};

function square54(){

    var sQz54 = document.getElementById("aImgSqr54").src;

    value25aSave54 = "zSqrArtSpecz54";

    localStorage.setItem(value25aSave54, sQz54);
};

function square55(){

    var sQz55 = document.getElementById("aImgSqr55").src;

    value25aSave55 = "zSqrArtSpecz55";

    localStorage.setItem(value25aSave55, sQz55);
};

function square56(){

    var sQz56 = document.getElementById("aImgSqr56").src;

    value25aSave56 = "zSqrArtSpecz56";

    localStorage.setItem(value25aSave56, sQz56);
};

function square57(){

    var sQz57 = document.getElementById("aImgSqr57").src;

    value25aSave57 = "zSqrArtSpecz57";

    localStorage.setItem(value25aSave57, sQz57);
};

function square58(){

    var sQz58 = document.getElementById("aImgSqr58").src;

    value25aSave58 = "zSqrArtSpecz58";

    localStorage.setItem(value25aSave58, sQz58);
};

function square59(){

    var sQz59 = document.getElementById("aImgSqr59").src;

    value25aSave59 = "zSqrArtSpecz59";

    localStorage.setItem(value25aSave59, sQz59);
};

function square60(){

    var sQz60 = document.getElementById("aImgSqr60").src;

    value25aSave60 = "zSqrArtSpecz60";

    localStorage.setItem(value25aSave60, sQz60);
};

function square61(){

    var sQz61 = document.getElementById("aImgSqr61").src;

    value25aSave61 = "zSqrArtSpecz61";

    localStorage.setItem(value25aSave61, sQz61);
};

function square62(){

    var sQz62 = document.getElementById("aImgSqr62").src;

    value25aSave62 = "zSqrArtSpecz62";

    localStorage.setItem(value25aSave62, sQz62);
};

function square63(){

    var sQz63 = document.getElementById("aImgSqr63").src;

    value25aSave63 = "zSqrArtSpecz63";

    localStorage.setItem(value25aSave63, sQz63);
};

function square64(){

    var sQz64 = document.getElementById("aImgSqr64").src;

    value25aSave64 = "zSqrArtSpecz64";

    localStorage.setItem(value25aSave64, sQz64);
};

function square65(){

    var sQz65 = document.getElementById("aImgSqr65").src;

    value25aSave65 = "zSqrArtSpecz65";

    localStorage.setItem(value25aSave65, sQz65);
};

function square66(){

    var sQz66 = document.getElementById("aImgSqr66").src;

    value25aSave66 = "zSqrArtSpecz66";

    localStorage.setItem(value25aSave66, sQz66);
};

function square67(){

    var sQz67 = document.getElementById("aImgSqr67").src;

    value25aSave67 = "zSqrArtSpecz67";

    localStorage.setItem(value25aSave67, sQz67);
};

function square68(){

    var sQz68 = document.getElementById("aImgSqr68").src;

    value25aSave68 = "zSqrArtSpecz68";

    localStorage.setItem(value25aSave68, sQz68);
};

function square69(){

    var sQz69 = document.getElementById("aImgSqr69").src;

    value25aSave69 = "zSqrArtSpecz69";

    localStorage.setItem(value25aSave69, sQz69);
};

function square70(){

    var sQz70 = document.getElementById("aImgSqr70").src;

    value25aSave70 = "zSqrArtSpecz70";

    localStorage.setItem(value25aSave70, sQz70);
};

function square71(){

    var sQz71 = document.getElementById("aImgSqr71").src;

    value25aSave71 = "zSqrArtSpecz71";

    localStorage.setItem(value25aSave71, sQz71);
};

function square72(){

    var sQz72 = document.getElementById("aImgSqr72").src;

    value25aSave72 = "zSqrArtSpecz72";

    localStorage.setItem(value25aSave72, sQz72);
};

function square73(){

    var sQz73 = document.getElementById("aImgSqr73").src;

    value25aSave73 = "zSqrArtSpecz73";

    localStorage.setItem(value25aSave73, sQz73);
};

function square74(){

    var sQz74 = document.getElementById("aImgSqr74").src;

    value25aSave74 = "zSqrArtSpecz74";

    localStorage.setItem(value25aSave74, sQz74);
};

function square75(){

    var sQz75 = document.getElementById("aImgSqr75").src;

    value25aSave75 = "zSqrArtSpecz75";

    localStorage.setItem(value25aSave75, sQz75);
};

function square76(){

    var sQz76 = document.getElementById("aImgSqr76").src;

    value25aSave76 = "zSqrArtSpecz76";

    localStorage.setItem(value25aSave76, sQz76);
};

function square77(){

    var sQz77 = document.getElementById("aImgSqr77").src;

    value25aSave77 = "zSqrArtSpecz77";

    localStorage.setItem(value25aSave77, sQz77);
};

function square78(){

    var sQz78 = document.getElementById("aImgSqr78").src;

    value25aSave78 = "zSqrArtSpecz78";

    localStorage.setItem(value25aSave78, sQz78);
};

function square79(){

    var sQz79 = document.getElementById("aImgSqr79").src;

    value25aSave79 = "zSqrArtSpecz79";

    localStorage.setItem(value25aSave79, sQz79);
};

function square80(){

    var sQz80 = document.getElementById("aImgSqr80").src;

    value25aSave80 = "zSqrArtSpecz80";

    localStorage.setItem(value25aSave80, sQz80);
};

function square81(){

    var sQz81 = document.getElementById("aImgSqr81").src;

    value25aSave81 = "zSqrArtSpecz81";

    localStorage.setItem(value25aSave81, sQz81);
};

function square82(){

    var sQz82 = document.getElementById("aImgSqr82").src;

    value25aSave82 = "zSqrArtSpecz82";

    localStorage.setItem(value25aSave82, sQz82);
};

function square83(){

    var sQz83 = document.getElementById("aImgSqr83").src;

    value25aSave83 = "zSqrArtSpecz83";

    localStorage.setItem(value25aSave83, sQz83);
};

function square84(){

    var sQz84 = document.getElementById("aImgSqr84").src;

    value25aSave84 = "zSqrArtSpecz84";

    localStorage.setItem(value25aSave84, sQz84);
};

function square85(){

    var sQz85 = document.getElementById("aImgSqr85").src;

    value25aSave85 = "zSqrArtSpecz85";

    localStorage.setItem(value25aSave85, sQz85);
};

function square86(){

    var sQz86 = document.getElementById("aImgSqr86").src;

    value25aSave86 = "zSqrArtSpecz86";

    localStorage.setItem(value25aSave86, sQz86);
};

function square87(){

    var sQz87 = document.getElementById("aImgSqr87").src;

    value25aSave87 = "zSqrArtSpecz87";

    localStorage.setItem(value25aSave87, sQz87);
};

function square88(){

    var sQz88 = document.getElementById("aImgSqr88").src;

    value25aSave88 = "zSqrArtSpecz88";

    localStorage.setItem(value25aSave88, sQz88);
};

function square89(){

    var sQz89 = document.getElementById("aImgSqr89").src;

    value25aSave89 = "zSqrArtSpecz89";

    localStorage.setItem(value25aSave89, sQz89);
};

function square90(){

    var sQz90 = document.getElementById("aImgSqr90").src;

    value25aSave90 = "zSqrArtSpecz90";

    localStorage.setItem(value25aSave90, sQz90);
};

function square91(){

    var sQz91 = document.getElementById("aImgSqr91").src;

    value25aSave91 = "zSqrArtSpecz91";

    localStorage.setItem(value25aSave91, sQz91);
};

function square92(){

    var sQz92 = document.getElementById("aImgSqr92").src;

    value25aSave92 = "zSqrArtSpecz92";

    localStorage.setItem(value25aSave92, sQz92);
};

function square93(){

    var sQz93 = document.getElementById("aImgSqr93").src;

    value25aSave93 = "zSqrArtSpecz93";

    localStorage.setItem(value25aSave93, sQz93);
};

function square94(){

    var sQz94 = document.getElementById("aImgSqr94").src;

    value25aSave94 = "zSqrArtSpecz94";

    localStorage.setItem(value25aSave94, sQz94);
};

function square95(){

    var sQz95 = document.getElementById("aImgSqr95").src;

    value25aSave95 = "zSqrArtSpecz95";

    localStorage.setItem(value25aSave95, sQz95);
};

function square96(){

    var sQz96 = document.getElementById("aImgSqr96").src;

    value25aSave96 = "zSqrArtSpecz96";

    localStorage.setItem(value25aSave96, sQz96);
};

function square97(){

    var sQz97 = document.getElementById("aImgSqr97").src;

    value25aSave97 = "zSqrArtSpecz97";

    localStorage.setItem(value25aSave97, sQz97);
};

function square98(){

    var sQz98 = document.getElementById("aImgSqr98").src;

    value25aSave98 = "zSqrArtSpecz98";

    localStorage.setItem(value25aSave98, sQz98);
};

function square99(){

    var sQz99 = document.getElementById("aImgSqr99").src;

    value25aSave99 = "zSqrArtSpecz99";

    localStorage.setItem(value25aSave99, sQz99);
};

function square100(){

    var sQz100 = document.getElementById("aImgSqr100").src;

    value25aSave100 = "zSqrArtSpecz100";

    localStorage.setItem(value25aSave100, sQz100);
};

function square101(){

    var sQz101 = document.getElementById("aImgSqr101").src;

    value25aSave101 = "zSqrArtSpecz101";

    localStorage.setItem(value25aSave101, sQz101);
};

function square102(){

    var sQz102 = document.getElementById("aImgSqr102").src;

    value25aSave102 = "zSqrArtSpecz102";

    localStorage.setItem(value25aSave102, sQz102);
};

function square103(){

    var sQz103 = document.getElementById("aImgSqr103").src;

    value25aSave103 = "zSqrArtSpecz103";

    localStorage.setItem(value25aSave103, sQz103);
};

function square104(){

    var sQz104 = document.getElementById("aImgSqr104").src;

    value25aSave104 = "zSqrArtSpecz104";

    localStorage.setItem(value25aSave104, sQz104);
};

function square105(){

    var sQz105 = document.getElementById("aImgSqr105").src;

    value25aSave105 = "zSqrArtSpecz105";

    localStorage.setItem(value25aSave105, sQz105);
};

function square106(){

    var sQz106 = document.getElementById("aImgSqr106").src;

    value25aSave106 = "zSqrArtSpecz106";

    localStorage.setItem(value25aSave106, sQz106);
};

function square107(){

    var sQz107 = document.getElementById("aImgSqr107").src;

    value25aSave107 = "zSqrArtSpecz107";

    localStorage.setItem(value25aSave107, sQz107);
};

function square108(){

    var sQz108 = document.getElementById("aImgSqr108").src;

    value25aSave108 = "zSqrArtSpecz108";

    localStorage.setItem(value25aSave108, sQz108);
};

function square109(){

    var sQz109 = document.getElementById("aImgSqr109").src;

    value25aSave109 = "zSqrArtSpecz109";

    localStorage.setItem(value25aSave109, sQz109);
};

function square110(){

    var sQz110 = document.getElementById("aImgSqr110").src;

    value25aSave110 = "zSqrArtSpecz110";

    localStorage.setItem(value25aSave110, sQz110);
};

function square111(){

    var sQz111 = document.getElementById("aImgSqr111").src;

    value25aSave111 = "zSqrArtSpecz111";

    localStorage.setItem(value25aSave111, sQz111);
};

function square112(){

    var sQz112 = document.getElementById("aImgSqr112").src;

    value25aSave112 = "zSqrArtSpecz112";

    localStorage.setItem(value25aSave112, sQz112);
};

function square113(){

    var sQz113 = document.getElementById("aImgSqr113").src;

    value25aSave113 = "zSqrArtSpecz113";

    localStorage.setItem(value25aSave113, sQz113);
};

function square114(){

    var sQz114 = document.getElementById("aImgSqr114").src;

    value25aSave114 = "zSqrArtSpecz114";

    localStorage.setItem(value25aSave114, sQz114);
};

function square115(){

    var sQz115 = document.getElementById("aImgSqr115").src;

    value25aSave115 = "zSqrArtSpecz115";

    localStorage.setItem(value25aSave115, sQz115);
};

function square116(){

    var sQz116 = document.getElementById("aImgSqr116").src;

    value25aSave116 = "zSqrArtSpecz116";

    localStorage.setItem(value25aSave116, sQz116);
};

function square117(){

    var sQz117 = document.getElementById("aImgSqr117").src;

    value25aSave117 = "zSqrArtSpecz117";

    localStorage.setItem(value25aSave117, sQz117);
};

function square118(){

    var sQz118 = document.getElementById("aImgSqr118").src;

    value25aSave118 = "zSqrArtSpecz118";

    localStorage.setItem(value25aSave118, sQz118);
};

function square119(){

    var sQz119 = document.getElementById("aImgSqr119").src;

    value25aSave119 = "zSqrArtSpecz119";

    localStorage.setItem(value25aSave119, sQz119);
};

function square120(){

    var sQz120 = document.getElementById("aImgSqr120").src;

    value25aSave120 = "zSqrArtSpecz120";

    localStorage.setItem(value25aSave120, sQz120);
};

function square121(){

    var sQz121 = document.getElementById("aImgSqr121").src;

    value25aSave121 = "zSqrArtSpecz121";

    localStorage.setItem(value25aSave121, sQz121);
};

function square122(){

    var sQz122 = document.getElementById("aImgSqr122").src;

    value25aSave122 = "zSqrArtSpecz122";

    localStorage.setItem(value25aSave122, sQz122);
};

function square123(){

    var sQz123 = document.getElementById("aImgSqr123").src;

    value25aSave123 = "zSqrArtSpecz123";

    localStorage.setItem(value25aSave123, sQz123);
};

function square124(){

    var sQz124 = document.getElementById("aImgSqr124").src;

    value25aSave124 = "zSqrArtSpecz124";

    localStorage.setItem(value25aSave124, sQz124);
};

function square125(){

    var sQz125 = document.getElementById("aImgSqr125").src;

    value25aSave125 = "zSqrArtSpecz125";

    localStorage.setItem(value25aSave125, sQz125);
};

function square126(){

    var sQz126 = document.getElementById("aImgSqr126").src;

    value25aSave126 = "zSqrArtSpecz126";

    localStorage.setItem(value25aSave126, sQz126);
};

function square127(){

    var sQz127 = document.getElementById("aImgSqr127").src;

    value25aSave127 = "zSqrArtSpecz127";

    localStorage.setItem(value25aSave127, sQz127);
};

function square128(){

    var sQz128 = document.getElementById("aImgSqr128").src;

    value25aSave128 = "zSqrArtSpecz128";

    localStorage.setItem(value25aSave128, sQz128);
};

function square129(){

    var sQz129 = document.getElementById("aImgSqr129").src;

    value25aSave129 = "zSqrArtSpecz129";

    localStorage.setItem(value25aSave129, sQz129);
};

function square130(){

    var sQz130 = document.getElementById("aImgSqr130").src;

    value25aSave130 = "zSqrArtSpecz130";

    localStorage.setItem(value25aSave130, sQz130);
};

function square131(){

    var sQz131 = document.getElementById("aImgSqr131").src;

    value25aSave131 = "zSqrArtSpecz131";

    localStorage.setItem(value25aSave131, sQz131);
};

function square132(){

    var sQz132 = document.getElementById("aImgSqr132").src;

    value25aSave132 = "zSqrArtSpecz132";

    localStorage.setItem(value25aSave132, sQz132);
};

function square133(){

    var sQz133 = document.getElementById("aImgSqr133").src;

    value25aSave133 = "zSqrArtSpecz133";

    localStorage.setItem(value25aSave133, sQz133);
};

function square134(){

    var sQz134 = document.getElementById("aImgSqr134").src;

    value25aSave134 = "zSqrArtSpecz134";

    localStorage.setItem(value25aSave134, sQz134);
};

function square135(){

    var sQz135 = document.getElementById("aImgSqr135").src;

    value25aSave135 = "zSqrArtSpecz135";

    localStorage.setItem(value25aSave135, sQz135);
};

function square136(){

    var sQz136 = document.getElementById("aImgSqr136").src;

    value25aSave136 = "zSqrArtSpecz136";

    localStorage.setItem(value25aSave136, sQz136);
};

function square137(){

    var sQz137 = document.getElementById("aImgSqr137").src;

    value25aSave137 = "zSqrArtSpecz137";

    localStorage.setItem(value25aSave137, sQz137);
};

function square138(){

    var sQz138 = document.getElementById("aImgSqr138").src;

    value25aSave138 = "zSqrArtSpecz138";

    localStorage.setItem(value25aSave138, sQz138);
};

function square139(){

    var sQz139 = document.getElementById("aImgSqr139").src;

    value25aSave139 = "zSqrArtSpecz139";

    localStorage.setItem(value25aSave139, sQz139);
};

function square140(){

    var sQz140 = document.getElementById("aImgSqr140").src;

    value25aSave140 = "zSqrArtSpecz140";

    localStorage.setItem(value25aSave140, sQz140);
};

function square141(){

    var sQz141 = document.getElementById("aImgSqr141").src;

    value25aSave141 = "zSqrArtSpecz141";

    localStorage.setItem(value25aSave141, sQz141);
};

function square142(){

    var sQz142 = document.getElementById("aImgSqr142").src;

    value25aSave142 = "zSqrArtSpecz142";

    localStorage.setItem(value25aSave142, sQz142);
};

function square143(){

    var sQz143 = document.getElementById("aImgSqr143").src;

    value25aSave143 = "zSqrArtSpecz143";

    localStorage.setItem(value25aSave143, sQz143);
};

function square144(){

    var sQz144 = document.getElementById("aImgSqr144").src;

    value25aSave144 = "zSqrArtSpecz144";

    localStorage.setItem(value25aSave144, sQz144);
};

function square145(){

    var sQz145 = document.getElementById("aImgSqr145").src;

    value25aSave145 = "zSqrArtSpecz145";

    localStorage.setItem(value25aSave145, sQz145);
};

function square146(){

    var sQz146 = document.getElementById("aImgSqr146").src;

    value25aSave146 = "zSqrArtSpecz146";

    localStorage.setItem(value25aSave146, sQz146);
};

function square147(){

    var sQz147 = document.getElementById("aImgSqr147").src;

    value25aSave147 = "zSqrArtSpecz147";

    localStorage.setItem(value25aSave147, sQz147);
};

function square148(){

    var sQz148 = document.getElementById("aImgSqr148").src;

    value25aSave148 = "zSqrArtSpecz148";

    localStorage.setItem(value25aSave148, sQz148);
};

function square149(){

    var sQz149 = document.getElementById("aImgSqr149").src;

    value25aSave149 = "zSqrArtSpecz149";

    localStorage.setItem(value25aSave149, sQz149);
};

function square150(){

    var sQz150 = document.getElementById("aImgSqr150").src;

    value25aSave150 = "zSqrArtSpecz150";

    localStorage.setItem(value25aSave150, sQz150);
};

function square151(){

    var sQz151 = document.getElementById("aImgSqr151").src;

    value25aSave151 = "zSqrArtSpecz151";

    localStorage.setItem(value25aSave151, sQz151);
};

function square152(){

    var sQz152 = document.getElementById("aImgSqr152").src;

    value25aSave152 = "zSqrArtSpecz152";

    localStorage.setItem(value25aSave152, sQz152);
};

function square153(){

    var sQz153 = document.getElementById("aImgSqr153").src;

    value25aSave153 = "zSqrArtSpecz153";

    localStorage.setItem(value25aSave153, sQz153);
};

function square154(){

    var sQz154 = document.getElementById("aImgSqr154").src;

    value25aSave154 = "zSqrArtSpecz154";

    localStorage.setItem(value25aSave154, sQz154);
};

function square155(){

    var sQz155 = document.getElementById("aImgSqr155").src;

    value25aSave155 = "zSqrArtSpecz155";

    localStorage.setItem(value25aSave155, sQz155);
};

function square156(){

    var sQz156 = document.getElementById("aImgSqr156").src;

    value25aSave156 = "zSqrArtSpecz156";

    localStorage.setItem(value25aSave156, sQz156);
};

function square157(){

    var sQz157 = document.getElementById("aImgSqr157").src;

    value25aSave157 = "zSqrArtSpecz157";

    localStorage.setItem(value25aSave157, sQz157);
};

function square158(){

    var sQz158 = document.getElementById("aImgSqr158").src;

    value25aSave158 = "zSqrArtSpecz158";

    localStorage.setItem(value25aSave158, sQz158);
};

function square159(){

    var sQz159 = document.getElementById("aImgSqr159").src;

    value25aSave159 = "zSqrArtSpecz159";

    localStorage.setItem(value25aSave159, sQz159);
};

function square160(){

    var sQz160 = document.getElementById("aImgSqr160").src;

    value25aSave160 = "zSqrArtSpecz160";

    localStorage.setItem(value25aSave160, sQz160);
};

function square161(){

    var sQz161 = document.getElementById("aImgSqr161").src;

    value25aSave161 = "zSqrArtSpecz161";

    localStorage.setItem(value25aSave161, sQz161);
};

function square162(){

    var sQz162 = document.getElementById("aImgSqr162").src;

    value25aSave162 = "zSqrArtSpecz162";

    localStorage.setItem(value25aSave162, sQz162);
};

function square163(){

    var sQz163 = document.getElementById("aImgSqr163").src;

    value25aSave163 = "zSqrArtSpecz163";

    localStorage.setItem(value25aSave163, sQz163);
};

function square164(){

    var sQz164 = document.getElementById("aImgSqr164").src;

    value25aSave164 = "zSqrArtSpecz164";

    localStorage.setItem(value25aSave164, sQz164);
};

function square165(){

    var sQz165 = document.getElementById("aImgSqr165").src;

    value25aSave165 = "zSqrArtSpecz165";

    localStorage.setItem(value25aSave165, sQz165);
};

function square166(){

    var sQz166 = document.getElementById("aImgSqr166").src;

    value25aSave166 = "zSqrArtSpecz166";

    localStorage.setItem(value25aSave166, sQz166);
};

function square167(){

    var sQz167 = document.getElementById("aImgSqr167").src;

    value25aSave167 = "zSqrArtSpecz167";

    localStorage.setItem(value25aSave167, sQz167);
};

function square168(){

    var sQz168 = document.getElementById("aImgSqr168").src;

    value25aSave168 = "zSqrArtSpecz168";

    localStorage.setItem(value25aSave168, sQz168);
};

function square169(){

    var sQz169 = document.getElementById("aImgSqr169").src;

    value25aSave169 = "zSqrArtSpecz169";

    localStorage.setItem(value25aSave169, sQz169);
};

function square170(){

    var sQz170 = document.getElementById("aImgSqr170").src;

    value25aSave170 = "zSqrArtSpecz170";

    localStorage.setItem(value25aSave170, sQz170);
};

function square171(){

    var sQz171 = document.getElementById("aImgSqr171").src;

    value25aSave171 = "zSqrArtSpecz171";

    localStorage.setItem(value25aSave171, sQz171);
};

function square172(){

    var sQz172 = document.getElementById("aImgSqr172").src;

    value25aSave172 = "zSqrArtSpecz172";

    localStorage.setItem(value25aSave172, sQz172);
};

function square173(){

    var sQz173 = document.getElementById("aImgSqr173").src;

    value25aSave173 = "zSqrArtSpecz173";

    localStorage.setItem(value25aSave173, sQz173);
};

function square174(){

    var sQz174 = document.getElementById("aImgSqr174").src;

    value25aSave174 = "zSqrArtSpecz174";

    localStorage.setItem(value25aSave174, sQz174);
};

function square175(){

    var sQz175 = document.getElementById("aImgSqr175").src;

    value25aSave175 = "zSqrArtSpecz175";

    localStorage.setItem(value25aSave175, sQz175);
};

function square176(){

    var sQz176 = document.getElementById("aImgSqr176").src;

    value25aSave176 = "zSqrArtSpecz176";

    localStorage.setItem(value25aSave176, sQz176);
};

function square177(){

    var sQz177 = document.getElementById("aImgSqr177").src;

    value25aSave177 = "zSqrArtSpecz177";

    localStorage.setItem(value25aSave177, sQz177);
};

function square178(){

    var sQz178 = document.getElementById("aImgSqr178").src;

    value25aSave178 = "zSqrArtSpecz178";

    localStorage.setItem(value25aSave178, sQz178);
};

function square179(){

    var sQz179 = document.getElementById("aImgSqr179").src;

    value25aSave179 = "zSqrArtSpecz179";

    localStorage.setItem(value25aSave179, sQz179);
};

function square180(){

    var sQz180 = document.getElementById("aImgSqr180").src;

    value25aSave180 = "zSqrArtSpecz180";

    localStorage.setItem(value25aSave180, sQz180);
};

function square181(){

    var sQz181 = document.getElementById("aImgSqr181").src;

    value25aSave181 = "zSqrArtSpecz181";

    localStorage.setItem(value25aSave181, sQz181);
};

function square182(){

    var sQz182 = document.getElementById("aImgSqr182").src;

    value25aSave182 = "zSqrArtSpecz182";

    localStorage.setItem(value25aSave182, sQz182);
};

function square183(){

    var sQz183 = document.getElementById("aImgSqr183").src;

    value25aSave183 = "zSqrArtSpecz183";

    localStorage.setItem(value25aSave183, sQz183);
};

function square184(){

    var sQz184 = document.getElementById("aImgSqr184").src;

    value25aSave184 = "zSqrArtSpecz184";

    localStorage.setItem(value25aSave184, sQz184);
};

function square185(){

    var sQz185 = document.getElementById("aImgSqr185").src;

    value25aSave185 = "zSqrArtSpecz185";

    localStorage.setItem(value25aSave185, sQz185);
};

function square186(){

    var sQz186 = document.getElementById("aImgSqr186").src;

    value25aSave186 = "zSqrArtSpecz186";

    localStorage.setItem(value25aSave186, sQz186);
};

function square187(){

    var sQz187 = document.getElementById("aImgSqr187").src;

    value25aSave187 = "zSqrArtSpecz187";

    localStorage.setItem(value25aSave187, sQz187);
};

function square188(){

    var sQz188 = document.getElementById("aImgSqr188").src;

    value25aSave188 = "zSqrArtSpecz188";

    localStorage.setItem(value25aSave188, sQz188);
};

function square189(){

    var sQz189 = document.getElementById("aImgSqr189").src;

    value25aSave189 = "zSqrArtSpecz189";

    localStorage.setItem(value25aSave189, sQz189);
};

function square190(){

    var sQz190 = document.getElementById("aImgSqr190").src;

    value25aSave190 = "zSqrArtSpecz190";

    localStorage.setItem(value25aSave190, sQz190);
};

function square191(){

    var sQz191 = document.getElementById("aImgSqr191").src;

    value25aSave191 = "zSqrArtSpecz191";

    localStorage.setItem(value25aSave191, sQz191);
};

function square192(){

    var sQz192 = document.getElementById("aImgSqr192").src;

    value25aSave192 = "zSqrArtSpecz192";

    localStorage.setItem(value25aSave192, sQz192);
};

function square193(){

    var sQz193 = document.getElementById("aImgSqr193").src;

    value25aSave193 = "zSqrArtSpecz193";

    localStorage.setItem(value25aSave193, sQz193);
};

function square194(){

    var sQz194 = document.getElementById("aImgSqr194").src;

    value25aSave194 = "zSqrArtSpecz194";

    localStorage.setItem(value25aSave194, sQz194);
};

function square195(){

    var sQz195 = document.getElementById("aImgSqr195").src;

    value25aSave195 = "zSqrArtSpecz195";

    localStorage.setItem(value25aSave195, sQz195);
};

function square196(){

    var sQz196 = document.getElementById("aImgSqr196").src;

    value25aSave196 = "zSqrArtSpecz196";

    localStorage.setItem(value25aSave196, sQz196);
};

function square197(){

    var sQz197 = document.getElementById("aImgSqr197").src;

    value25aSave197 = "zSqrArtSpecz197";

    localStorage.setItem(value25aSave197, sQz197);
};

function square198(){

    var sQz198 = document.getElementById("aImgSqr198").src;

    value25aSave198 = "zSqrArtSpecz198";

    localStorage.setItem(value25aSave198, sQz198);
};

function square199(){

    var sQz199 = document.getElementById("aImgSqr199").src;

    value25aSave199 = "zSqrArtSpecz199";

    localStorage.setItem(value25aSave199, sQz199);
};

function square200(){

    var sQz200 = document.getElementById("aImgSqr200").src;

    value25aSave200 = "zSqrArtSpecz200";

    localStorage.setItem(value25aSave200, sQz200);
};

function square201(){

    var sQz201 = document.getElementById("aImgSqr201").src;

    value25aSave201 = "zSqrArtSpecz201";

    localStorage.setItem(value25aSave201, sQz201);
};

function square202(){

    var sQz202 = document.getElementById("aImgSqr202").src;

    value25aSave202 = "zSqrArtSpecz202";

    localStorage.setItem(value25aSave202, sQz202);
};

function square203(){

    var sQz203 = document.getElementById("aImgSqr203").src;

    value25aSave203 = "zSqrArtSpecz203";

    localStorage.setItem(value25aSave203, sQz203);
};

function square204(){

    var sQz204 = document.getElementById("aImgSqr204").src;

    value25aSave204 = "zSqrArtSpecz204";

    localStorage.setItem(value25aSave204, sQz204);
};

function square205(){

    var sQz205 = document.getElementById("aImgSqr205").src;

    value25aSave205 = "zSqrArtSpecz205";

    localStorage.setItem(value25aSave205, sQz205);
};

function square206(){

    var sQz206 = document.getElementById("aImgSqr206").src;

    value25aSave206 = "zSqrArtSpecz206";

    localStorage.setItem(value25aSave206, sQz206);
};

function square207(){

    var sQz207 = document.getElementById("aImgSqr207").src;

    value25aSave207 = "zSqrArtSpecz207";

    localStorage.setItem(value25aSave207, sQz207);
};

function square208(){

    var sQz208 = document.getElementById("aImgSqr208").src;

    value25aSave208 = "zSqrArtSpecz208";

    localStorage.setItem(value25aSave208, sQz208);
};

function square209(){

    var sQz209 = document.getElementById("aImgSqr209").src;

    value25aSave209 = "zSqrArtSpecz209";

    localStorage.setItem(value25aSave209, sQz209);
};

function square210(){

    var sQz210 = document.getElementById("aImgSqr210").src;

    value25aSave210 = "zSqrArtSpecz210";

    localStorage.setItem(value25aSave210, sQz210);
};

function square211(){

    var sQz211 = document.getElementById("aImgSqr211").src;

    value25aSave211 = "zSqrArtSpecz211";

    localStorage.setItem(value25aSave211, sQz211);
};

function square212(){

    var sQz212 = document.getElementById("aImgSqr212").src;

    value25aSave212 = "zSqrArtSpecz212";

    localStorage.setItem(value25aSave212, sQz212);
};

function square213(){

    var sQz213 = document.getElementById("aImgSqr213").src;

    value25aSave213 = "zSqrArtSpecz213";

    localStorage.setItem(value25aSave213, sQz213);
};

function square214(){

    var sQz214 = document.getElementById("aImgSqr214").src;

    value25aSave214 = "zSqrArtSpecz214";

    localStorage.setItem(value25aSave214, sQz214);
};

function square215(){

    var sQz215 = document.getElementById("aImgSqr215").src;

    value25aSave215 = "zSqrArtSpecz215";

    localStorage.setItem(value25aSave215, sQz215);
};

function square216(){

    var sQz216 = document.getElementById("aImgSqr216").src;

    value25aSave216 = "zSqrArtSpecz216";

    localStorage.setItem(value25aSave216, sQz216);
};

function square217(){

    var sQz217 = document.getElementById("aImgSqr217").src;

    value25aSave217 = "zSqrArtSpecz217";

    localStorage.setItem(value25aSave217, sQz217);
};

function square218(){

    var sQz218 = document.getElementById("aImgSqr218").src;

    value25aSave218 = "zSqrArtSpecz218";

    localStorage.setItem(value25aSave218, sQz218);
};

function square219(){

    var sQz219 = document.getElementById("aImgSqr219").src;

    value25aSave219 = "zSqrArtSpecz219";

    localStorage.setItem(value25aSave219, sQz219);
};

function square220(){

    var sQz220 = document.getElementById("aImgSqr220").src;

    value25aSave220 = "zSqrArtSpecz220";

    localStorage.setItem(value25aSave220, sQz220);
};

function square221(){

    var sQz221 = document.getElementById("aImgSqr221").src;

    value25aSave221 = "zSqrArtSpecz221";

    localStorage.setItem(value25aSave221, sQz221);
};

function square222(){

    var sQz222 = document.getElementById("aImgSqr222").src;

    value25aSave222 = "zSqrArtSpecz222";

    localStorage.setItem(value25aSave222, sQz222);
};

function square223(){

    var sQz223 = document.getElementById("aImgSqr223").src;

    value25aSave223 = "zSqrArtSpecz223";

    localStorage.setItem(value25aSave223, sQz223);
};

function square224(){

    var sQz224 = document.getElementById("aImgSqr224").src;

    value25aSave224 = "zSqrArtSpecz224";

    localStorage.setItem(value25aSave224, sQz224);
};

function square225(){

    var sQz225 = document.getElementById("aImgSqr225").src;

    value25aSave225 = "zSqrArtSpecz225";

    localStorage.setItem(value25aSave225, sQz225);
};

function square226(){

    var sQz226 = document.getElementById("aImgSqr226").src;

    value25aSave226 = "zSqrArtSpecz226";

    localStorage.setItem(value25aSave226, sQz226);
};

function square227(){

    var sQz227 = document.getElementById("aImgSqr227").src;

    value25aSave227 = "zSqrArtSpecz227";

    localStorage.setItem(value25aSave227, sQz227);
};

function square228(){

    var sQz228 = document.getElementById("aImgSqr228").src;

    value25aSave228 = "zSqrArtSpecz228";

    localStorage.setItem(value25aSave228, sQz228);
};

function square229(){

    var sQz229 = document.getElementById("aImgSqr229").src;

    value25aSave229 = "zSqrArtSpecz229";

    localStorage.setItem(value25aSave229, sQz229);
};

function square230(){

    var sQz230 = document.getElementById("aImgSqr230").src;

    value25aSave230 = "zSqrArtSpecz230";

    localStorage.setItem(value25aSave230, sQz230);
};

function square231(){

    var sQz231 = document.getElementById("aImgSqr231").src;

    value25aSave231 = "zSqrArtSpecz231";

    localStorage.setItem(value25aSave231, sQz231);
};

function square232(){

    var sQz232 = document.getElementById("aImgSqr232").src;

    value25aSave232 = "zSqrArtSpecz232";

    localStorage.setItem(value25aSave232, sQz232);
};

function square233(){

    var sQz233 = document.getElementById("aImgSqr233").src;

    value25aSave233 = "zSqrArtSpecz233";

    localStorage.setItem(value25aSave233, sQz233);
};

function square234(){

    var sQz234 = document.getElementById("aImgSqr234").src;

    value25aSave234 = "zSqrArtSpecz234";

    localStorage.setItem(value25aSave234, sQz234);
};

function square235(){

    var sQz235 = document.getElementById("aImgSqr235").src;

    value25aSave235 = "zSqrArtSpecz235";

    localStorage.setItem(value25aSave235, sQz235);
};

function square236(){

    var sQz236 = document.getElementById("aImgSqr236").src;

    value25aSave236 = "zSqrArtSpecz236";

    localStorage.setItem(value25aSave236, sQz236);
};

function square237(){

    var sQz237 = document.getElementById("aImgSqr237").src;

    value25aSave237 = "zSqrArtSpecz237";

    localStorage.setItem(value25aSave237, sQz237);
};

function square238(){

    var sQz238 = document.getElementById("aImgSqr238").src;

    value25aSave238 = "zSqrArtSpecz238";

    localStorage.setItem(value25aSave238, sQz238);
};

function square239(){

    var sQz239 = document.getElementById("aImgSqr239").src;

    value25aSave239 = "zSqrArtSpecz239";

    localStorage.setItem(value25aSave239, sQz239);
};

function square240(){

    var sQz240 = document.getElementById("aImgSqr240").src;

    value25aSave240 = "zSqrArtSpecz240";

    localStorage.setItem(value25aSave240, sQz240);
};

function square241(){

    var sQz241 = document.getElementById("aImgSqr241").src;

    value25aSave241 = "zSqrArtSpecz241";

    localStorage.setItem(value25aSave241, sQz241);
};

function square242(){

    var sQz242 = document.getElementById("aImgSqr242").src;

    value25aSave242 = "zSqrArtSpecz242";

    localStorage.setItem(value25aSave242, sQz242);
};

function square243(){

    var sQz243 = document.getElementById("aImgSqr243").src;

    value25aSave243 = "zSqrArtSpecz243";

    localStorage.setItem(value25aSave243, sQz243);
};

function square244(){

    var sQz244 = document.getElementById("aImgSqr244").src;

    value25aSave244 = "zSqrArtSpecz244";

    localStorage.setItem(value25aSave244, sQz244);
};

function square245(){

    var sQz245 = document.getElementById("aImgSqr245").src;

    value25aSave245 = "zSqrArtSpecz245";

    localStorage.setItem(value25aSave245, sQz245);
};

function square246(){

    var sQz246 = document.getElementById("aImgSqr246").src;

    value25aSave246 = "zSqrArtSpecz246";

    localStorage.setItem(value25aSave246, sQz246);
};

function square247(){

    var sQz247 = document.getElementById("aImgSqr247").src;

    value25aSave247 = "zSqrArtSpecz247";

    localStorage.setItem(value25aSave247, sQz247);
};

function square248(){

    var sQz248 = document.getElementById("aImgSqr248").src;

    value25aSave248 = "zSqrArtSpecz248";

    localStorage.setItem(value25aSave248, sQz248);
};

function square249(){

    var sQz249 = document.getElementById("aImgSqr249").src;

    value25aSave249 = "zSqrArtSpecz249";

    localStorage.setItem(value25aSave249, sQz249);
};

function square250(){

    var sQz250 = document.getElementById("aImgSqr250").src;

    value25aSave250 = "zSqrArtSpecz250";

    localStorage.setItem(value25aSave250, sQz250);
};

function square251(){

    var sQz251 = document.getElementById("aImgSqr251").src;

    value25aSave251 = "zSqrArtSpecz251";

    localStorage.setItem(value25aSave251, sQz251);
};

function square252(){

    var sQz252 = document.getElementById("aImgSqr252").src;

    value25aSave252 = "zSqrArtSpecz252";

    localStorage.setItem(value25aSave252, sQz252);
};

function square253(){

    var sQz253 = document.getElementById("aImgSqr253").src;

    value25aSave253 = "zSqrArtSpecz253";

    localStorage.setItem(value25aSave253, sQz253);
};

function square254(){

    var sQz254 = document.getElementById("aImgSqr254").src;

    value25aSave254 = "zSqrArtSpecz254";

    localStorage.setItem(value25aSave254, sQz254);
};

function square255(){

    var sQz255 = document.getElementById("aImgSqr255").src;

    value25aSave255 = "zSqrArtSpecz255";

    localStorage.setItem(value25aSave255, sQz255);
};

function square256(){

    var sQz256 = document.getElementById("aImgSqr256").src;

    value25aSave256 = "zSqrArtSpecz256";

    localStorage.setItem(value25aSave256, sQz256);
};

function square257(){

    var sQz257 = document.getElementById("aImgSqr257").src;

    value25aSave257 = "zSqrArtSpecz257";

    localStorage.setItem(value25aSave257, sQz257);
};

function square258(){

    var sQz258 = document.getElementById("aImgSqr258").src;

    value25aSave258 = "zSqrArtSpecz258";

    localStorage.setItem(value25aSave258, sQz258);
};

function square259(){

    var sQz259 = document.getElementById("aImgSqr259").src;

    value25aSave259 = "zSqrArtSpecz259";

    localStorage.setItem(value25aSave259, sQz259);
};

function square260(){

    var sQz260 = document.getElementById("aImgSqr260").src;

    value25aSave260 = "zSqrArtSpecz260";

    localStorage.setItem(value25aSave260, sQz260);
};

function square261(){

    var sQz261 = document.getElementById("aImgSqr261").src;

    value25aSave261 = "zSqrArtSpecz261";

    localStorage.setItem(value25aSave261, sQz261);
};

function square262(){

    var sQz262 = document.getElementById("aImgSqr262").src;

    value25aSave262 = "zSqrArtSpecz262";

    localStorage.setItem(value25aSave262, sQz262);
};

function square263(){

    var sQz263 = document.getElementById("aImgSqr263").src;

    value25aSave263 = "zSqrArtSpecz263";

    localStorage.setItem(value25aSave263, sQz263);
};

function square264(){

    var sQz264 = document.getElementById("aImgSqr264").src;

    value25aSave264 = "zSqrArtSpecz264";

    localStorage.setItem(value25aSave264, sQz264);
};

function square265(){

    var sQz265 = document.getElementById("aImgSqr265").src;

    value25aSave265 = "zSqrArtSpecz265";

    localStorage.setItem(value25aSave265, sQz265);
};

function square266(){

    var sQz266 = document.getElementById("aImgSqr266").src;

    value25aSave266 = "zSqrArtSpecz266";

    localStorage.setItem(value25aSave266, sQz266);
};

function square267(){

    var sQz267 = document.getElementById("aImgSqr267").src;

    value25aSave267 = "zSqrArtSpecz267";

    localStorage.setItem(value25aSave267, sQz267);
};

function square268(){

    var sQz268 = document.getElementById("aImgSqr268").src;

    value25aSave268 = "zSqrArtSpecz268";

    localStorage.setItem(value25aSave268, sQz268);
};

function square269(){

    var sQz269 = document.getElementById("aImgSqr269").src;

    value25aSave269 = "zSqrArtSpecz269";

    localStorage.setItem(value25aSave269, sQz269);
};

function square270(){

    var sQz270 = document.getElementById("aImgSqr270").src;

    value25aSave270 = "zSqrArtSpecz270";

    localStorage.setItem(value25aSave270, sQz270);
};

function square271(){

    var sQz271 = document.getElementById("aImgSqr271").src;

    value25aSave271 = "zSqrArtSpecz271";

    localStorage.setItem(value25aSave271, sQz271);
};

function square272(){

    var sQz272 = document.getElementById("aImgSqr272").src;

    value25aSave272 = "zSqrArtSpecz272";

    localStorage.setItem(value25aSave272, sQz272);
};

function square273(){

    var sQz273 = document.getElementById("aImgSqr273").src;

    value25aSave273 = "zSqrArtSpecz273";

    localStorage.setItem(value25aSave273, sQz273);
};

function square274(){

    var sQz274 = document.getElementById("aImgSqr274").src;

    value25aSave274 = "zSqrArtSpecz274";

    localStorage.setItem(value25aSave274, sQz274);
};

function square275(){

    var sQz275 = document.getElementById("aImgSqr275").src;

    value25aSave275 = "zSqrArtSpecz275";

    localStorage.setItem(value25aSave275, sQz275);
};

function square276(){

    var sQz276 = document.getElementById("aImgSqr276").src;

    value25aSave276 = "zSqrArtSpecz276";

    localStorage.setItem(value25aSave276, sQz276);
};

function square277(){

    var sQz277 = document.getElementById("aImgSqr277").src;

    value25aSave277 = "zSqrArtSpecz277";

    localStorage.setItem(value25aSave277, sQz277);
};

function square278(){

    var sQz278 = document.getElementById("aImgSqr278").src;

    value25aSave278 = "zSqrArtSpecz278";

    localStorage.setItem(value25aSave278, sQz278);
};

function square279(){

    var sQz279 = document.getElementById("aImgSqr279").src;

    value25aSave279 = "zSqrArtSpecz279";

    localStorage.setItem(value25aSave279, sQz279);
};

function square280(){

    var sQz280 = document.getElementById("aImgSqr280").src;

    value25aSave280 = "zSqrArtSpecz280";

    localStorage.setItem(value25aSave280, sQz280);
};

function square281(){

    var sQz281 = document.getElementById("aImgSqr281").src;

    value25aSave281 = "zSqrArtSpecz281";

    localStorage.setItem(value25aSave281, sQz281);
};

function square282(){

    var sQz282 = document.getElementById("aImgSqr282").src;

    value25aSave282 = "zSqrArtSpecz282";

    localStorage.setItem(value25aSave282, sQz282);
};

function square283(){

    var sQz283 = document.getElementById("aImgSqr283").src;

    value25aSave283 = "zSqrArtSpecz283";

    localStorage.setItem(value25aSave283, sQz283);
};

function square284(){

    var sQz284 = document.getElementById("aImgSqr284").src;

    value25aSave284 = "zSqrArtSpecz284";

    localStorage.setItem(value25aSave284, sQz284);
};

function square285(){

    var sQz285 = document.getElementById("aImgSqr285").src;

    value25aSave285 = "zSqrArtSpecz285";

    localStorage.setItem(value25aSave285, sQz285);
};

function square286(){

    var sQz286 = document.getElementById("aImgSqr286").src;

    value25aSave286 = "zSqrArtSpecz286";

    localStorage.setItem(value25aSave286, sQz286);
};

function square287(){

    var sQz287 = document.getElementById("aImgSqr287").src;

    value25aSave287 = "zSqrArtSpecz287";

    localStorage.setItem(value25aSave287, sQz287);
};

function square288(){

    var sQz288 = document.getElementById("aImgSqr288").src;

    value25aSave288 = "zSqrArtSpecz288";

    localStorage.setItem(value25aSave288, sQz288);
};

function square289(){

    var sQz289 = document.getElementById("aImgSqr289").src;

    value25aSave289 = "zSqrArtSpecz289";

    localStorage.setItem(value25aSave289, sQz289);
};

function square290(){

    var sQz290 = document.getElementById("aImgSqr290").src;

    value25aSave290 = "zSqrArtSpecz290";

    localStorage.setItem(value25aSave290, sQz290);
};

function square291(){

    var sQz291 = document.getElementById("aImgSqr291").src;

    value25aSave291 = "zSqrArtSpecz291";

    localStorage.setItem(value25aSave291, sQz291);
};

function square292(){

    var sQz292 = document.getElementById("aImgSqr292").src;

    value25aSave292 = "zSqrArtSpecz292";

    localStorage.setItem(value25aSave292, sQz292);
};

function square293(){

    var sQz293 = document.getElementById("aImgSqr293").src;

    value25aSave293 = "zSqrArtSpecz293";

    localStorage.setItem(value25aSave293, sQz293);
};

function square294(){

    var sQz294 = document.getElementById("aImgSqr294").src;

    value25aSave294 = "zSqrArtSpecz294";

    localStorage.setItem(value25aSave294, sQz294);
};

function square295(){

    var sQz295 = document.getElementById("aImgSqr295").src;

    value25aSave295 = "zSqrArtSpecz295";

    localStorage.setItem(value25aSave295, sQz295);
};

function square296(){

    var sQz296 = document.getElementById("aImgSqr296").src;

    value25aSave296 = "zSqrArtSpecz296";

    localStorage.setItem(value25aSave296, sQz296);
};

function square297(){

    var sQz297 = document.getElementById("aImgSqr297").src;

    value25aSave297 = "zSqrArtSpecz297";

    localStorage.setItem(value25aSave297, sQz297);
};

function square298(){

    var sQz298 = document.getElementById("aImgSqr298").src;

    value25aSave298 = "zSqrArtSpecz298";

    localStorage.setItem(value25aSave298, sQz298);
};

function square299(){

    var sQz299 = document.getElementById("aImgSqr299").src;

    value25aSave299 = "zSqrArtSpecz299";

    localStorage.setItem(value25aSave299, sQz299);
};

function square300(){

    var sQz300 = document.getElementById("aImgSqr300").src;

    value25aSave300 = "zSqrArtSpecz300";

    localStorage.setItem(value25aSave300, sQz300);
};

function square301(){

    var sQz301 = document.getElementById("aImgSqr301").src;

    value25aSave301 = "zSqrArtSpecz301";

    localStorage.setItem(value25aSave301, sQz301);
};

function square302(){

    var sQz302 = document.getElementById("aImgSqr302").src;

    value25aSave302 = "zSqrArtSpecz302";

    localStorage.setItem(value25aSave302, sQz302);
};

function square303(){

    var sQz303 = document.getElementById("aImgSqr303").src;

    value25aSave303 = "zSqrArtSpecz303";

    localStorage.setItem(value25aSave303, sQz303);
};

function square304(){

    var sQz304 = document.getElementById("aImgSqr304").src;

    value25aSave304 = "zSqrArtSpecz304";

    localStorage.setItem(value25aSave304, sQz304);
};

function square305(){

    var sQz305 = document.getElementById("aImgSqr305").src;

    value25aSave305 = "zSqrArtSpecz305";

    localStorage.setItem(value25aSave305, sQz305);
};

function square306(){

    var sQz306 = document.getElementById("aImgSqr306").src;

    value25aSave306 = "zSqrArtSpecz306";

    localStorage.setItem(value25aSave306, sQz306);
};

function square307(){

    var sQz307 = document.getElementById("aImgSqr307").src;

    value25aSave307 = "zSqrArtSpecz307";

    localStorage.setItem(value25aSave307, sQz307);
};

function square308(){

    var sQz308 = document.getElementById("aImgSqr308").src;

    value25aSave308 = "zSqrArtSpecz308";

    localStorage.setItem(value25aSave308, sQz308);
};

function square309(){

    var sQz309 = document.getElementById("aImgSqr309").src;

    value25aSave309 = "zSqrArtSpecz309";

    localStorage.setItem(value25aSave309, sQz309);
};

function square310(){

    var sQz310 = document.getElementById("aImgSqr310").src;

    value25aSave310 = "zSqrArtSpecz310";

    localStorage.setItem(value25aSave310, sQz310);
};

function square311(){

    var sQz311 = document.getElementById("aImgSqr311").src;

    value25aSave311 = "zSqrArtSpecz311";

    localStorage.setItem(value25aSave311, sQz311);
};

function square312(){

    var sQz312 = document.getElementById("aImgSqr312").src;

    value25aSave312 = "zSqrArtSpecz312";

    localStorage.setItem(value25aSave312, sQz312);
};

function square313(){

    var sQz313 = document.getElementById("aImgSqr313").src;

    value25aSave313 = "zSqrArtSpecz313";

    localStorage.setItem(value25aSave313, sQz313);
};

function square314(){

    var sQz314 = document.getElementById("aImgSqr314").src;

    value25aSave314 = "zSqrArtSpecz314";

    localStorage.setItem(value25aSave314, sQz314);
};

function square315(){

    var sQz315 = document.getElementById("aImgSqr315").src;

    value25aSave315 = "zSqrArtSpecz315";

    localStorage.setItem(value25aSave315, sQz315);
};

function square316(){

    var sQz316 = document.getElementById("aImgSqr316").src;

    value25aSave316 = "zSqrArtSpecz316";

    localStorage.setItem(value25aSave316, sQz316);
};

function square317(){

    var sQz317 = document.getElementById("aImgSqr317").src;

    value25aSave317 = "zSqrArtSpecz317";

    localStorage.setItem(value25aSave317, sQz317);
};

function square318(){

    var sQz318 = document.getElementById("aImgSqr318").src;

    value25aSave318 = "zSqrArtSpecz318";

    localStorage.setItem(value25aSave318, sQz318);
};

function square319(){

    var sQz319 = document.getElementById("aImgSqr319").src;

    value25aSave319 = "zSqrArtSpecz319";

    localStorage.setItem(value25aSave319, sQz319);
};

function square320(){

    var sQz320 = document.getElementById("aImgSqr320").src;

    value25aSave320 = "zSqrArtSpecz320";

    localStorage.setItem(value25aSave320, sQz320);
};

function square321(){

    var sQz321 = document.getElementById("aImgSqr321").src;

    value25aSave321 = "zSqrArtSpecz321";

    localStorage.setItem(value25aSave321, sQz321);
};

function square322(){

    var sQz322 = document.getElementById("aImgSqr322").src;

    value25aSave322 = "zSqrArtSpecz322";

    localStorage.setItem(value25aSave322, sQz322);
};

function square323(){

    var sQz323 = document.getElementById("aImgSqr323").src;

    value25aSave323 = "zSqrArtSpecz323";

    localStorage.setItem(value25aSave323, sQz323);
};

function square324(){

    var sQz324 = document.getElementById("aImgSqr324").src;

    value25aSave324 = "zSqrArtSpecz324";

    localStorage.setItem(value25aSave324, sQz324);
};

function square325(){

    var sQz325 = document.getElementById("aImgSqr325").src;

    value25aSave325 = "zSqrArtSpecz325";

    localStorage.setItem(value25aSave325, sQz325);
};

function square326(){

    var sQz326 = document.getElementById("aImgSqr326").src;

    value25aSave326 = "zSqrArtSpecz326";

    localStorage.setItem(value25aSave326, sQz326);
};

function square327(){

    var sQz327 = document.getElementById("aImgSqr327").src;

    value25aSave327 = "zSqrArtSpecz327";

    localStorage.setItem(value25aSave327, sQz327);
};

function square328(){

    var sQz328 = document.getElementById("aImgSqr328").src;

    value25aSave328 = "zSqrArtSpecz328";

    localStorage.setItem(value25aSave328, sQz328);
};

function square329(){

    var sQz329 = document.getElementById("aImgSqr329").src;

    value25aSave329 = "zSqrArtSpecz329";

    localStorage.setItem(value25aSave329, sQz329);
};

function square330(){

    var sQz330 = document.getElementById("aImgSqr330").src;

    value25aSave330 = "zSqrArtSpecz330";

    localStorage.setItem(value25aSave330, sQz330);
};

function square331(){

    var sQz331 = document.getElementById("aImgSqr331").src;

    value25aSave331 = "zSqrArtSpecz331";

    localStorage.setItem(value25aSave331, sQz331);
};

function square332(){

    var sQz332 = document.getElementById("aImgSqr332").src;

    value25aSave332 = "zSqrArtSpecz332";

    localStorage.setItem(value25aSave332, sQz332);
};

function square333(){

    var sQz333 = document.getElementById("aImgSqr333").src;

    value25aSave333 = "zSqrArtSpecz333";

    localStorage.setItem(value25aSave333, sQz333);
};

function square334(){

    var sQz334 = document.getElementById("aImgSqr334").src;

    value25aSave334 = "zSqrArtSpecz334";

    localStorage.setItem(value25aSave334, sQz334);
};

function square335(){

    var sQz335 = document.getElementById("aImgSqr335").src;

    value25aSave335 = "zSqrArtSpecz335";

    localStorage.setItem(value25aSave335, sQz335);
};

function square336(){

    var sQz336 = document.getElementById("aImgSqr336").src;

    value25aSave336 = "zSqrArtSpecz336";

    localStorage.setItem(value25aSave336, sQz336);
};

function square337(){

    var sQz337 = document.getElementById("aImgSqr337").src;

    value25aSave337 = "zSqrArtSpecz337";

    localStorage.setItem(value25aSave337, sQz337);
};

function square338(){

    var sQz338 = document.getElementById("aImgSqr338").src;

    value25aSave338 = "zSqrArtSpecz338";

    localStorage.setItem(value25aSave338, sQz338);
};

function square339(){

    var sQz339 = document.getElementById("aImgSqr339").src;

    value25aSave339 = "zSqrArtSpecz339";

    localStorage.setItem(value25aSave339, sQz339);
};

function square340(){

    var sQz340 = document.getElementById("aImgSqr340").src;

    value25aSave340 = "zSqrArtSpecz340";

    localStorage.setItem(value25aSave340, sQz340);
};

function square341(){

    var sQz341 = document.getElementById("aImgSqr341").src;

    value25aSave341 = "zSqrArtSpecz341";

    localStorage.setItem(value25aSave341, sQz341);
};

function square342(){

    var sQz342 = document.getElementById("aImgSqr342").src;

    value25aSave342 = "zSqrArtSpecz342";

    localStorage.setItem(value25aSave342, sQz342);
};

function square343(){

    var sQz343 = document.getElementById("aImgSqr343").src;

    value25aSave343 = "zSqrArtSpecz343";

    localStorage.setItem(value25aSave343, sQz343);
};

function square344(){

    var sQz344 = document.getElementById("aImgSqr344").src;

    value25aSave344 = "zSqrArtSpecz344";

    localStorage.setItem(value25aSave344, sQz344);
};

function square345(){

    var sQz345 = document.getElementById("aImgSqr345").src;

    value25aSave345 = "zSqrArtSpecz345";

    localStorage.setItem(value25aSave345, sQz345);
};

function square346(){

    var sQz346 = document.getElementById("aImgSqr346").src;

    value25aSave346 = "zSqrArtSpecz346";

    localStorage.setItem(value25aSave346, sQz346);
};

function square347(){

    var sQz347 = document.getElementById("aImgSqr347").src;

    value25aSave347 = "zSqrArtSpecz347";

    localStorage.setItem(value25aSave347, sQz347);
};

function square348(){

    var sQz348 = document.getElementById("aImgSqr348").src;

    value25aSave348 = "zSqrArtSpecz348";

    localStorage.setItem(value25aSave348, sQz348);
};

function square349(){

    var sQz349 = document.getElementById("aImgSqr349").src;

    value25aSave349 = "zSqrArtSpecz349";

    localStorage.setItem(value25aSave349, sQz349);
};

function square350(){

    var sQz350 = document.getElementById("aImgSqr350").src;

    value25aSave350 = "zSqrArtSpecz350";

    localStorage.setItem(value25aSave350, sQz350);
};

function square351(){

    var sQz351 = document.getElementById("aImgSqr351").src;

    value25aSave351 = "zSqrArtSpecz351";

    localStorage.setItem(value25aSave351, sQz351);
};

function square352(){

    var sQz352 = document.getElementById("aImgSqr352").src;

    value25aSave352 = "zSqrArtSpecz352";

    localStorage.setItem(value25aSave352, sQz352);
};

function square353(){

    var sQz353 = document.getElementById("aImgSqr353").src;

    value25aSave353 = "zSqrArtSpecz353";

    localStorage.setItem(value25aSave353, sQz353);
};

function square354(){

    var sQz354 = document.getElementById("aImgSqr354").src;

    value25aSave354 = "zSqrArtSpecz354";

    localStorage.setItem(value25aSave354, sQz354);
};

function square355(){

    var sQz355 = document.getElementById("aImgSqr355").src;

    value25aSave355 = "zSqrArtSpecz355";

    localStorage.setItem(value25aSave355, sQz355);
};

function square356(){

    var sQz356 = document.getElementById("aImgSqr356").src;

    value25aSave356 = "zSqrArtSpecz356";

    localStorage.setItem(value25aSave356, sQz356);
};

function square357(){

    var sQz357 = document.getElementById("aImgSqr357").src;

    value25aSave357 = "zSqrArtSpecz357";

    localStorage.setItem(value25aSave357, sQz357);
};

function square358(){

    var sQz358 = document.getElementById("aImgSqr358").src;

    value25aSave358 = "zSqrArtSpecz358";

    localStorage.setItem(value25aSave358, sQz358);
};

function square359(){

    var sQz359 = document.getElementById("aImgSqr359").src;

    value25aSave359 = "zSqrArtSpecz359";

    localStorage.setItem(value25aSave359, sQz359);
};

function square360(){

    var sQz360 = document.getElementById("aImgSqr360").src;

    value25aSave360 = "zSqrArtSpecz360";

    localStorage.setItem(value25aSave360, sQz360);
};

function square361(){

    var sQz361 = document.getElementById("aImgSqr361").src;

    value25aSave361 = "zSqrArtSpecz361";

    localStorage.setItem(value25aSave361, sQz361);
};

function square362(){

    var sQz362 = document.getElementById("aImgSqr362").src;

    value25aSave362 = "zSqrArtSpecz362";

    localStorage.setItem(value25aSave362, sQz362);
};

function square363(){

    var sQz363 = document.getElementById("aImgSqr363").src;

    value25aSave363 = "zSqrArtSpecz363";

    localStorage.setItem(value25aSave363, sQz363);
};

function square364(){

    var sQz364 = document.getElementById("aImgSqr364").src;

    value25aSave364 = "zSqrArtSpecz364";

    localStorage.setItem(value25aSave364, sQz364);
};

function square365(){

    var sQz365 = document.getElementById("aImgSqr365").src;

    value25aSave365 = "zSqrArtSpecz365";

    localStorage.setItem(value25aSave365, sQz365);
};

function square366(){

    var sQz366 = document.getElementById("aImgSqr366").src;

    value25aSave366 = "zSqrArtSpecz366";

    localStorage.setItem(value25aSave366, sQz366);
};

function square367(){

    var sQz367 = document.getElementById("aImgSqr367").src;

    value25aSave367 = "zSqrArtSpecz367";

    localStorage.setItem(value25aSave367, sQz367);
};

function square368(){

    var sQz368 = document.getElementById("aImgSqr368").src;

    value25aSave368 = "zSqrArtSpecz368";

    localStorage.setItem(value25aSave368, sQz368);
};

function square369(){

    var sQz369 = document.getElementById("aImgSqr369").src;

    value25aSave369 = "zSqrArtSpecz369";

    localStorage.setItem(value25aSave369, sQz369);
};

function square370(){

    var sQz370 = document.getElementById("aImgSqr370").src;

    value25aSave370 = "zSqrArtSpecz370";

    localStorage.setItem(value25aSave370, sQz370);
};

function square371(){

    var sQz371 = document.getElementById("aImgSqr371").src;

    value25aSave371 = "zSqrArtSpecz371";

    localStorage.setItem(value25aSave371, sQz371);
};

function square372(){

    var sQz372 = document.getElementById("aImgSqr372").src;

    value25aSave372 = "zSqrArtSpecz372";

    localStorage.setItem(value25aSave372, sQz372);
};

function square373(){

    var sQz373 = document.getElementById("aImgSqr373").src;

    value25aSave373 = "zSqrArtSpecz373";

    localStorage.setItem(value25aSave373, sQz373);
};

function square374(){

    var sQz374 = document.getElementById("aImgSqr374").src;

    value25aSave374 = "zSqrArtSpecz374";

    localStorage.setItem(value25aSave374, sQz374);
};

function square375(){

    var sQz375 = document.getElementById("aImgSqr375").src;

    value25aSave375 = "zSqrArtSpecz375";

    localStorage.setItem(value25aSave375, sQz375);
};

function square376(){

    var sQz376 = document.getElementById("aImgSqr376").src;

    value25aSave376 = "zSqrArtSpecz376";

    localStorage.setItem(value25aSave376, sQz376);
};

function square377(){

    var sQz377 = document.getElementById("aImgSqr377").src;

    value25aSave377 = "zSqrArtSpecz377";

    localStorage.setItem(value25aSave377, sQz377);
};

function square378(){

    var sQz378 = document.getElementById("aImgSqr378").src;

    value25aSave378 = "zSqrArtSpecz378";

    localStorage.setItem(value25aSave378, sQz378);
};

function square379(){

    var sQz379 = document.getElementById("aImgSqr379").src;

    value25aSave379 = "zSqrArtSpecz379";

    localStorage.setItem(value25aSave379, sQz379);
};

function square380(){

    var sQz380 = document.getElementById("aImgSqr380").src;

    value25aSave380 = "zSqrArtSpecz380";

    localStorage.setItem(value25aSave380, sQz380);
};

function square381(){

    var sQz381 = document.getElementById("aImgSqr381").src;

    value25aSave381 = "zSqrArtSpecz381";

    localStorage.setItem(value25aSave381, sQz381);
};

function square382(){

    var sQz382 = document.getElementById("aImgSqr382").src;

    value25aSave382 = "zSqrArtSpecz382";

    localStorage.setItem(value25aSave382, sQz382);
};

function square383(){

    var sQz383 = document.getElementById("aImgSqr383").src;

    value25aSave383 = "zSqrArtSpecz383";

    localStorage.setItem(value25aSave383, sQz383);
};

function square384(){

    var sQz384 = document.getElementById("aImgSqr384").src;

    value25aSave384 = "zSqrArtSpecz384";

    localStorage.setItem(value25aSave384, sQz384);
};

function square385(){

    var sQz385 = document.getElementById("aImgSqr385").src;

    value25aSave385 = "zSqrArtSpecz385";

    localStorage.setItem(value25aSave385, sQz385);
};

function square386(){

    var sQz386 = document.getElementById("aImgSqr386").src;

    value25aSave386 = "zSqrArtSpecz386";

    localStorage.setItem(value25aSave386, sQz386);
};

function square387(){

    var sQz387 = document.getElementById("aImgSqr387").src;

    value25aSave387 = "zSqrArtSpecz387";

    localStorage.setItem(value25aSave387, sQz387);
};

function square388(){

    var sQz388 = document.getElementById("aImgSqr388").src;

    value25aSave388 = "zSqrArtSpecz388";

    localStorage.setItem(value25aSave388, sQz388);
};

function square389(){

    var sQz389 = document.getElementById("aImgSqr389").src;

    value25aSave389 = "zSqrArtSpecz389";

    localStorage.setItem(value25aSave389, sQz389);
};

function square390(){

    var sQz390 = document.getElementById("aImgSqr390").src;

    value25aSave390 = "zSqrArtSpecz390";

    localStorage.setItem(value25aSave390, sQz390);
};

function square391(){

    var sQz391 = document.getElementById("aImgSqr391").src;

    value25aSave391 = "zSqrArtSpecz391";

    localStorage.setItem(value25aSave391, sQz391);
};

function square392(){

    var sQz392 = document.getElementById("aImgSqr392").src;

    value25aSave392 = "zSqrArtSpecz392";

    localStorage.setItem(value25aSave392, sQz392);
};

function square393(){

    var sQz393 = document.getElementById("aImgSqr393").src;

    value25aSave393 = "zSqrArtSpecz393";

    localStorage.setItem(value25aSave393, sQz393);
};

function square394(){

    var sQz394 = document.getElementById("aImgSqr394").src;

    value25aSave394 = "zSqrArtSpecz394";

    localStorage.setItem(value25aSave394, sQz394);
};

function square395(){

    var sQz395 = document.getElementById("aImgSqr395").src;

    value25aSave395 = "zSqrArtSpecz395";

    localStorage.setItem(value25aSave395, sQz395);
};

function square396(){

    var sQz396 = document.getElementById("aImgSqr396").src;

    value25aSave396 = "zSqrArtSpecz396";

    localStorage.setItem(value25aSave396, sQz396);
};

function square397(){

    var sQz397 = document.getElementById("aImgSqr397").src;

    value25aSave397 = "zSqrArtSpecz397";

    localStorage.setItem(value25aSave397, sQz397);
};

function square398(){

    var sQz398 = document.getElementById("aImgSqr398").src;

    value25aSave398 = "zSqrArtSpecz398";

    localStorage.setItem(value25aSave398, sQz398);
};

function square399(){

    var sQz399 = document.getElementById("aImgSqr399").src;

    value25aSave399 = "zSqrArtSpecz399";

    localStorage.setItem(value25aSave399, sQz399);
};

function square400(){

    var sQz400 = document.getElementById("aImgSqr400").src;

    value25aSave400 = "zSqrArtSpecz400";

    localStorage.setItem(value25aSave400, sQz400);
};

function square401(){

    var sQz401 = document.getElementById("aImgSqr401").src;

    value25aSave401 = "zSqrArtSpecz401";

    localStorage.setItem(value25aSave401, sQz401);
};

function square402(){

    var sQz402 = document.getElementById("aImgSqr402").src;

    value25aSave402 = "zSqrArtSpecz402";

    localStorage.setItem(value25aSave402, sQz402);
};

function square403(){

    var sQz403 = document.getElementById("aImgSqr403").src;

    value25aSave403 = "zSqrArtSpecz403";

    localStorage.setItem(value25aSave403, sQz403);
};

function square404(){

    var sQz404 = document.getElementById("aImgSqr404").src;

    value25aSave404 = "zSqrArtSpecz404";

    localStorage.setItem(value25aSave404, sQz404);
};

function square405(){

    var sQz405 = document.getElementById("aImgSqr405").src;

    value25aSave405 = "zSqrArtSpecz405";

    localStorage.setItem(value25aSave405, sQz405);
};

function square406(){

    var sQz406 = document.getElementById("aImgSqr406").src;

    value25aSave406 = "zSqrArtSpecz406";

    localStorage.setItem(value25aSave406, sQz406);
};

function square407(){

    var sQz407 = document.getElementById("aImgSqr407").src;

    value25aSave407 = "zSqrArtSpecz407";

    localStorage.setItem(value25aSave407, sQz407);
};

function square408(){

    var sQz408 = document.getElementById("aImgSqr408").src;

    value25aSave408 = "zSqrArtSpecz408";

    localStorage.setItem(value25aSave408, sQz408);
};

function square409(){

    var sQz409 = document.getElementById("aImgSqr409").src;

    value25aSave409 = "zSqrArtSpecz409";

    localStorage.setItem(value25aSave409, sQz409);
};

function square410(){

    var sQz410 = document.getElementById("aImgSqr410").src;

    value25aSave410 = "zSqrArtSpecz410";

    localStorage.setItem(value25aSave410, sQz410);
};

function square411(){

    var sQz411 = document.getElementById("aImgSqr411").src;

    value25aSave411 = "zSqrArtSpecz411";

    localStorage.setItem(value25aSave411, sQz411);
};

function square412(){

    var sQz412 = document.getElementById("aImgSqr412").src;

    value25aSave412 = "zSqrArtSpecz412";

    localStorage.setItem(value25aSave412, sQz412);
};

function square413(){

    var sQz413 = document.getElementById("aImgSqr413").src;

    value25aSave413 = "zSqrArtSpecz413";

    localStorage.setItem(value25aSave413, sQz413);
};

function square414(){

    var sQz414 = document.getElementById("aImgSqr414").src;

    value25aSave414 = "zSqrArtSpecz414";

    localStorage.setItem(value25aSave414, sQz414);
};

function square415(){

    var sQz415 = document.getElementById("aImgSqr415").src;

    value25aSave415 = "zSqrArtSpecz415";

    localStorage.setItem(value25aSave415, sQz415);
};

function square416(){

    var sQz416 = document.getElementById("aImgSqr416").src;

    value25aSave416 = "zSqrArtSpecz416";

    localStorage.setItem(value25aSave416, sQz416);
};

function square417(){

    var sQz417 = document.getElementById("aImgSqr417").src;

    value25aSave417 = "zSqrArtSpecz417";

    localStorage.setItem(value25aSave417, sQz417);
};

function square418(){

    var sQz418 = document.getElementById("aImgSqr418").src;

    value25aSave418 = "zSqrArtSpecz418";

    localStorage.setItem(value25aSave418, sQz418);
};

function square419(){

    var sQz419 = document.getElementById("aImgSqr419").src;

    value25aSave419 = "zSqrArtSpecz419";

    localStorage.setItem(value25aSave419, sQz419);
};

function square420(){

    var sQz420 = document.getElementById("aImgSqr420").src;

    value25aSave420 = "zSqrArtSpecz420";

    localStorage.setItem(value25aSave420, sQz420);
};

function square421(){

    var sQz421 = document.getElementById("aImgSqr421").src;

    value25aSave421 = "zSqrArtSpecz421";

    localStorage.setItem(value25aSave421, sQz421);
};

function square422(){

    var sQz422 = document.getElementById("aImgSqr422").src;

    value25aSave422 = "zSqrArtSpecz422";

    localStorage.setItem(value25aSave422, sQz422);
};

function square423(){

    var sQz423 = document.getElementById("aImgSqr423").src;

    value25aSave423 = "zSqrArtSpecz423";

    localStorage.setItem(value25aSave423, sQz423);
};

function square424(){

    var sQz424 = document.getElementById("aImgSqr424").src;

    value25aSave424 = "zSqrArtSpecz424";

    localStorage.setItem(value25aSave424, sQz424);
};

function square425(){

    var sQz425 = document.getElementById("aImgSqr425").src;

    value25aSave425 = "zSqrArtSpecz425";

    localStorage.setItem(value25aSave425, sQz425);
};

function square426(){

    var sQz426 = document.getElementById("aImgSqr426").src;

    value25aSave426 = "zSqrArtSpecz426";

    localStorage.setItem(value25aSave426, sQz426);
};

function square427(){

    var sQz427 = document.getElementById("aImgSqr427").src;

    value25aSave427 = "zSqrArtSpecz427";

    localStorage.setItem(value25aSave427, sQz427);
};

function square428(){

    var sQz428 = document.getElementById("aImgSqr428").src;

    value25aSave428 = "zSqrArtSpecz428";

    localStorage.setItem(value25aSave428, sQz428);
};

function square429(){

    var sQz429 = document.getElementById("aImgSqr429").src;

    value25aSave429 = "zSqrArtSpecz429";

    localStorage.setItem(value25aSave429, sQz429);
};

function square430(){

    var sQz430 = document.getElementById("aImgSqr430").src;

    value25aSave430 = "zSqrArtSpecz430";

    localStorage.setItem(value25aSave430, sQz430);
};

function square431(){

    var sQz431 = document.getElementById("aImgSqr431").src;

    value25aSave431 = "zSqrArtSpecz431";

    localStorage.setItem(value25aSave431, sQz431);
};

function square432(){

    var sQz432 = document.getElementById("aImgSqr432").src;

    value25aSave432 = "zSqrArtSpecz432";

    localStorage.setItem(value25aSave432, sQz432);
};

function square433(){

    var sQz433 = document.getElementById("aImgSqr433").src;

    value25aSave433 = "zSqrArtSpecz433";

    localStorage.setItem(value25aSave433, sQz433);
};

function square434(){

    var sQz434 = document.getElementById("aImgSqr434").src;

    value25aSave434 = "zSqrArtSpecz434";

    localStorage.setItem(value25aSave434, sQz434);
};

function square435(){

    var sQz435 = document.getElementById("aImgSqr435").src;

    value25aSave435 = "zSqrArtSpecz435";

    localStorage.setItem(value25aSave435, sQz435);
};

function square436(){

    var sQz436 = document.getElementById("aImgSqr436").src;

    value25aSave436 = "zSqrArtSpecz436";

    localStorage.setItem(value25aSave436, sQz436);
};

function square437(){

    var sQz437 = document.getElementById("aImgSqr437").src;

    value25aSave437 = "zSqrArtSpecz437";

    localStorage.setItem(value25aSave437, sQz437);
};

function square438(){

    var sQz438 = document.getElementById("aImgSqr438").src;

    value25aSave438 = "zSqrArtSpecz438";

    localStorage.setItem(value25aSave438, sQz438);
};

function square439(){

    var sQz439 = document.getElementById("aImgSqr439").src;

    value25aSave439 = "zSqrArtSpecz439";

    localStorage.setItem(value25aSave439, sQz439);
};

function square440(){

    var sQz440 = document.getElementById("aImgSqr440").src;

    value25aSave440 = "zSqrArtSpecz440";

    localStorage.setItem(value25aSave440, sQz440);
};

function square441(){

    var sQz441 = document.getElementById("aImgSqr441").src;

    value25aSave441 = "zSqrArtSpecz441";

    localStorage.setItem(value25aSave441, sQz441);
};

function square442(){

    var sQz442 = document.getElementById("aImgSqr442").src;

    value25aSave442 = "zSqrArtSpecz442";

    localStorage.setItem(value25aSave442, sQz442);
};

function square443(){

    var sQz443 = document.getElementById("aImgSqr443").src;

    value25aSave443 = "zSqrArtSpecz443";

    localStorage.setItem(value25aSave443, sQz443);
};

function square444(){

    var sQz444 = document.getElementById("aImgSqr444").src;

    value25aSave444 = "zSqrArtSpecz444";

    localStorage.setItem(value25aSave444, sQz444);
};

function square445(){

    var sQz445 = document.getElementById("aImgSqr445").src;

    value25aSave445 = "zSqrArtSpecz445";

    localStorage.setItem(value25aSave445, sQz445);
};

function square446(){

    var sQz446 = document.getElementById("aImgSqr446").src;

    value25aSave446 = "zSqrArtSpecz446";

    localStorage.setItem(value25aSave446, sQz446);
};

function square447(){

    var sQz447 = document.getElementById("aImgSqr447").src;

    value25aSave447 = "zSqrArtSpecz447";

    localStorage.setItem(value25aSave447, sQz447);
};

function square448(){

    var sQz448 = document.getElementById("aImgSqr448").src;

    value25aSave448 = "zSqrArtSpecz448";

    localStorage.setItem(value25aSave448, sQz448);
};

function square449(){

    var sQz449 = document.getElementById("aImgSqr449").src;

    value25aSave449 = "zSqrArtSpecz449";

    localStorage.setItem(value25aSave449, sQz449);
};

function square450(){

    var sQz450 = document.getElementById("aImgSqr450").src;

    value25aSave450 = "zSqrArtSpecz450";

    localStorage.setItem(value25aSave450, sQz450);
};

function square451(){

    var sQz451 = document.getElementById("aImgSqr451").src;

    value25aSave451 = "zSqrArtSpecz451";

    localStorage.setItem(value25aSave451, sQz451);
};

function square452(){

    var sQz452 = document.getElementById("aImgSqr452").src;

    value25aSave452 = "zSqrArtSpecz452";

    localStorage.setItem(value25aSave452, sQz452);
};

function square453(){

    var sQz453 = document.getElementById("aImgSqr453").src;

    value25aSave453 = "zSqrArtSpecz453";

    localStorage.setItem(value25aSave453, sQz453);
};

function square454(){

    var sQz454 = document.getElementById("aImgSqr454").src;

    value25aSave454 = "zSqrArtSpecz454";

    localStorage.setItem(value25aSave454, sQz454);
};

function square455(){

    var sQz455 = document.getElementById("aImgSqr455").src;

    value25aSave455 = "zSqrArtSpecz455";

    localStorage.setItem(value25aSave455, sQz455);
};

function square456(){

    var sQz456 = document.getElementById("aImgSqr456").src;

    value25aSave456 = "zSqrArtSpecz456";

    localStorage.setItem(value25aSave456, sQz456);
};

function square457(){

    var sQz457 = document.getElementById("aImgSqr457").src;

    value25aSave457 = "zSqrArtSpecz457";

    localStorage.setItem(value25aSave457, sQz457);
};

function square458(){

    var sQz458 = document.getElementById("aImgSqr458").src;

    value25aSave458 = "zSqrArtSpecz458";

    localStorage.setItem(value25aSave458, sQz458);
};

function square459(){

    var sQz459 = document.getElementById("aImgSqr459").src;

    value25aSave459 = "zSqrArtSpecz459";

    localStorage.setItem(value25aSave459, sQz459);
};

function square460(){

    var sQz460 = document.getElementById("aImgSqr460").src;

    value25aSave460 = "zSqrArtSpecz460";

    localStorage.setItem(value25aSave460, sQz460);
};

function square461(){

    var sQz461 = document.getElementById("aImgSqr461").src;

    value25aSave461 = "zSqrArtSpecz461";

    localStorage.setItem(value25aSave461, sQz461);
};

function square462(){

    var sQz462 = document.getElementById("aImgSqr462").src;

    value25aSave462 = "zSqrArtSpecz462";

    localStorage.setItem(value25aSave462, sQz462);
};

function square463(){

    var sQz463 = document.getElementById("aImgSqr463").src;

    value25aSave463 = "zSqrArtSpecz463";

    localStorage.setItem(value25aSave463, sQz463);
};

function square464(){

    var sQz464 = document.getElementById("aImgSqr464").src;

    value25aSave464 = "zSqrArtSpecz464";

    localStorage.setItem(value25aSave464, sQz464);
};

function square465(){

    var sQz465 = document.getElementById("aImgSqr465").src;

    value25aSave465 = "zSqrArtSpecz465";

    localStorage.setItem(value25aSave465, sQz465);
};

function square466(){

    var sQz466 = document.getElementById("aImgSqr466").src;

    value25aSave466 = "zSqrArtSpecz466";

    localStorage.setItem(value25aSave466, sQz466);
};

function square467(){

    var sQz467 = document.getElementById("aImgSqr467").src;

    value25aSave467 = "zSqrArtSpecz467";

    localStorage.setItem(value25aSave467, sQz467);
};

function square468(){

    var sQz468 = document.getElementById("aImgSqr468").src;

    value25aSave468 = "zSqrArtSpecz468";

    localStorage.setItem(value25aSave468, sQz468);
};

function square469(){

    var sQz469 = document.getElementById("aImgSqr469").src;

    value25aSave469 = "zSqrArtSpecz469";

    localStorage.setItem(value25aSave469, sQz469);
};

function square470(){

    var sQz470 = document.getElementById("aImgSqr470").src;

    value25aSave470 = "zSqrArtSpecz470";

    localStorage.setItem(value25aSave470, sQz470);
};

function square471(){

    var sQz471 = document.getElementById("aImgSqr471").src;

    value25aSave471 = "zSqrArtSpecz471";

    localStorage.setItem(value25aSave471, sQz471);
};

function square472(){

    var sQz472 = document.getElementById("aImgSqr472").src;

    value25aSave472 = "zSqrArtSpecz472";

    localStorage.setItem(value25aSave472, sQz472);
};

function square473(){

    var sQz473 = document.getElementById("aImgSqr473").src;

    value25aSave473 = "zSqrArtSpecz473";

    localStorage.setItem(value25aSave473, sQz473);
};

function square474(){

    var sQz474 = document.getElementById("aImgSqr474").src;

    value25aSave474 = "zSqrArtSpecz474";

    localStorage.setItem(value25aSave474, sQz474);
};

function square475(){

    var sQz475 = document.getElementById("aImgSqr475").src;

    value25aSave475 = "zSqrArtSpecz475";

    localStorage.setItem(value25aSave475, sQz475);
};

function square476(){

    var sQz476 = document.getElementById("aImgSqr476").src;

    value25aSave476 = "zSqrArtSpecz476";

    localStorage.setItem(value25aSave476, sQz476);
};

function square477(){

    var sQz477 = document.getElementById("aImgSqr477").src;

    value25aSave477 = "zSqrArtSpecz477";

    localStorage.setItem(value25aSave477, sQz477);
};

function square478(){

    var sQz478 = document.getElementById("aImgSqr478").src;

    value25aSave478 = "zSqrArtSpecz478";

    localStorage.setItem(value25aSave478, sQz478);
};

function square479(){

    var sQz479 = document.getElementById("aImgSqr479").src;

    value25aSave479 = "zSqrArtSpecz479";

    localStorage.setItem(value25aSave479, sQz479);
};

function square480(){

    var sQz480 = document.getElementById("aImgSqr480").src;

    value25aSave480 = "zSqrArtSpecz480";

    localStorage.setItem(value25aSave480, sQz480);
};

function square481(){

    var sQz481 = document.getElementById("aImgSqr481").src;

    value25aSave481 = "zSqrArtSpecz481";

    localStorage.setItem(value25aSave481, sQz481);
};

function square482(){

    var sQz482 = document.getElementById("aImgSqr482").src;

    value25aSave482 = "zSqrArtSpecz482";

    localStorage.setItem(value25aSave482, sQz482);
};

function square483(){

    var sQz483 = document.getElementById("aImgSqr483").src;

    value25aSave483 = "zSqrArtSpecz483";

    localStorage.setItem(value25aSave483, sQz483);
};

function square484(){

    var sQz484 = document.getElementById("aImgSqr484").src;

    value25aSave484 = "zSqrArtSpecz484";

    localStorage.setItem(value25aSave484, sQz484);
};

function square485(){

    var sQz485 = document.getElementById("aImgSqr485").src;

    value25aSave485 = "zSqrArtSpecz485";

    localStorage.setItem(value25aSave485, sQz485);
};

function square486(){

    var sQz486 = document.getElementById("aImgSqr486").src;

    value25aSave486 = "zSqrArtSpecz486";

    localStorage.setItem(value25aSave486, sQz486);
};

function square487(){

    var sQz487 = document.getElementById("aImgSqr487").src;

    value25aSave487 = "zSqrArtSpecz487";

    localStorage.setItem(value25aSave487, sQz487);
};

function square488(){

    var sQz488 = document.getElementById("aImgSqr488").src;

    value25aSave488 = "zSqrArtSpecz488";

    localStorage.setItem(value25aSave488, sQz488);
};

function square489(){

    var sQz489 = document.getElementById("aImgSqr489").src;

    value25aSave489 = "zSqrArtSpecz489";

    localStorage.setItem(value25aSave489, sQz489);
};

function square490(){

    var sQz490 = document.getElementById("aImgSqr490").src;

    value25aSave490 = "zSqrArtSpecz490";

    localStorage.setItem(value25aSave490, sQz490);
};

function square491(){

    var sQz491 = document.getElementById("aImgSqr491").src;

    value25aSave491 = "zSqrArtSpecz491";

    localStorage.setItem(value25aSave491, sQz491);
};

function square492(){

    var sQz492 = document.getElementById("aImgSqr492").src;

    value25aSave492 = "zSqrArtSpecz492";

    localStorage.setItem(value25aSave492, sQz492);
};

function square493(){

    var sQz493 = document.getElementById("aImgSqr493").src;

    value25aSave493 = "zSqrArtSpecz493";

    localStorage.setItem(value25aSave493, sQz493);
};

function square494(){

    var sQz494 = document.getElementById("aImgSqr494").src;

    value25aSave494 = "zSqrArtSpecz494";

    localStorage.setItem(value25aSave494, sQz494);
};

function square495(){

    var sQz495 = document.getElementById("aImgSqr495").src;

    value25aSave495 = "zSqrArtSpecz495";

    localStorage.setItem(value25aSave495, sQz495);
};

function square496(){

    var sQz496 = document.getElementById("aImgSqr496").src;

    value25aSave496 = "zSqrArtSpecz496";

    localStorage.setItem(value25aSave496, sQz496);
};

function square497(){

    var sQz497 = document.getElementById("aImgSqr497").src;

    value25aSave497 = "zSqrArtSpecz497";

    localStorage.setItem(value25aSave497, sQz497);
};

function square498(){

    var sQz498 = document.getElementById("aImgSqr498").src;

    value25aSave498 = "zSqrArtSpecz498";

    localStorage.setItem(value25aSave498, sQz498);
};

function square499(){

    var sQz499 = document.getElementById("aImgSqr499").src;

    value25aSave499 = "zSqrArtSpecz499";

    localStorage.setItem(value25aSave499, sQz499);
};

function square500(){

    var sQz500 = document.getElementById("aImgSqr500").src;

    value25aSave500 = "zSqrArtSpecz500";

    localStorage.setItem(value25aSave500, sQz500);
};

function square501(){

    var sQz501 = document.getElementById("aImgSqr501").src;

    value25aSave501 = "zSqrArtSpecz501";

    localStorage.setItem(value25aSave501, sQz501);
};

function square502(){

    var sQz502 = document.getElementById("aImgSqr502").src;

    value25aSave502 = "zSqrArtSpecz502";

    localStorage.setItem(value25aSave502, sQz502);
};

function square503(){

    var sQz503 = document.getElementById("aImgSqr503").src;

    value25aSave503 = "zSqrArtSpecz503";

    localStorage.setItem(value25aSave503, sQz503);
};

function square504(){

    var sQz504 = document.getElementById("aImgSqr504").src;

    value25aSave504 = "zSqrArtSpecz504";

    localStorage.setItem(value25aSave504, sQz504);
};

function square505(){

    var sQz505 = document.getElementById("aImgSqr505").src;

    value25aSave505 = "zSqrArtSpecz505";

    localStorage.setItem(value25aSave505, sQz505);
};

function square506(){

    var sQz506 = document.getElementById("aImgSqr506").src;

    value25aSave506 = "zSqrArtSpecz506";

    localStorage.setItem(value25aSave506, sQz506);
};

function square507(){

    var sQz507 = document.getElementById("aImgSqr507").src;

    value25aSave507 = "zSqrArtSpecz507";

    localStorage.setItem(value25aSave507, sQz507);
};

function square508(){

    var sQz508 = document.getElementById("aImgSqr508").src;

    value25aSave508 = "zSqrArtSpecz508";

    localStorage.setItem(value25aSave508, sQz508);
};

function square509(){

    var sQz509 = document.getElementById("aImgSqr509").src;

    value25aSave509 = "zSqrArtSpecz509";

    localStorage.setItem(value25aSave509, sQz509);
};

function square510(){

    var sQz510 = document.getElementById("aImgSqr510").src;

    value25aSave510 = "zSqrArtSpecz510";

    localStorage.setItem(value25aSave510, sQz510);
};

function square511(){

    var sQz511 = document.getElementById("aImgSqr511").src;

    value25aSave511 = "zSqrArtSpecz511";

    localStorage.setItem(value25aSave511, sQz511);
};

function square512(){

    var sQz512 = document.getElementById("aImgSqr512").src;

    value25aSave512 = "zSqrArtSpecz512";

    localStorage.setItem(value25aSave512, sQz512);
};

function square513(){

    var sQz513 = document.getElementById("aImgSqr513").src;

    value25aSave513 = "zSqrArtSpecz513";

    localStorage.setItem(value25aSave513, sQz513);
};

function square514(){

    var sQz514 = document.getElementById("aImgSqr514").src;

    value25aSave514 = "zSqrArtSpecz514";

    localStorage.setItem(value25aSave514, sQz514);
};

function square515(){

    var sQz515 = document.getElementById("aImgSqr515").src;

    value25aSave515 = "zSqrArtSpecz515";

    localStorage.setItem(value25aSave515, sQz515);
};

function square516(){

    var sQz516 = document.getElementById("aImgSqr516").src;

    value25aSave516 = "zSqrArtSpecz516";

    localStorage.setItem(value25aSave516, sQz516);
};

function square517(){

    var sQz517 = document.getElementById("aImgSqr517").src;

    value25aSave517 = "zSqrArtSpecz517";

    localStorage.setItem(value25aSave517, sQz517);
};

function square518(){

    var sQz518 = document.getElementById("aImgSqr518").src;

    value25aSave518 = "zSqrArtSpecz518";

    localStorage.setItem(value25aSave518, sQz518);
};

function square519(){

    var sQz519 = document.getElementById("aImgSqr519").src;

    value25aSave519 = "zSqrArtSpecz519";

    localStorage.setItem(value25aSave519, sQz519);
};

function square520(){

    var sQz520 = document.getElementById("aImgSqr520").src;

    value25aSave520 = "zSqrArtSpecz520";

    localStorage.setItem(value25aSave520, sQz520);
};

function square521(){

    var sQz521 = document.getElementById("aImgSqr521").src;

    value25aSave521 = "zSqrArtSpecz521";

    localStorage.setItem(value25aSave521, sQz521);
};

function square522(){

    var sQz522 = document.getElementById("aImgSqr522").src;

    value25aSave522 = "zSqrArtSpecz522";

    localStorage.setItem(value25aSave522, sQz522);
};

function square523(){

    var sQz523 = document.getElementById("aImgSqr523").src;

    value25aSave523 = "zSqrArtSpecz523";

    localStorage.setItem(value25aSave523, sQz523);
};

function square524(){

    var sQz524 = document.getElementById("aImgSqr524").src;

    value25aSave524 = "zSqrArtSpecz524";

    localStorage.setItem(value25aSave524, sQz524);
};

function square525(){

    var sQz525 = document.getElementById("aImgSqr525").src;

    value25aSave525 = "zSqrArtSpecz525";

    localStorage.setItem(value25aSave525, sQz525);
};

function square526(){

    var sQz526 = document.getElementById("aImgSqr526").src;

    value25aSave526 = "zSqrArtSpecz526";

    localStorage.setItem(value25aSave526, sQz526);
};

function square527(){

    var sQz527 = document.getElementById("aImgSqr527").src;

    value25aSave527 = "zSqrArtSpecz527";

    localStorage.setItem(value25aSave527, sQz527);
};

function square528(){

    var sQz528 = document.getElementById("aImgSqr528").src;

    value25aSave528 = "zSqrArtSpecz528";

    localStorage.setItem(value25aSave528, sQz528);
};

function square529(){

    var sQz529 = document.getElementById("aImgSqr529").src;

    value25aSave529 = "zSqrArtSpecz529";

    localStorage.setItem(value25aSave529, sQz529);
};

function square530(){

    var sQz530 = document.getElementById("aImgSqr530").src;

    value25aSave530 = "zSqrArtSpecz530";

    localStorage.setItem(value25aSave530, sQz530);
};

function square531(){

    var sQz531 = document.getElementById("aImgSqr531").src;

    value25aSave531 = "zSqrArtSpecz531";

    localStorage.setItem(value25aSave531, sQz531);
};

function square532(){

    var sQz532 = document.getElementById("aImgSqr532").src;

    value25aSave532 = "zSqrArtSpecz532";

    localStorage.setItem(value25aSave532, sQz532);
};

function square533(){

    var sQz533 = document.getElementById("aImgSqr533").src;

    value25aSave533 = "zSqrArtSpecz533";

    localStorage.setItem(value25aSave533, sQz533);
};

function square534(){

    var sQz534 = document.getElementById("aImgSqr534").src;

    value25aSave534 = "zSqrArtSpecz534";

    localStorage.setItem(value25aSave534, sQz534);
};

function square535(){

    var sQz535 = document.getElementById("aImgSqr535").src;

    value25aSave535 = "zSqrArtSpecz535";

    localStorage.setItem(value25aSave535, sQz535);
};

function square536(){

    var sQz536 = document.getElementById("aImgSqr536").src;

    value25aSave536 = "zSqrArtSpecz536";

    localStorage.setItem(value25aSave536, sQz536);
};

function square537(){

    var sQz537 = document.getElementById("aImgSqr537").src;

    value25aSave537 = "zSqrArtSpecz537";

    localStorage.setItem(value25aSave537, sQz537);
};

function square538(){

    var sQz538 = document.getElementById("aImgSqr538").src;

    value25aSave538 = "zSqrArtSpecz538";

    localStorage.setItem(value25aSave538, sQz538);
};

function square539(){

    var sQz539 = document.getElementById("aImgSqr539").src;

    value25aSave539 = "zSqrArtSpecz539";

    localStorage.setItem(value25aSave539, sQz539);
};

function square540(){

    var sQz540 = document.getElementById("aImgSqr540").src;

    value25aSave540 = "zSqrArtSpecz540";

    localStorage.setItem(value25aSave540, sQz540);
};

function square541(){

    var sQz541 = document.getElementById("aImgSqr541").src;

    value25aSave541 = "zSqrArtSpecz541";

    localStorage.setItem(value25aSave541, sQz541);
};

function square542(){

    var sQz542 = document.getElementById("aImgSqr542").src;

    value25aSave542 = "zSqrArtSpecz542";

    localStorage.setItem(value25aSave542, sQz542);
};

function square543(){

    var sQz543 = document.getElementById("aImgSqr543").src;

    value25aSave543 = "zSqrArtSpecz543";

    localStorage.setItem(value25aSave543, sQz543);
};

function square544(){

    var sQz544 = document.getElementById("aImgSqr544").src;

    value25aSave544 = "zSqrArtSpecz544";

    localStorage.setItem(value25aSave544, sQz544);
};

function square545(){

    var sQz545 = document.getElementById("aImgSqr545").src;

    value25aSave545 = "zSqrArtSpecz545";

    localStorage.setItem(value25aSave545, sQz545);
};

function square546(){

    var sQz546 = document.getElementById("aImgSqr546").src;

    value25aSave546 = "zSqrArtSpecz546";

    localStorage.setItem(value25aSave546, sQz546);
};

function square547(){

    var sQz547 = document.getElementById("aImgSqr547").src;

    value25aSave547 = "zSqrArtSpecz547";

    localStorage.setItem(value25aSave547, sQz547);
};

function square548(){

    var sQz548 = document.getElementById("aImgSqr548").src;

    value25aSave548 = "zSqrArtSpecz548";

    localStorage.setItem(value25aSave548, sQz548);
};

function square549(){

    var sQz549 = document.getElementById("aImgSqr549").src;

    value25aSave549 = "zSqrArtSpecz549";

    localStorage.setItem(value25aSave549, sQz549);
};

function square550(){

    var sQz550 = document.getElementById("aImgSqr550").src;

    value25aSave550 = "zSqrArtSpecz550";

    localStorage.setItem(value25aSave550, sQz550);
};

function square551(){

    var sQz551 = document.getElementById("aImgSqr551").src;

    value25aSave551 = "zSqrArtSpecz551";

    localStorage.setItem(value25aSave551, sQz551);
};

function square552(){

    var sQz552 = document.getElementById("aImgSqr552").src;

    value25aSave552 = "zSqrArtSpecz552";

    localStorage.setItem(value25aSave552, sQz552);
};

function square553(){

    var sQz553 = document.getElementById("aImgSqr553").src;

    value25aSave553 = "zSqrArtSpecz553";

    localStorage.setItem(value25aSave553, sQz553);
};

function square554(){

    var sQz554 = document.getElementById("aImgSqr554").src;

    value25aSave554 = "zSqrArtSpecz554";

    localStorage.setItem(value25aSave554, sQz554);
};

function square555(){

    var sQz555 = document.getElementById("aImgSqr555").src;

    value25aSave555 = "zSqrArtSpecz555";

    localStorage.setItem(value25aSave555, sQz555);
};

function square556(){

    var sQz556 = document.getElementById("aImgSqr556").src;

    value25aSave556 = "zSqrArtSpecz556";

    localStorage.setItem(value25aSave556, sQz556);
};

function square557(){

    var sQz557 = document.getElementById("aImgSqr557").src;

    value25aSave557 = "zSqrArtSpecz557";

    localStorage.setItem(value25aSave557, sQz557);
};

function square558(){

    var sQz558 = document.getElementById("aImgSqr558").src;

    value25aSave558 = "zSqrArtSpecz558";

    localStorage.setItem(value25aSave558, sQz558);
};

function square559(){

    var sQz559 = document.getElementById("aImgSqr559").src;

    value25aSave559 = "zSqrArtSpecz559";

    localStorage.setItem(value25aSave559, sQz559);
};

function square560(){

    var sQz560 = document.getElementById("aImgSqr560").src;

    value25aSave560 = "zSqrArtSpecz560";

    localStorage.setItem(value25aSave560, sQz560);
};

function square561(){

    var sQz561 = document.getElementById("aImgSqr561").src;

    value25aSave561 = "zSqrArtSpecz561";

    localStorage.setItem(value25aSave561, sQz561);
};

function square562(){

    var sQz562 = document.getElementById("aImgSqr562").src;

    value25aSave562 = "zSqrArtSpecz562";

    localStorage.setItem(value25aSave562, sQz562);
};

function square563(){

    var sQz563 = document.getElementById("aImgSqr563").src;

    value25aSave563 = "zSqrArtSpecz563";

    localStorage.setItem(value25aSave563, sQz563);
};

function square564(){

    var sQz564 = document.getElementById("aImgSqr564").src;

    value25aSave564 = "zSqrArtSpecz564";

    localStorage.setItem(value25aSave564, sQz564);
};

function square565(){

    var sQz565 = document.getElementById("aImgSqr565").src;

    value25aSave565 = "zSqrArtSpecz565";

    localStorage.setItem(value25aSave565, sQz565);
};

function square566(){

    var sQz566 = document.getElementById("aImgSqr566").src;

    value25aSave566 = "zSqrArtSpecz566";

    localStorage.setItem(value25aSave566, sQz566);
};

function square567(){

    var sQz567 = document.getElementById("aImgSqr567").src;

    value25aSave567 = "zSqrArtSpecz567";

    localStorage.setItem(value25aSave567, sQz567);
};

function square568(){

    var sQz568 = document.getElementById("aImgSqr568").src;

    value25aSave568 = "zSqrArtSpecz568";

    localStorage.setItem(value25aSave568, sQz568);
};

function square569(){

    var sQz569 = document.getElementById("aImgSqr569").src;

    value25aSave569 = "zSqrArtSpecz569";

    localStorage.setItem(value25aSave569, sQz569);
};

function square570(){

    var sQz570 = document.getElementById("aImgSqr570").src;

    value25aSave570 = "zSqrArtSpecz570";

    localStorage.setItem(value25aSave570, sQz570);
};

function square571(){

    var sQz571 = document.getElementById("aImgSqr571").src;

    value25aSave571 = "zSqrArtSpecz571";

    localStorage.setItem(value25aSave571, sQz571);
};

function square572(){

    var sQz572 = document.getElementById("aImgSqr572").src;

    value25aSave572 = "zSqrArtSpecz572";

    localStorage.setItem(value25aSave572, sQz572);
};

function square573(){

    var sQz573 = document.getElementById("aImgSqr573").src;

    value25aSave573 = "zSqrArtSpecz573";

    localStorage.setItem(value25aSave573, sQz573);
};

function square574(){

    var sQz574 = document.getElementById("aImgSqr574").src;

    value25aSave574 = "zSqrArtSpecz574";

    localStorage.setItem(value25aSave574, sQz574);
};

function square575(){

    var sQz575 = document.getElementById("aImgSqr575").src;

    value25aSave575 = "zSqrArtSpecz575";

    localStorage.setItem(value25aSave575, sQz575);
};

function square576(){

    var sQz576 = document.getElementById("aImgSqr576").src;

    value25aSave576 = "zSqrArtSpecz576";

    localStorage.setItem(value25aSave576, sQz576);
};

function square577(){

    var sQz577 = document.getElementById("aImgSqr577").src;

    value25aSave577 = "zSqrArtSpecz577";

    localStorage.setItem(value25aSave577, sQz577);
};

function square578(){

    var sQz578 = document.getElementById("aImgSqr578").src;

    value25aSave578 = "zSqrArtSpecz578";

    localStorage.setItem(value25aSave578, sQz578);
};

function square579(){

    var sQz579 = document.getElementById("aImgSqr579").src;

    value25aSave579 = "zSqrArtSpecz579";

    localStorage.setItem(value25aSave579, sQz579);
};

function square580(){

    var sQz580 = document.getElementById("aImgSqr580").src;

    value25aSave580 = "zSqrArtSpecz580";

    localStorage.setItem(value25aSave580, sQz580);
};

function square581(){

    var sQz581 = document.getElementById("aImgSqr581").src;

    value25aSave581 = "zSqrArtSpecz581";

    localStorage.setItem(value25aSave581, sQz581);
};

function square582(){

    var sQz582 = document.getElementById("aImgSqr582").src;

    value25aSave582 = "zSqrArtSpecz582";

    localStorage.setItem(value25aSave582, sQz582);
};

function square583(){

    var sQz583 = document.getElementById("aImgSqr583").src;

    value25aSave583 = "zSqrArtSpecz583";

    localStorage.setItem(value25aSave583, sQz583);
};

function square584(){

    var sQz584 = document.getElementById("aImgSqr584").src;

    value25aSave584 = "zSqrArtSpecz584";

    localStorage.setItem(value25aSave584, sQz584);
};

function square585(){

    var sQz585 = document.getElementById("aImgSqr585").src;

    value25aSave585 = "zSqrArtSpecz585";

    localStorage.setItem(value25aSave585, sQz585);
};

function square586(){

    var sQz586 = document.getElementById("aImgSqr586").src;

    value25aSave586 = "zSqrArtSpecz586";

    localStorage.setItem(value25aSave586, sQz586);
};

function square587(){

    var sQz587 = document.getElementById("aImgSqr587").src;

    value25aSave587 = "zSqrArtSpecz587";

    localStorage.setItem(value25aSave587, sQz587);
};

function square588(){

    var sQz588 = document.getElementById("aImgSqr588").src;

    value25aSave588 = "zSqrArtSpecz588";

    localStorage.setItem(value25aSave588, sQz588);
};

function square589(){

    var sQz589 = document.getElementById("aImgSqr589").src;

    value25aSave589 = "zSqrArtSpecz589";

    localStorage.setItem(value25aSave589, sQz589);
};

function square590(){

    var sQz590 = document.getElementById("aImgSqr590").src;

    value25aSave590 = "zSqrArtSpecz590";

    localStorage.setItem(value25aSave590, sQz590);
};

function square591(){

    var sQz591 = document.getElementById("aImgSqr591").src;

    value25aSave591 = "zSqrArtSpecz591";

    localStorage.setItem(value25aSave591, sQz591);
};

function square592(){

    var sQz592 = document.getElementById("aImgSqr592").src;

    value25aSave592 = "zSqrArtSpecz592";

    localStorage.setItem(value25aSave592, sQz592);
};

function square593(){

    var sQz593 = document.getElementById("aImgSqr593").src;

    value25aSave593 = "zSqrArtSpecz593";

    localStorage.setItem(value25aSave593, sQz593);
};

function square594(){

    var sQz594 = document.getElementById("aImgSqr594").src;

    value25aSave594 = "zSqrArtSpecz594";

    localStorage.setItem(value25aSave594, sQz594);
};

function square595(){

    var sQz595 = document.getElementById("aImgSqr595").src;

    value25aSave595 = "zSqrArtSpecz595";

    localStorage.setItem(value25aSave595, sQz595);
};

function square596(){

    var sQz596 = document.getElementById("aImgSqr596").src;

    value25aSave596 = "zSqrArtSpecz596";

    localStorage.setItem(value25aSave596, sQz596);
};

function square597(){

    var sQz597 = document.getElementById("aImgSqr597").src;

    value25aSave597 = "zSqrArtSpecz597";

    localStorage.setItem(value25aSave597, sQz597);
};

function square598(){

    var sQz598 = document.getElementById("aImgSqr598").src;

    value25aSave598 = "zSqrArtSpecz598";

    localStorage.setItem(value25aSave598, sQz598);
};

function square599(){

    var sQz599 = document.getElementById("aImgSqr599").src;

    value25aSave599 = "zSqrArtSpecz599";

    localStorage.setItem(value25aSave599, sQz599);
};

function square600(){

    var sQz600 = document.getElementById("aImgSqr600").src;

    value25aSave600 = "zSqrArtSpecz600";

    localStorage.setItem(value25aSave600, sQz600);
};

function square601(){

    var sQz601 = document.getElementById("aImgSqr601").src;

    value25aSave601 = "zSqrArtSpecz601";

    localStorage.setItem(value25aSave601, sQz601);
};

function square602(){

    var sQz602 = document.getElementById("aImgSqr602").src;

    value25aSave602 = "zSqrArtSpecz602";

    localStorage.setItem(value25aSave602, sQz602);
};

function square603(){

    var sQz603 = document.getElementById("aImgSqr603").src;

    value25aSave603 = "zSqrArtSpecz603";

    localStorage.setItem(value25aSave603, sQz603);
};

function square604(){

    var sQz604 = document.getElementById("aImgSqr604").src;

    value25aSave604 = "zSqrArtSpecz604";

    localStorage.setItem(value25aSave604, sQz604);
};

function square605(){

    var sQz605 = document.getElementById("aImgSqr605").src;

    value25aSave605 = "zSqrArtSpecz605";

    localStorage.setItem(value25aSave605, sQz605);
};

function square606(){

    var sQz606 = document.getElementById("aImgSqr606").src;

    value25aSave606 = "zSqrArtSpecz606";

    localStorage.setItem(value25aSave606, sQz606);
};

function square607(){

    var sQz607 = document.getElementById("aImgSqr607").src;

    value25aSave607 = "zSqrArtSpecz607";

    localStorage.setItem(value25aSave607, sQz607);
};

function square608(){

    var sQz608 = document.getElementById("aImgSqr608").src;

    value25aSave608 = "zSqrArtSpecz608";

    localStorage.setItem(value25aSave608, sQz608);
};

function square609(){

    var sQz609 = document.getElementById("aImgSqr609").src;

    value25aSave609 = "zSqrArtSpecz609";

    localStorage.setItem(value25aSave609, sQz609);
};

function square610(){

    var sQz610 = document.getElementById("aImgSqr610").src;

    value25aSave610 = "zSqrArtSpecz610";

    localStorage.setItem(value25aSave610, sQz610);
};

function square611(){

    var sQz611 = document.getElementById("aImgSqr611").src;

    value25aSave611 = "zSqrArtSpecz611";

    localStorage.setItem(value25aSave611, sQz611);
};

function square612(){

    var sQz612 = document.getElementById("aImgSqr612").src;

    value25aSave612 = "zSqrArtSpecz612";

    localStorage.setItem(value25aSave612, sQz612);
};

function square613(){

    var sQz613 = document.getElementById("aImgSqr613").src;

    value25aSave613 = "zSqrArtSpecz613";

    localStorage.setItem(value25aSave613, sQz613);
};

function square614(){

    var sQz614 = document.getElementById("aImgSqr614").src;

    value25aSave614 = "zSqrArtSpecz614";

    localStorage.setItem(value25aSave614, sQz614);
};

function square615(){

    var sQz615 = document.getElementById("aImgSqr615").src;

    value25aSave615 = "zSqrArtSpecz615";

    localStorage.setItem(value25aSave615, sQz615);
};

function square616(){

    var sQz616 = document.getElementById("aImgSqr616").src;

    value25aSave616 = "zSqrArtSpecz616";

    localStorage.setItem(value25aSave616, sQz616);
};

function square617(){

    var sQz617 = document.getElementById("aImgSqr617").src;

    value25aSave617 = "zSqrArtSpecz617";

    localStorage.setItem(value25aSave617, sQz617);
};

function square618(){

    var sQz618 = document.getElementById("aImgSqr618").src;

    value25aSave618 = "zSqrArtSpecz618";

    localStorage.setItem(value25aSave618, sQz618);
};

function square619(){

    var sQz619 = document.getElementById("aImgSqr619").src;

    value25aSave619 = "zSqrArtSpecz619";

    localStorage.setItem(value25aSave619, sQz619);
};

function square620(){

    var sQz620 = document.getElementById("aImgSqr620").src;

    value25aSave620 = "zSqrArtSpecz620";

    localStorage.setItem(value25aSave620, sQz620);
};

function square621(){

    var sQz621 = document.getElementById("aImgSqr621").src;

    value25aSave621 = "zSqrArtSpecz621";

    localStorage.setItem(value25aSave621, sQz621);
};

function square622(){

    var sQz622 = document.getElementById("aImgSqr622").src;

    value25aSave622 = "zSqrArtSpecz622";

    localStorage.setItem(value25aSave622, sQz622);
};

function square623(){

    var sQz623 = document.getElementById("aImgSqr623").src;

    value25aSave623 = "zSqrArtSpecz623";

    localStorage.setItem(value25aSave623, sQz623);
};

function square624(){

    var sQz624 = document.getElementById("aImgSqr624").src;

    value25aSave624 = "zSqrArtSpecz624";

    localStorage.setItem(value25aSave624, sQz624);
};

function square625(){

    var sQz625 = document.getElementById("aImgSqr625").src;

    value25aSave625 = "zSqrArtSpecz625";

    localStorage.setItem(value25aSave625, sQz625);
};

function setCThis(){
    square1()

    square2()

    square3()

    square4()

    square5()

    square6()

    square7()

    square8()

    square9()

    square10()

    square11()

    square12()

    square13()

    square14()

    square15()

    square16()

    square17()

    square18()

    square19()

    square20()

    square21()

    square22()

    square23()

    square24()

    square25()

    square26()

    square27()

    square28()

    square29()

    square30()

    square31()

    square32()

    square33()

    square34()

    square35()

    square36()

    square37()

    square38()

    square39()

    square40()

    square41()

    square42()

    square43()

    square44()

    square45()

    square46()

    square47()

    square48()

    square49()

    square50()

    square51()

    square52()

    square53()

    square54()

    square55()

    square56()

    square57()

    square58()

    square59()

    square60()

    square61()

    square62()

    square63()

    square64()

    square65()

    square66()

    square67()

    square68()

    square69()

    square70()

    square71()

    square72()

    square73()

    square74()

    square75()

    square76()

    square77()

    square78()

    square79()

    square80()

    square81()

    square82()

    square83()

    square84()

    square85()

    square86()

    square87()

    square88()

    square89()

    square90()

    square91()

    square92()

    square93()

    square94()

    square95()

    square96()

    square97()

    square98()

    square99()

    square100()

    square101()

    square102()

    square103()

    square104()

    square105()

    square106()

    square107()

    square108()

    square109()

    square110()

    square111()

    square112()

    square113()

    square114()

    square115()

    square116()

    square117()

    square118()

    square119()

    square120()

    square121()

    square122()

    square123()

    square124()

    square125()

    square126()

    square127()

    square128()

    square129()

    square130()

    square131()

    square132()

    square133()

    square134()

    square135()

    square136()

    square137()

    square138()

    square139()

    square140()

    square141()

    square142()

    square143()

    square144()

    square145()

    square146()

    square147()

    square148()

    square149()

    square150()

    square151()

    square152()

    square153()

    square154()

    square155()

    square156()

    square157()

    square158()

    square159()

    square160()

    square161()

    square162()

    square163()

    square164()

    square165()

    square166()

    square167()

    square168()

    square169()

    square170()

    square171()

    square172()

    square173()

    square174()

    square175()

    square176()

    square177()

    square178()

    square179()

    square180()

    square181()

    square182()

    square183()

    square184()

    square185()

    square186()

    square187()

    square188()

    square189()

    square190()

    square191()

    square192()

    square193()

    square194()

    square195()

    square196()

    square197()

    square198()

    square199()

    square200()

    square201()

    square202()

    square203()

    square204()

    square205()

    square206()

    square207()

    square208()

    square209()

    square210()

    square211()

    square212()

    square213()

    square214()

    square215()

    square216()

    square217()

    square218()

    square219()

    square220()

    square221()

    square222()

    square223()

    square224()

    square225()

    square226()

    square227()

    square228()

    square229()

    square230()

    square231()

    square232()

    square233()

    square234()

    square235()

    square236()

    square237()

    square238()

    square239()

    square240()

    square241()

    square242()

    square243()

    square244()

    square245()

    square246()

    square247()

    square248()

    square249()

    square250()

    square251()

    square252()

    square253()

    square254()

    square255()

    square256()

    square257()

    square258()

    square259()

    square260()

    square261()

    square262()

    square263()

    square264()

    square265()

    square266()

    square267()

    square268()

    square269()

    square270()

    square271()

    square272()

    square273()

    square274()

    square275()

    square276()

    square277()

    square278()

    square279()

    square280()

    square281()

    square282()

    square283()

    square284()

    square285()

    square286()

    square287()

    square288()

    square289()

    square290()

    square291()

    square292()

    square293()

    square294()

    square295()

    square296()

    square297()

    square298()

    square299()

    square300()

    square301()

    square302()

    square303()

    square304()

    square305()

    square306()

    square307()

    square308()

    square309()

    square310()

    square311()

    square312()

    square313()

    square314()

    square315()

    square316()

    square317()

    square318()

    square319()

    square320()

    square321()

    square322()

    square323()

    square324()

    square325()

    square326()

    square327()

    square328()

    square329()

    square330()

    square331()

    square332()

    square333()

    square334()

    square335()

    square336()

    square337()

    square338()

    square339()

    square340()

    square341()

    square342()

    square343()

    square344()

    square345()

    square346()

    square347()

    square348()

    square349()

    square350()

    square351()

    square352()

    square353()

    square354()

    square355()

    square356()

    square357()

    square358()

    square359()

    square360()

    square361()

    square362()

    square363()

    square364()

    square365()

    square366()

    square367()

    square368()

    square369()

    square370()

    square371()

    square372()

    square373()

    square374()

    square375()

    square376()

    square377()

    square378()

    square379()

    square380()

    square381()

    square382()

    square383()

    square384()

    square385()

    square386()

    square387()

    square388()

    square389()

    square390()

    square391()

    square392()

    square393()

    square394()

    square395()

    square396()

    square397()

    square398()

    square399()

    square400()

    square401()

    square402()

    square403()

    square404()

    square405()

    square406()

    square407()

    square408()

    square409()

    square410()

    square411()

    square412()

    square413()

    square414()

    square415()

    square416()

    square417()

    square418()

    square419()

    square420()

    square421()

    square422()

    square423()

    square424()

    square425()

    square426()

    square427()

    square428()

    square429()

    square430()

    square431()

    square432()

    square433()

    square434()

    square435()

    square436()

    square437()

    square438()

    square439()

    square440()

    square441()

    square442()

    square443()

    square444()

    square445()

    square446()

    square447()

    square448()

    square449()

    square450()

    square451()

    square452()

    square453()

    square454()

    square455()

    square456()

    square457()

    square458()

    square459()

    square460()

    square461()

    square462()

    square463()

    square464()

    square465()

    square466()

    square467()

    square468()

    square469()

    square470()

    square471()

    square472()

    square473()

    square474()

    square475()

    square476()

    square477()

    square478()

    square479()

    square480()

    square481()

    square482()

    square483()

    square484()

    square485()

    square486()

    square487()

    square488()

    square489()

    square490()

    square491()

    square492()

    square493()

    square494()

    square495()

    square496()

    square497()

    square498()

    square499()

    square500()

    square501()

    square502()

    square503()

    square504()

    square505()

    square506()

    square507()

    square508()

    square509()

    square510()

    square511()

    square512()

    square513()

    square514()

    square515()

    square516()

    square517()

    square518()

    square519()

    square520()

    square521()

    square522()

    square523()

    square524()

    square525()

    square526()

    square527()

    square528()

    square529()

    square530()

    square531()

    square532()

    square533()

    square534()

    square535()

    square536()

    square537()

    square538()

    square539()

    square540()

    square541()

    square542()

    square543()

    square544()

    square545()

    square546()

    square547()

    square548()

    square549()

    square550()

    square551()

    square552()

    square553()

    square554()

    square555()

    square556()

    square557()

    square558()

    square559()

    square560()

    square561()

    square562()

    square563()

    square564()

    square565()

    square566()

    square567()

    square568()

    square569()

    square570()

    square571()

    square572()

    square573()

    square574()

    square575()

    square576()

    square577()

    square578()

    square579()

    square580()

    square581()

    square582()

    square583()

    square584()

    square585()

    square586()

    square587()

    square588()

    square589()

    square590()

    square591()

    square592()

    square593()

    square594()

    square595()

    square596()

    square597()

    square598()

    square599()

    square600()

    square601()

    square602()

    square603()

    square604()

    square605()

    square606()

    square607()

    square608()

    square609()

    square610()

    square611()

    square612()

    square613()

    square614()

    square615()

    square616()

    square617()

    square618()

    square619()

    square620()

    square621()

    square622()

    square623()

    square624()

    square625()

    alert("Your art has been saved locally, to your local browser storage.");
};

function squareToSzzZValue1(){
    value25aSave = "zSqrArtSpecz1";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs1").src = tripleZeroA;
};

function squareToSzzZValue2(){
    value25aSave = "zSqrArtSpecz2";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs2").src = tripleZeroA;
};

function squareToSzzZValue3(){
    value25aSave = "zSqrArtSpecz3";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs3").src = tripleZeroA;
};

function squareToSzzZValue4(){
    value25aSave = "zSqrArtSpecz4";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs4").src = tripleZeroA;
};

function squareToSzzZValue5(){
    value25aSave = "zSqrArtSpecz5";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs5").src = tripleZeroA;
};

function squareToSzzZValue6(){
    value25aSave = "zSqrArtSpecz6";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs6").src = tripleZeroA;
};

function squareToSzzZValue7(){
    value25aSave = "zSqrArtSpecz7";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs7").src = tripleZeroA;
};

function squareToSzzZValue8(){
    value25aSave = "zSqrArtSpecz8";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs8").src = tripleZeroA;
};

function squareToSzzZValue9(){
    value25aSave = "zSqrArtSpecz9";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs9").src = tripleZeroA;
};

function squareToSzzZValue10(){
    value25aSave = "zSqrArtSpecz10";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs10").src = tripleZeroA;
};

function squareToSzzZValue11(){
    value25aSave = "zSqrArtSpecz11";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs11").src = tripleZeroA;
};

function squareToSzzZValue12(){
    value25aSave = "zSqrArtSpecz12";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs12").src = tripleZeroA;
};

function squareToSzzZValue13(){
    value25aSave = "zSqrArtSpecz13";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs13").src = tripleZeroA;
};

function squareToSzzZValue14(){
    value25aSave = "zSqrArtSpecz14";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs14").src = tripleZeroA;
};

function squareToSzzZValue15(){
    value25aSave = "zSqrArtSpecz15";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs15").src = tripleZeroA;
};

function squareToSzzZValue16(){
    value25aSave = "zSqrArtSpecz16";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs16").src = tripleZeroA;
};

function squareToSzzZValue17(){
    value25aSave = "zSqrArtSpecz17";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs17").src = tripleZeroA;
};

function squareToSzzZValue18(){
    value25aSave = "zSqrArtSpecz18";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs18").src = tripleZeroA;
};

function squareToSzzZValue19(){
    value25aSave = "zSqrArtSpecz19";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs19").src = tripleZeroA;
};

function squareToSzzZValue20(){
    value25aSave = "zSqrArtSpecz20";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs20").src = tripleZeroA;
};

function squareToSzzZValue21(){
    value25aSave = "zSqrArtSpecz21";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs21").src = tripleZeroA;
};

function squareToSzzZValue22(){
    value25aSave = "zSqrArtSpecz22";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs22").src = tripleZeroA;
};

function squareToSzzZValue23(){
    value25aSave = "zSqrArtSpecz23";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs23").src = tripleZeroA;
};

function squareToSzzZValue24(){
    value25aSave = "zSqrArtSpecz24";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs24").src = tripleZeroA;
};

function squareToSzzZValue25(){
    value25aSave = "zSqrArtSpecz25";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs25").src = tripleZeroA;
};

function squareToSzzZValue26(){
    value25aSave = "zSqrArtSpecz26";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs26").src = tripleZeroA;
};

function squareToSzzZValue27(){
    value25aSave = "zSqrArtSpecz27";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs27").src = tripleZeroA;
};

function squareToSzzZValue28(){
    value25aSave = "zSqrArtSpecz28";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs28").src = tripleZeroA;
};

function squareToSzzZValue29(){
    value25aSave = "zSqrArtSpecz29";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs29").src = tripleZeroA;
};

function squareToSzzZValue30(){
    value25aSave = "zSqrArtSpecz30";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs30").src = tripleZeroA;
};

function squareToSzzZValue31(){
    value25aSave = "zSqrArtSpecz31";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs31").src = tripleZeroA;
};

function squareToSzzZValue32(){
    value25aSave = "zSqrArtSpecz32";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs32").src = tripleZeroA;
};

function squareToSzzZValue33(){
    value25aSave = "zSqrArtSpecz33";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs33").src = tripleZeroA;
};

function squareToSzzZValue34(){
    value25aSave = "zSqrArtSpecz34";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs34").src = tripleZeroA;
};

function squareToSzzZValue35(){
    value25aSave = "zSqrArtSpecz35";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs35").src = tripleZeroA;
};

function squareToSzzZValue36(){
    value25aSave = "zSqrArtSpecz36";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs36").src = tripleZeroA;
};

function squareToSzzZValue37(){
    value25aSave = "zSqrArtSpecz37";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs37").src = tripleZeroA;
};

function squareToSzzZValue38(){
    value25aSave = "zSqrArtSpecz38";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs38").src = tripleZeroA;
};

function squareToSzzZValue39(){
    value25aSave = "zSqrArtSpecz39";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs39").src = tripleZeroA;
};

function squareToSzzZValue40(){
    value25aSave = "zSqrArtSpecz40";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs40").src = tripleZeroA;
};

function squareToSzzZValue41(){
    value25aSave = "zSqrArtSpecz41";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs41").src = tripleZeroA;
};

function squareToSzzZValue42(){
    value25aSave = "zSqrArtSpecz42";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs42").src = tripleZeroA;
};

function squareToSzzZValue43(){
    value25aSave = "zSqrArtSpecz43";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs43").src = tripleZeroA;
};

function squareToSzzZValue44(){
    value25aSave = "zSqrArtSpecz44";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs44").src = tripleZeroA;
};

function squareToSzzZValue45(){
    value25aSave = "zSqrArtSpecz45";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs45").src = tripleZeroA;
};

function squareToSzzZValue46(){
    value25aSave = "zSqrArtSpecz46";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs46").src = tripleZeroA;
};

function squareToSzzZValue47(){
    value25aSave = "zSqrArtSpecz47";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs47").src = tripleZeroA;
};

function squareToSzzZValue48(){
    value25aSave = "zSqrArtSpecz48";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs48").src = tripleZeroA;
};

function squareToSzzZValue49(){
    value25aSave = "zSqrArtSpecz49";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs49").src = tripleZeroA;
};

function squareToSzzZValue50(){
    value25aSave = "zSqrArtSpecz50";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs50").src = tripleZeroA;
};

function squareToSzzZValue51(){
    value25aSave = "zSqrArtSpecz51";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs51").src = tripleZeroA;
};

function squareToSzzZValue52(){
    value25aSave = "zSqrArtSpecz52";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs52").src = tripleZeroA;
};

function squareToSzzZValue53(){
    value25aSave = "zSqrArtSpecz53";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs53").src = tripleZeroA;
};

function squareToSzzZValue54(){
    value25aSave = "zSqrArtSpecz54";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs54").src = tripleZeroA;
};

function squareToSzzZValue55(){
    value25aSave = "zSqrArtSpecz55";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs55").src = tripleZeroA;
};

function squareToSzzZValue56(){
    value25aSave = "zSqrArtSpecz56";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs56").src = tripleZeroA;
};

function squareToSzzZValue57(){
    value25aSave = "zSqrArtSpecz57";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs57").src = tripleZeroA;
};

function squareToSzzZValue58(){
    value25aSave = "zSqrArtSpecz58";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs58").src = tripleZeroA;
};

function squareToSzzZValue59(){
    value25aSave = "zSqrArtSpecz59";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs59").src = tripleZeroA;
};

function squareToSzzZValue60(){
    value25aSave = "zSqrArtSpecz60";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs60").src = tripleZeroA;
};

function squareToSzzZValue61(){
    value25aSave = "zSqrArtSpecz61";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs61").src = tripleZeroA;
};

function squareToSzzZValue62(){
    value25aSave = "zSqrArtSpecz62";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs62").src = tripleZeroA;
};

function squareToSzzZValue63(){
    value25aSave = "zSqrArtSpecz63";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs63").src = tripleZeroA;
};

function squareToSzzZValue64(){
    value25aSave = "zSqrArtSpecz64";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs64").src = tripleZeroA;
};

function squareToSzzZValue65(){
    value25aSave = "zSqrArtSpecz65";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs65").src = tripleZeroA;
};

function squareToSzzZValue66(){
    value25aSave = "zSqrArtSpecz66";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs66").src = tripleZeroA;
};

function squareToSzzZValue67(){
    value25aSave = "zSqrArtSpecz67";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs67").src = tripleZeroA;
};

function squareToSzzZValue68(){
    value25aSave = "zSqrArtSpecz68";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs68").src = tripleZeroA;
};

function squareToSzzZValue69(){
    value25aSave = "zSqrArtSpecz69";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs69").src = tripleZeroA;
};

function squareToSzzZValue70(){
    value25aSave = "zSqrArtSpecz70";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs70").src = tripleZeroA;
};

function squareToSzzZValue71(){
    value25aSave = "zSqrArtSpecz71";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs71").src = tripleZeroA;
};

function squareToSzzZValue72(){
    value25aSave = "zSqrArtSpecz72";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs72").src = tripleZeroA;
};

function squareToSzzZValue73(){
    value25aSave = "zSqrArtSpecz73";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs73").src = tripleZeroA;
};

function squareToSzzZValue74(){
    value25aSave = "zSqrArtSpecz74";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs74").src = tripleZeroA;
};

function squareToSzzZValue75(){
    value25aSave = "zSqrArtSpecz75";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs75").src = tripleZeroA;
};

function squareToSzzZValue76(){
    value25aSave = "zSqrArtSpecz76";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs76").src = tripleZeroA;
};

function squareToSzzZValue77(){
    value25aSave = "zSqrArtSpecz77";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs77").src = tripleZeroA;
};

function squareToSzzZValue78(){
    value25aSave = "zSqrArtSpecz78";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs78").src = tripleZeroA;
};

function squareToSzzZValue79(){
    value25aSave = "zSqrArtSpecz79";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs79").src = tripleZeroA;
};

function squareToSzzZValue80(){
    value25aSave = "zSqrArtSpecz80";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs80").src = tripleZeroA;
};

function squareToSzzZValue81(){
    value25aSave = "zSqrArtSpecz81";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs81").src = tripleZeroA;
};

function squareToSzzZValue82(){
    value25aSave = "zSqrArtSpecz82";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs82").src = tripleZeroA;
};

function squareToSzzZValue83(){
    value25aSave = "zSqrArtSpecz83";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs83").src = tripleZeroA;
};

function squareToSzzZValue84(){
    value25aSave = "zSqrArtSpecz84";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs84").src = tripleZeroA;
};

function squareToSzzZValue85(){
    value25aSave = "zSqrArtSpecz85";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs85").src = tripleZeroA;
};

function squareToSzzZValue86(){
    value25aSave = "zSqrArtSpecz86";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs86").src = tripleZeroA;
};

function squareToSzzZValue87(){
    value25aSave = "zSqrArtSpecz87";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs87").src = tripleZeroA;
};

function squareToSzzZValue88(){
    value25aSave = "zSqrArtSpecz88";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs88").src = tripleZeroA;
};

function squareToSzzZValue89(){
    value25aSave = "zSqrArtSpecz89";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs89").src = tripleZeroA;
};

function squareToSzzZValue90(){
    value25aSave = "zSqrArtSpecz90";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs90").src = tripleZeroA;
};

function squareToSzzZValue91(){
    value25aSave = "zSqrArtSpecz91";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs91").src = tripleZeroA;
};

function squareToSzzZValue92(){
    value25aSave = "zSqrArtSpecz92";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs92").src = tripleZeroA;
};

function squareToSzzZValue93(){
    value25aSave = "zSqrArtSpecz93";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs93").src = tripleZeroA;
};

function squareToSzzZValue94(){
    value25aSave = "zSqrArtSpecz94";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs94").src = tripleZeroA;
};

function squareToSzzZValue95(){
    value25aSave = "zSqrArtSpecz95";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs95").src = tripleZeroA;
};

function squareToSzzZValue96(){
    value25aSave = "zSqrArtSpecz96";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs96").src = tripleZeroA;
};

function squareToSzzZValue97(){
    value25aSave = "zSqrArtSpecz97";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs97").src = tripleZeroA;
};

function squareToSzzZValue98(){
    value25aSave = "zSqrArtSpecz98";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs98").src = tripleZeroA;
};

function squareToSzzZValue99(){
    value25aSave = "zSqrArtSpecz99";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs99").src = tripleZeroA;
};

function squareToSzzZValue100(){
    value25aSave = "zSqrArtSpecz100";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs100").src = tripleZeroA;
};

function squareToSzzZValue101(){
    value25aSave = "zSqrArtSpecz101";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs101").src = tripleZeroA;
};

function squareToSzzZValue102(){
    value25aSave = "zSqrArtSpecz102";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs102").src = tripleZeroA;
};

function squareToSzzZValue103(){
    value25aSave = "zSqrArtSpecz103";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs103").src = tripleZeroA;
};

function squareToSzzZValue104(){
    value25aSave = "zSqrArtSpecz104";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs104").src = tripleZeroA;
};

function squareToSzzZValue105(){
    value25aSave = "zSqrArtSpecz105";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs105").src = tripleZeroA;
};

function squareToSzzZValue106(){
    value25aSave = "zSqrArtSpecz106";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs106").src = tripleZeroA;
};

function squareToSzzZValue107(){
    value25aSave = "zSqrArtSpecz107";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs107").src = tripleZeroA;
};

function squareToSzzZValue108(){
    value25aSave = "zSqrArtSpecz108";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs108").src = tripleZeroA;
};

function squareToSzzZValue109(){
    value25aSave = "zSqrArtSpecz109";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs109").src = tripleZeroA;
};

function squareToSzzZValue110(){
    value25aSave = "zSqrArtSpecz110";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs110").src = tripleZeroA;
};

function squareToSzzZValue111(){
    value25aSave = "zSqrArtSpecz111";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs111").src = tripleZeroA;
};

function squareToSzzZValue112(){
    value25aSave = "zSqrArtSpecz112";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs112").src = tripleZeroA;
};

function squareToSzzZValue113(){
    value25aSave = "zSqrArtSpecz113";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs113").src = tripleZeroA;
};

function squareToSzzZValue114(){
    value25aSave = "zSqrArtSpecz114";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs114").src = tripleZeroA;
};

function squareToSzzZValue115(){
    value25aSave = "zSqrArtSpecz115";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs115").src = tripleZeroA;
};

function squareToSzzZValue116(){
    value25aSave = "zSqrArtSpecz116";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs116").src = tripleZeroA;
};

function squareToSzzZValue117(){
    value25aSave = "zSqrArtSpecz117";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs117").src = tripleZeroA;
};

function squareToSzzZValue118(){
    value25aSave = "zSqrArtSpecz118";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs118").src = tripleZeroA;
};

function squareToSzzZValue119(){
    value25aSave = "zSqrArtSpecz119";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs119").src = tripleZeroA;
};

function squareToSzzZValue120(){
    value25aSave = "zSqrArtSpecz120";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs120").src = tripleZeroA;
};

function squareToSzzZValue121(){
    value25aSave = "zSqrArtSpecz121";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs121").src = tripleZeroA;
};

function squareToSzzZValue122(){
    value25aSave = "zSqrArtSpecz122";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs122").src = tripleZeroA;
};

function squareToSzzZValue123(){
    value25aSave = "zSqrArtSpecz123";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs123").src = tripleZeroA;
};

function squareToSzzZValue124(){
    value25aSave = "zSqrArtSpecz124";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs124").src = tripleZeroA;
};

function squareToSzzZValue125(){
    value25aSave = "zSqrArtSpecz125";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs125").src = tripleZeroA;
};

function squareToSzzZValue126(){
    value25aSave = "zSqrArtSpecz126";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs126").src = tripleZeroA;
};

function squareToSzzZValue127(){
    value25aSave = "zSqrArtSpecz127";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs127").src = tripleZeroA;
};

function squareToSzzZValue128(){
    value25aSave = "zSqrArtSpecz128";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs128").src = tripleZeroA;
};

function squareToSzzZValue129(){
    value25aSave = "zSqrArtSpecz129";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs129").src = tripleZeroA;
};

function squareToSzzZValue130(){
    value25aSave = "zSqrArtSpecz130";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs130").src = tripleZeroA;
};

function squareToSzzZValue131(){
    value25aSave = "zSqrArtSpecz131";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs131").src = tripleZeroA;
};

function squareToSzzZValue132(){
    value25aSave = "zSqrArtSpecz132";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs132").src = tripleZeroA;
};

function squareToSzzZValue133(){
    value25aSave = "zSqrArtSpecz133";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs133").src = tripleZeroA;
};

function squareToSzzZValue134(){
    value25aSave = "zSqrArtSpecz134";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs134").src = tripleZeroA;
};

function squareToSzzZValue135(){
    value25aSave = "zSqrArtSpecz135";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs135").src = tripleZeroA;
};

function squareToSzzZValue136(){
    value25aSave = "zSqrArtSpecz136";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs136").src = tripleZeroA;
};

function squareToSzzZValue137(){
    value25aSave = "zSqrArtSpecz137";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs137").src = tripleZeroA;
};

function squareToSzzZValue138(){
    value25aSave = "zSqrArtSpecz138";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs138").src = tripleZeroA;
};

function squareToSzzZValue139(){
    value25aSave = "zSqrArtSpecz139";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs139").src = tripleZeroA;
};

function squareToSzzZValue140(){
    value25aSave = "zSqrArtSpecz140";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs140").src = tripleZeroA;
};

function squareToSzzZValue141(){
    value25aSave = "zSqrArtSpecz141";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs141").src = tripleZeroA;
};

function squareToSzzZValue142(){
    value25aSave = "zSqrArtSpecz142";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs142").src = tripleZeroA;
};

function squareToSzzZValue143(){
    value25aSave = "zSqrArtSpecz143";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs143").src = tripleZeroA;
};

function squareToSzzZValue144(){
    value25aSave = "zSqrArtSpecz144";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs144").src = tripleZeroA;
};

function squareToSzzZValue145(){
    value25aSave = "zSqrArtSpecz145";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs145").src = tripleZeroA;
};

function squareToSzzZValue146(){
    value25aSave = "zSqrArtSpecz146";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs146").src = tripleZeroA;
};

function squareToSzzZValue147(){
    value25aSave = "zSqrArtSpecz147";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs147").src = tripleZeroA;
};

function squareToSzzZValue148(){
    value25aSave = "zSqrArtSpecz148";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs148").src = tripleZeroA;
};

function squareToSzzZValue149(){
    value25aSave = "zSqrArtSpecz149";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs149").src = tripleZeroA;
};

function squareToSzzZValue150(){
    value25aSave = "zSqrArtSpecz150";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs150").src = tripleZeroA;
};

function squareToSzzZValue151(){
    value25aSave = "zSqrArtSpecz151";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs151").src = tripleZeroA;
};

function squareToSzzZValue152(){
    value25aSave = "zSqrArtSpecz152";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs152").src = tripleZeroA;
};

function squareToSzzZValue153(){
    value25aSave = "zSqrArtSpecz153";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs153").src = tripleZeroA;
};

function squareToSzzZValue154(){
    value25aSave = "zSqrArtSpecz154";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs154").src = tripleZeroA;
};

function squareToSzzZValue155(){
    value25aSave = "zSqrArtSpecz155";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs155").src = tripleZeroA;
};

function squareToSzzZValue156(){
    value25aSave = "zSqrArtSpecz156";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs156").src = tripleZeroA;
};

function squareToSzzZValue157(){
    value25aSave = "zSqrArtSpecz157";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs157").src = tripleZeroA;
};

function squareToSzzZValue158(){
    value25aSave = "zSqrArtSpecz158";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs158").src = tripleZeroA;
};

function squareToSzzZValue159(){
    value25aSave = "zSqrArtSpecz159";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs159").src = tripleZeroA;
};

function squareToSzzZValue160(){
    value25aSave = "zSqrArtSpecz160";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs160").src = tripleZeroA;
};

function squareToSzzZValue161(){
    value25aSave = "zSqrArtSpecz161";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs161").src = tripleZeroA;
};

function squareToSzzZValue162(){
    value25aSave = "zSqrArtSpecz162";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs162").src = tripleZeroA;
};

function squareToSzzZValue163(){
    value25aSave = "zSqrArtSpecz163";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs163").src = tripleZeroA;
};

function squareToSzzZValue164(){
    value25aSave = "zSqrArtSpecz164";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs164").src = tripleZeroA;
};

function squareToSzzZValue165(){
    value25aSave = "zSqrArtSpecz165";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs165").src = tripleZeroA;
};

function squareToSzzZValue166(){
    value25aSave = "zSqrArtSpecz166";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs166").src = tripleZeroA;
};

function squareToSzzZValue167(){
    value25aSave = "zSqrArtSpecz167";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs167").src = tripleZeroA;
};

function squareToSzzZValue168(){
    value25aSave = "zSqrArtSpecz168";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs168").src = tripleZeroA;
};

function squareToSzzZValue169(){
    value25aSave = "zSqrArtSpecz169";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs169").src = tripleZeroA;
};

function squareToSzzZValue170(){
    value25aSave = "zSqrArtSpecz170";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs170").src = tripleZeroA;
};

function squareToSzzZValue171(){
    value25aSave = "zSqrArtSpecz171";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs171").src = tripleZeroA;
};

function squareToSzzZValue172(){
    value25aSave = "zSqrArtSpecz172";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs172").src = tripleZeroA;
};

function squareToSzzZValue173(){
    value25aSave = "zSqrArtSpecz173";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs173").src = tripleZeroA;
};

function squareToSzzZValue174(){
    value25aSave = "zSqrArtSpecz174";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs174").src = tripleZeroA;
};

function squareToSzzZValue175(){
    value25aSave = "zSqrArtSpecz175";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs175").src = tripleZeroA;
};

function squareToSzzZValue176(){
    value25aSave = "zSqrArtSpecz176";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs176").src = tripleZeroA;
};

function squareToSzzZValue177(){
    value25aSave = "zSqrArtSpecz177";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs177").src = tripleZeroA;
};

function squareToSzzZValue178(){
    value25aSave = "zSqrArtSpecz178";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs178").src = tripleZeroA;
};

function squareToSzzZValue179(){
    value25aSave = "zSqrArtSpecz179";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs179").src = tripleZeroA;
};

function squareToSzzZValue180(){
    value25aSave = "zSqrArtSpecz180";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs180").src = tripleZeroA;
};

function squareToSzzZValue181(){
    value25aSave = "zSqrArtSpecz181";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs181").src = tripleZeroA;
};

function squareToSzzZValue182(){
    value25aSave = "zSqrArtSpecz182";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs182").src = tripleZeroA;
};

function squareToSzzZValue183(){
    value25aSave = "zSqrArtSpecz183";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs183").src = tripleZeroA;
};

function squareToSzzZValue184(){
    value25aSave = "zSqrArtSpecz184";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs184").src = tripleZeroA;
};

function squareToSzzZValue185(){
    value25aSave = "zSqrArtSpecz185";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs185").src = tripleZeroA;
};

function squareToSzzZValue186(){
    value25aSave = "zSqrArtSpecz186";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs186").src = tripleZeroA;
};

function squareToSzzZValue187(){
    value25aSave = "zSqrArtSpecz187";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs187").src = tripleZeroA;
};

function squareToSzzZValue188(){
    value25aSave = "zSqrArtSpecz188";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs188").src = tripleZeroA;
};

function squareToSzzZValue189(){
    value25aSave = "zSqrArtSpecz189";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs189").src = tripleZeroA;
};

function squareToSzzZValue190(){
    value25aSave = "zSqrArtSpecz190";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs190").src = tripleZeroA;
};

function squareToSzzZValue191(){
    value25aSave = "zSqrArtSpecz191";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs191").src = tripleZeroA;
};

function squareToSzzZValue192(){
    value25aSave = "zSqrArtSpecz192";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs192").src = tripleZeroA;
};

function squareToSzzZValue193(){
    value25aSave = "zSqrArtSpecz193";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs193").src = tripleZeroA;
};

function squareToSzzZValue194(){
    value25aSave = "zSqrArtSpecz194";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs194").src = tripleZeroA;
};

function squareToSzzZValue195(){
    value25aSave = "zSqrArtSpecz195";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs195").src = tripleZeroA;
};

function squareToSzzZValue196(){
    value25aSave = "zSqrArtSpecz196";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs196").src = tripleZeroA;
};

function squareToSzzZValue197(){
    value25aSave = "zSqrArtSpecz197";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs197").src = tripleZeroA;
};

function squareToSzzZValue198(){
    value25aSave = "zSqrArtSpecz198";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs198").src = tripleZeroA;
};

function squareToSzzZValue199(){
    value25aSave = "zSqrArtSpecz199";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs199").src = tripleZeroA;
};

function squareToSzzZValue200(){
    value25aSave = "zSqrArtSpecz200";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs200").src = tripleZeroA;
};

function squareToSzzZValue201(){
    value25aSave = "zSqrArtSpecz201";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs201").src = tripleZeroA;
};

function squareToSzzZValue202(){
    value25aSave = "zSqrArtSpecz202";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs202").src = tripleZeroA;
};

function squareToSzzZValue203(){
    value25aSave = "zSqrArtSpecz203";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs203").src = tripleZeroA;
};

function squareToSzzZValue204(){
    value25aSave = "zSqrArtSpecz204";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs204").src = tripleZeroA;
};

function squareToSzzZValue205(){
    value25aSave = "zSqrArtSpecz205";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs205").src = tripleZeroA;
};

function squareToSzzZValue206(){
    value25aSave = "zSqrArtSpecz206";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs206").src = tripleZeroA;
};

function squareToSzzZValue207(){
    value25aSave = "zSqrArtSpecz207";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs207").src = tripleZeroA;
};

function squareToSzzZValue208(){
    value25aSave = "zSqrArtSpecz208";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs208").src = tripleZeroA;
};

function squareToSzzZValue209(){
    value25aSave = "zSqrArtSpecz209";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs209").src = tripleZeroA;
};

function squareToSzzZValue210(){
    value25aSave = "zSqrArtSpecz210";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs210").src = tripleZeroA;
};

function squareToSzzZValue211(){
    value25aSave = "zSqrArtSpecz211";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs211").src = tripleZeroA;
};

function squareToSzzZValue212(){
    value25aSave = "zSqrArtSpecz212";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs212").src = tripleZeroA;
};

function squareToSzzZValue213(){
    value25aSave = "zSqrArtSpecz213";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs213").src = tripleZeroA;
};

function squareToSzzZValue214(){
    value25aSave = "zSqrArtSpecz214";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs214").src = tripleZeroA;
};

function squareToSzzZValue215(){
    value25aSave = "zSqrArtSpecz215";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs215").src = tripleZeroA;
};

function squareToSzzZValue216(){
    value25aSave = "zSqrArtSpecz216";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs216").src = tripleZeroA;
};

function squareToSzzZValue217(){
    value25aSave = "zSqrArtSpecz217";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs217").src = tripleZeroA;
};

function squareToSzzZValue218(){
    value25aSave = "zSqrArtSpecz218";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs218").src = tripleZeroA;
};

function squareToSzzZValue219(){
    value25aSave = "zSqrArtSpecz219";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs219").src = tripleZeroA;
};

function squareToSzzZValue220(){
    value25aSave = "zSqrArtSpecz220";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs220").src = tripleZeroA;
};

function squareToSzzZValue221(){
    value25aSave = "zSqrArtSpecz221";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs221").src = tripleZeroA;
};

function squareToSzzZValue222(){
    value25aSave = "zSqrArtSpecz222";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs222").src = tripleZeroA;
};

function squareToSzzZValue223(){
    value25aSave = "zSqrArtSpecz223";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs223").src = tripleZeroA;
};

function squareToSzzZValue224(){
    value25aSave = "zSqrArtSpecz224";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs224").src = tripleZeroA;
};

function squareToSzzZValue225(){
    value25aSave = "zSqrArtSpecz225";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs225").src = tripleZeroA;
};

function squareToSzzZValue226(){
    value25aSave = "zSqrArtSpecz226";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs226").src = tripleZeroA;
};

function squareToSzzZValue227(){
    value25aSave = "zSqrArtSpecz227";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs227").src = tripleZeroA;
};

function squareToSzzZValue228(){
    value25aSave = "zSqrArtSpecz228";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs228").src = tripleZeroA;
};

function squareToSzzZValue229(){
    value25aSave = "zSqrArtSpecz229";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs229").src = tripleZeroA;
};

function squareToSzzZValue230(){
    value25aSave = "zSqrArtSpecz230";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs230").src = tripleZeroA;
};

function squareToSzzZValue231(){
    value25aSave = "zSqrArtSpecz231";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs231").src = tripleZeroA;
};

function squareToSzzZValue232(){
    value25aSave = "zSqrArtSpecz232";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs232").src = tripleZeroA;
};

function squareToSzzZValue233(){
    value25aSave = "zSqrArtSpecz233";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs233").src = tripleZeroA;
};

function squareToSzzZValue234(){
    value25aSave = "zSqrArtSpecz234";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs234").src = tripleZeroA;
};

function squareToSzzZValue235(){
    value25aSave = "zSqrArtSpecz235";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs235").src = tripleZeroA;
};

function squareToSzzZValue236(){
    value25aSave = "zSqrArtSpecz236";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs236").src = tripleZeroA;
};

function squareToSzzZValue237(){
    value25aSave = "zSqrArtSpecz237";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs237").src = tripleZeroA;
};

function squareToSzzZValue238(){
    value25aSave = "zSqrArtSpecz238";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs238").src = tripleZeroA;
};

function squareToSzzZValue239(){
    value25aSave = "zSqrArtSpecz239";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs239").src = tripleZeroA;
};

function squareToSzzZValue240(){
    value25aSave = "zSqrArtSpecz240";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs240").src = tripleZeroA;
};

function squareToSzzZValue241(){
    value25aSave = "zSqrArtSpecz241";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs241").src = tripleZeroA;
};

function squareToSzzZValue242(){
    value25aSave = "zSqrArtSpecz242";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs242").src = tripleZeroA;
};

function squareToSzzZValue243(){
    value25aSave = "zSqrArtSpecz243";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs243").src = tripleZeroA;
};

function squareToSzzZValue244(){
    value25aSave = "zSqrArtSpecz244";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs244").src = tripleZeroA;
};

function squareToSzzZValue245(){
    value25aSave = "zSqrArtSpecz245";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs245").src = tripleZeroA;
};

function squareToSzzZValue246(){
    value25aSave = "zSqrArtSpecz246";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs246").src = tripleZeroA;
};

function squareToSzzZValue247(){
    value25aSave = "zSqrArtSpecz247";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs247").src = tripleZeroA;
};

function squareToSzzZValue248(){
    value25aSave = "zSqrArtSpecz248";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs248").src = tripleZeroA;
};

function squareToSzzZValue249(){
    value25aSave = "zSqrArtSpecz249";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs249").src = tripleZeroA;
};

function squareToSzzZValue250(){
    value25aSave = "zSqrArtSpecz250";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs250").src = tripleZeroA;
};

function squareToSzzZValue251(){
    value25aSave = "zSqrArtSpecz251";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs251").src = tripleZeroA;
};

function squareToSzzZValue252(){
    value25aSave = "zSqrArtSpecz252";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs252").src = tripleZeroA;
};

function squareToSzzZValue253(){
    value25aSave = "zSqrArtSpecz253";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs253").src = tripleZeroA;
};

function squareToSzzZValue254(){
    value25aSave = "zSqrArtSpecz254";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs254").src = tripleZeroA;
};

function squareToSzzZValue255(){
    value25aSave = "zSqrArtSpecz255";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs255").src = tripleZeroA;
};

function squareToSzzZValue256(){
    value25aSave = "zSqrArtSpecz256";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs256").src = tripleZeroA;
};

function squareToSzzZValue257(){
    value25aSave = "zSqrArtSpecz257";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs257").src = tripleZeroA;
};

function squareToSzzZValue258(){
    value25aSave = "zSqrArtSpecz258";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs258").src = tripleZeroA;
};

function squareToSzzZValue259(){
    value25aSave = "zSqrArtSpecz259";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs259").src = tripleZeroA;
};

function squareToSzzZValue260(){
    value25aSave = "zSqrArtSpecz260";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs260").src = tripleZeroA;
};

function squareToSzzZValue261(){
    value25aSave = "zSqrArtSpecz261";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs261").src = tripleZeroA;
};

function squareToSzzZValue262(){
    value25aSave = "zSqrArtSpecz262";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs262").src = tripleZeroA;
};

function squareToSzzZValue263(){
    value25aSave = "zSqrArtSpecz263";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs263").src = tripleZeroA;
};

function squareToSzzZValue264(){
    value25aSave = "zSqrArtSpecz264";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs264").src = tripleZeroA;
};

function squareToSzzZValue265(){
    value25aSave = "zSqrArtSpecz265";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs265").src = tripleZeroA;
};

function squareToSzzZValue266(){
    value25aSave = "zSqrArtSpecz266";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs266").src = tripleZeroA;
};

function squareToSzzZValue267(){
    value25aSave = "zSqrArtSpecz267";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs267").src = tripleZeroA;
};

function squareToSzzZValue268(){
    value25aSave = "zSqrArtSpecz268";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs268").src = tripleZeroA;
};

function squareToSzzZValue269(){
    value25aSave = "zSqrArtSpecz269";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs269").src = tripleZeroA;
};

function squareToSzzZValue270(){
    value25aSave = "zSqrArtSpecz270";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs270").src = tripleZeroA;
};

function squareToSzzZValue271(){
    value25aSave = "zSqrArtSpecz271";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs271").src = tripleZeroA;
};

function squareToSzzZValue272(){
    value25aSave = "zSqrArtSpecz272";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs272").src = tripleZeroA;
};

function squareToSzzZValue273(){
    value25aSave = "zSqrArtSpecz273";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs273").src = tripleZeroA;
};

function squareToSzzZValue274(){
    value25aSave = "zSqrArtSpecz274";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs274").src = tripleZeroA;
};

function squareToSzzZValue275(){
    value25aSave = "zSqrArtSpecz275";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs275").src = tripleZeroA;
};

function squareToSzzZValue276(){
    value25aSave = "zSqrArtSpecz276";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs276").src = tripleZeroA;
};

function squareToSzzZValue277(){
    value25aSave = "zSqrArtSpecz277";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs277").src = tripleZeroA;
};

function squareToSzzZValue278(){
    value25aSave = "zSqrArtSpecz278";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs278").src = tripleZeroA;
};

function squareToSzzZValue279(){
    value25aSave = "zSqrArtSpecz279";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs279").src = tripleZeroA;
};

function squareToSzzZValue280(){
    value25aSave = "zSqrArtSpecz280";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs280").src = tripleZeroA;
};

function squareToSzzZValue281(){
    value25aSave = "zSqrArtSpecz281";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs281").src = tripleZeroA;
};

function squareToSzzZValue282(){
    value25aSave = "zSqrArtSpecz282";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs282").src = tripleZeroA;
};

function squareToSzzZValue283(){
    value25aSave = "zSqrArtSpecz283";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs283").src = tripleZeroA;
};

function squareToSzzZValue284(){
    value25aSave = "zSqrArtSpecz284";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs284").src = tripleZeroA;
};

function squareToSzzZValue285(){
    value25aSave = "zSqrArtSpecz285";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs285").src = tripleZeroA;
};

function squareToSzzZValue286(){
    value25aSave = "zSqrArtSpecz286";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs286").src = tripleZeroA;
};

function squareToSzzZValue287(){
    value25aSave = "zSqrArtSpecz287";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs287").src = tripleZeroA;
};

function squareToSzzZValue288(){
    value25aSave = "zSqrArtSpecz288";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs288").src = tripleZeroA;
};

function squareToSzzZValue289(){
    value25aSave = "zSqrArtSpecz289";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs289").src = tripleZeroA;
};

function squareToSzzZValue290(){
    value25aSave = "zSqrArtSpecz290";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs290").src = tripleZeroA;
};

function squareToSzzZValue291(){
    value25aSave = "zSqrArtSpecz291";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs291").src = tripleZeroA;
};

function squareToSzzZValue292(){
    value25aSave = "zSqrArtSpecz292";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs292").src = tripleZeroA;
};

function squareToSzzZValue293(){
    value25aSave = "zSqrArtSpecz293";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs293").src = tripleZeroA;
};

function squareToSzzZValue294(){
    value25aSave = "zSqrArtSpecz294";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs294").src = tripleZeroA;
};

function squareToSzzZValue295(){
    value25aSave = "zSqrArtSpecz295";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs295").src = tripleZeroA;
};

function squareToSzzZValue296(){
    value25aSave = "zSqrArtSpecz296";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs296").src = tripleZeroA;
};

function squareToSzzZValue297(){
    value25aSave = "zSqrArtSpecz297";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs297").src = tripleZeroA;
};

function squareToSzzZValue298(){
    value25aSave = "zSqrArtSpecz298";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs298").src = tripleZeroA;
};

function squareToSzzZValue299(){
    value25aSave = "zSqrArtSpecz299";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs299").src = tripleZeroA;
};

function squareToSzzZValue300(){
    value25aSave = "zSqrArtSpecz300";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs300").src = tripleZeroA;
};

function squareToSzzZValue301(){
    value25aSave = "zSqrArtSpecz301";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs301").src = tripleZeroA;
};

function squareToSzzZValue302(){
    value25aSave = "zSqrArtSpecz302";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs302").src = tripleZeroA;
};

function squareToSzzZValue303(){
    value25aSave = "zSqrArtSpecz303";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs303").src = tripleZeroA;
};

function squareToSzzZValue304(){
    value25aSave = "zSqrArtSpecz304";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs304").src = tripleZeroA;
};

function squareToSzzZValue305(){
    value25aSave = "zSqrArtSpecz305";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs305").src = tripleZeroA;
};

function squareToSzzZValue306(){
    value25aSave = "zSqrArtSpecz306";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs306").src = tripleZeroA;
};

function squareToSzzZValue307(){
    value25aSave = "zSqrArtSpecz307";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs307").src = tripleZeroA;
};

function squareToSzzZValue308(){
    value25aSave = "zSqrArtSpecz308";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs308").src = tripleZeroA;
};

function squareToSzzZValue309(){
    value25aSave = "zSqrArtSpecz309";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs309").src = tripleZeroA;
};

function squareToSzzZValue310(){
    value25aSave = "zSqrArtSpecz310";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs310").src = tripleZeroA;
};

function squareToSzzZValue311(){
    value25aSave = "zSqrArtSpecz311";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs311").src = tripleZeroA;
};

function squareToSzzZValue312(){
    value25aSave = "zSqrArtSpecz312";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs312").src = tripleZeroA;
};

function squareToSzzZValue313(){
    value25aSave = "zSqrArtSpecz313";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs313").src = tripleZeroA;
};

function squareToSzzZValue314(){
    value25aSave = "zSqrArtSpecz314";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs314").src = tripleZeroA;
};

function squareToSzzZValue315(){
    value25aSave = "zSqrArtSpecz315";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs315").src = tripleZeroA;
};

function squareToSzzZValue316(){
    value25aSave = "zSqrArtSpecz316";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs316").src = tripleZeroA;
};

function squareToSzzZValue317(){
    value25aSave = "zSqrArtSpecz317";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs317").src = tripleZeroA;
};

function squareToSzzZValue318(){
    value25aSave = "zSqrArtSpecz318";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs318").src = tripleZeroA;
};

function squareToSzzZValue319(){
    value25aSave = "zSqrArtSpecz319";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs319").src = tripleZeroA;
};

function squareToSzzZValue320(){
    value25aSave = "zSqrArtSpecz320";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs320").src = tripleZeroA;
};

function squareToSzzZValue321(){
    value25aSave = "zSqrArtSpecz321";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs321").src = tripleZeroA;
};

function squareToSzzZValue322(){
    value25aSave = "zSqrArtSpecz322";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs322").src = tripleZeroA;
};

function squareToSzzZValue323(){
    value25aSave = "zSqrArtSpecz323";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs323").src = tripleZeroA;
};

function squareToSzzZValue324(){
    value25aSave = "zSqrArtSpecz324";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs324").src = tripleZeroA;
};

function squareToSzzZValue325(){
    value25aSave = "zSqrArtSpecz325";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs325").src = tripleZeroA;
};

function squareToSzzZValue326(){
    value25aSave = "zSqrArtSpecz326";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs326").src = tripleZeroA;
};

function squareToSzzZValue327(){
    value25aSave = "zSqrArtSpecz327";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs327").src = tripleZeroA;
};

function squareToSzzZValue328(){
    value25aSave = "zSqrArtSpecz328";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs328").src = tripleZeroA;
};

function squareToSzzZValue329(){
    value25aSave = "zSqrArtSpecz329";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs329").src = tripleZeroA;
};

function squareToSzzZValue330(){
    value25aSave = "zSqrArtSpecz330";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs330").src = tripleZeroA;
};

function squareToSzzZValue331(){
    value25aSave = "zSqrArtSpecz331";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs331").src = tripleZeroA;
};

function squareToSzzZValue332(){
    value25aSave = "zSqrArtSpecz332";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs332").src = tripleZeroA;
};

function squareToSzzZValue333(){
    value25aSave = "zSqrArtSpecz333";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs333").src = tripleZeroA;
};

function squareToSzzZValue334(){
    value25aSave = "zSqrArtSpecz334";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs334").src = tripleZeroA;
};

function squareToSzzZValue335(){
    value25aSave = "zSqrArtSpecz335";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs335").src = tripleZeroA;
};

function squareToSzzZValue336(){
    value25aSave = "zSqrArtSpecz336";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs336").src = tripleZeroA;
};

function squareToSzzZValue337(){
    value25aSave = "zSqrArtSpecz337";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs337").src = tripleZeroA;
};

function squareToSzzZValue338(){
    value25aSave = "zSqrArtSpecz338";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs338").src = tripleZeroA;
};

function squareToSzzZValue339(){
    value25aSave = "zSqrArtSpecz339";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs339").src = tripleZeroA;
};

function squareToSzzZValue340(){
    value25aSave = "zSqrArtSpecz340";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs340").src = tripleZeroA;
};

function squareToSzzZValue341(){
    value25aSave = "zSqrArtSpecz341";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs341").src = tripleZeroA;
};

function squareToSzzZValue342(){
    value25aSave = "zSqrArtSpecz342";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs342").src = tripleZeroA;
};

function squareToSzzZValue343(){
    value25aSave = "zSqrArtSpecz343";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs343").src = tripleZeroA;
};

function squareToSzzZValue344(){
    value25aSave = "zSqrArtSpecz344";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs344").src = tripleZeroA;
};

function squareToSzzZValue345(){
    value25aSave = "zSqrArtSpecz345";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs345").src = tripleZeroA;
};

function squareToSzzZValue346(){
    value25aSave = "zSqrArtSpecz346";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs346").src = tripleZeroA;
};

function squareToSzzZValue347(){
    value25aSave = "zSqrArtSpecz347";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs347").src = tripleZeroA;
};

function squareToSzzZValue348(){
    value25aSave = "zSqrArtSpecz348";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs348").src = tripleZeroA;
};

function squareToSzzZValue349(){
    value25aSave = "zSqrArtSpecz349";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs349").src = tripleZeroA;
};

function squareToSzzZValue350(){
    value25aSave = "zSqrArtSpecz350";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs350").src = tripleZeroA;
};

function squareToSzzZValue351(){
    value25aSave = "zSqrArtSpecz351";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs351").src = tripleZeroA;
};

function squareToSzzZValue352(){
    value25aSave = "zSqrArtSpecz352";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs352").src = tripleZeroA;
};

function squareToSzzZValue353(){
    value25aSave = "zSqrArtSpecz353";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs353").src = tripleZeroA;
};

function squareToSzzZValue354(){
    value25aSave = "zSqrArtSpecz354";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs354").src = tripleZeroA;
};

function squareToSzzZValue355(){
    value25aSave = "zSqrArtSpecz355";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs355").src = tripleZeroA;
};

function squareToSzzZValue356(){
    value25aSave = "zSqrArtSpecz356";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs356").src = tripleZeroA;
};

function squareToSzzZValue357(){
    value25aSave = "zSqrArtSpecz357";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs357").src = tripleZeroA;
};

function squareToSzzZValue358(){
    value25aSave = "zSqrArtSpecz358";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs358").src = tripleZeroA;
};

function squareToSzzZValue359(){
    value25aSave = "zSqrArtSpecz359";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs359").src = tripleZeroA;
};

function squareToSzzZValue360(){
    value25aSave = "zSqrArtSpecz360";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs360").src = tripleZeroA;
};

function squareToSzzZValue361(){
    value25aSave = "zSqrArtSpecz361";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs361").src = tripleZeroA;
};

function squareToSzzZValue362(){
    value25aSave = "zSqrArtSpecz362";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs362").src = tripleZeroA;
};

function squareToSzzZValue363(){
    value25aSave = "zSqrArtSpecz363";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs363").src = tripleZeroA;
};

function squareToSzzZValue364(){
    value25aSave = "zSqrArtSpecz364";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs364").src = tripleZeroA;
};

function squareToSzzZValue365(){
    value25aSave = "zSqrArtSpecz365";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs365").src = tripleZeroA;
};

function squareToSzzZValue366(){
    value25aSave = "zSqrArtSpecz366";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs366").src = tripleZeroA;
};

function squareToSzzZValue367(){
    value25aSave = "zSqrArtSpecz367";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs367").src = tripleZeroA;
};

function squareToSzzZValue368(){
    value25aSave = "zSqrArtSpecz368";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs368").src = tripleZeroA;
};

function squareToSzzZValue369(){
    value25aSave = "zSqrArtSpecz369";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs369").src = tripleZeroA;
};

function squareToSzzZValue370(){
    value25aSave = "zSqrArtSpecz370";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs370").src = tripleZeroA;
};

function squareToSzzZValue371(){
    value25aSave = "zSqrArtSpecz371";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs371").src = tripleZeroA;
};

function squareToSzzZValue372(){
    value25aSave = "zSqrArtSpecz372";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs372").src = tripleZeroA;
};

function squareToSzzZValue373(){
    value25aSave = "zSqrArtSpecz373";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs373").src = tripleZeroA;
};

function squareToSzzZValue374(){
    value25aSave = "zSqrArtSpecz374";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs374").src = tripleZeroA;
};

function squareToSzzZValue375(){
    value25aSave = "zSqrArtSpecz375";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs375").src = tripleZeroA;
};

function squareToSzzZValue376(){
    value25aSave = "zSqrArtSpecz376";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs376").src = tripleZeroA;
};

function squareToSzzZValue377(){
    value25aSave = "zSqrArtSpecz377";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs377").src = tripleZeroA;
};

function squareToSzzZValue378(){
    value25aSave = "zSqrArtSpecz378";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs378").src = tripleZeroA;
};

function squareToSzzZValue379(){
    value25aSave = "zSqrArtSpecz379";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs379").src = tripleZeroA;
};

function squareToSzzZValue380(){
    value25aSave = "zSqrArtSpecz380";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs380").src = tripleZeroA;
};

function squareToSzzZValue381(){
    value25aSave = "zSqrArtSpecz381";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs381").src = tripleZeroA;
};

function squareToSzzZValue382(){
    value25aSave = "zSqrArtSpecz382";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs382").src = tripleZeroA;
};

function squareToSzzZValue383(){
    value25aSave = "zSqrArtSpecz383";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs383").src = tripleZeroA;
};

function squareToSzzZValue384(){
    value25aSave = "zSqrArtSpecz384";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs384").src = tripleZeroA;
};

function squareToSzzZValue385(){
    value25aSave = "zSqrArtSpecz385";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs385").src = tripleZeroA;
};

function squareToSzzZValue386(){
    value25aSave = "zSqrArtSpecz386";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs386").src = tripleZeroA;
};

function squareToSzzZValue387(){
    value25aSave = "zSqrArtSpecz387";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs387").src = tripleZeroA;
};

function squareToSzzZValue388(){
    value25aSave = "zSqrArtSpecz388";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs388").src = tripleZeroA;
};

function squareToSzzZValue389(){
    value25aSave = "zSqrArtSpecz389";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs389").src = tripleZeroA;
};

function squareToSzzZValue390(){
    value25aSave = "zSqrArtSpecz390";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs390").src = tripleZeroA;
};

function squareToSzzZValue391(){
    value25aSave = "zSqrArtSpecz391";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs391").src = tripleZeroA;
};

function squareToSzzZValue392(){
    value25aSave = "zSqrArtSpecz392";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs392").src = tripleZeroA;
};

function squareToSzzZValue393(){
    value25aSave = "zSqrArtSpecz393";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs393").src = tripleZeroA;
};

function squareToSzzZValue394(){
    value25aSave = "zSqrArtSpecz394";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs394").src = tripleZeroA;
};

function squareToSzzZValue395(){
    value25aSave = "zSqrArtSpecz395";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs395").src = tripleZeroA;
};

function squareToSzzZValue396(){
    value25aSave = "zSqrArtSpecz396";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs396").src = tripleZeroA;
};

function squareToSzzZValue397(){
    value25aSave = "zSqrArtSpecz397";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs397").src = tripleZeroA;
};

function squareToSzzZValue398(){
    value25aSave = "zSqrArtSpecz398";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs398").src = tripleZeroA;
};

function squareToSzzZValue399(){
    value25aSave = "zSqrArtSpecz399";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs399").src = tripleZeroA;
};

function squareToSzzZValue400(){
    value25aSave = "zSqrArtSpecz400";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs400").src = tripleZeroA;
};

function squareToSzzZValue401(){
    value25aSave = "zSqrArtSpecz401";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs401").src = tripleZeroA;
};

function squareToSzzZValue402(){
    value25aSave = "zSqrArtSpecz402";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs402").src = tripleZeroA;
};

function squareToSzzZValue403(){
    value25aSave = "zSqrArtSpecz403";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs403").src = tripleZeroA;
};

function squareToSzzZValue404(){
    value25aSave = "zSqrArtSpecz404";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs404").src = tripleZeroA;
};

function squareToSzzZValue405(){
    value25aSave = "zSqrArtSpecz405";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs405").src = tripleZeroA;
};

function squareToSzzZValue406(){
    value25aSave = "zSqrArtSpecz406";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs406").src = tripleZeroA;
};

function squareToSzzZValue407(){
    value25aSave = "zSqrArtSpecz407";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs407").src = tripleZeroA;
};

function squareToSzzZValue408(){
    value25aSave = "zSqrArtSpecz408";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs408").src = tripleZeroA;
};

function squareToSzzZValue409(){
    value25aSave = "zSqrArtSpecz409";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs409").src = tripleZeroA;
};

function squareToSzzZValue410(){
    value25aSave = "zSqrArtSpecz410";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs410").src = tripleZeroA;
};

function squareToSzzZValue411(){
    value25aSave = "zSqrArtSpecz411";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs411").src = tripleZeroA;
};

function squareToSzzZValue412(){
    value25aSave = "zSqrArtSpecz412";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs412").src = tripleZeroA;
};

function squareToSzzZValue413(){
    value25aSave = "zSqrArtSpecz413";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs413").src = tripleZeroA;
};

function squareToSzzZValue414(){
    value25aSave = "zSqrArtSpecz414";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs414").src = tripleZeroA;
};

function squareToSzzZValue415(){
    value25aSave = "zSqrArtSpecz415";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs415").src = tripleZeroA;
};

function squareToSzzZValue416(){
    value25aSave = "zSqrArtSpecz416";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs416").src = tripleZeroA;
};

function squareToSzzZValue417(){
    value25aSave = "zSqrArtSpecz417";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs417").src = tripleZeroA;
};

function squareToSzzZValue418(){
    value25aSave = "zSqrArtSpecz418";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs418").src = tripleZeroA;
};

function squareToSzzZValue419(){
    value25aSave = "zSqrArtSpecz419";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs419").src = tripleZeroA;
};

function squareToSzzZValue420(){
    value25aSave = "zSqrArtSpecz420";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs420").src = tripleZeroA;
};

function squareToSzzZValue421(){
    value25aSave = "zSqrArtSpecz421";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs421").src = tripleZeroA;
};

function squareToSzzZValue422(){
    value25aSave = "zSqrArtSpecz422";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs422").src = tripleZeroA;
};

function squareToSzzZValue423(){
    value25aSave = "zSqrArtSpecz423";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs423").src = tripleZeroA;
};

function squareToSzzZValue424(){
    value25aSave = "zSqrArtSpecz424";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs424").src = tripleZeroA;
};

function squareToSzzZValue425(){
    value25aSave = "zSqrArtSpecz425";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs425").src = tripleZeroA;
};

function squareToSzzZValue426(){
    value25aSave = "zSqrArtSpecz426";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs426").src = tripleZeroA;
};

function squareToSzzZValue427(){
    value25aSave = "zSqrArtSpecz427";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs427").src = tripleZeroA;
};

function squareToSzzZValue428(){
    value25aSave = "zSqrArtSpecz428";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs428").src = tripleZeroA;
};

function squareToSzzZValue429(){
    value25aSave = "zSqrArtSpecz429";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs429").src = tripleZeroA;
};

function squareToSzzZValue430(){
    value25aSave = "zSqrArtSpecz430";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs430").src = tripleZeroA;
};

function squareToSzzZValue431(){
    value25aSave = "zSqrArtSpecz431";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs431").src = tripleZeroA;
};

function squareToSzzZValue432(){
    value25aSave = "zSqrArtSpecz432";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs432").src = tripleZeroA;
};

function squareToSzzZValue433(){
    value25aSave = "zSqrArtSpecz433";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs433").src = tripleZeroA;
};

function squareToSzzZValue434(){
    value25aSave = "zSqrArtSpecz434";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs434").src = tripleZeroA;
};

function squareToSzzZValue435(){
    value25aSave = "zSqrArtSpecz435";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs435").src = tripleZeroA;
};

function squareToSzzZValue436(){
    value25aSave = "zSqrArtSpecz436";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs436").src = tripleZeroA;
};

function squareToSzzZValue437(){
    value25aSave = "zSqrArtSpecz437";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs437").src = tripleZeroA;
};

function squareToSzzZValue438(){
    value25aSave = "zSqrArtSpecz438";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs438").src = tripleZeroA;
};

function squareToSzzZValue439(){
    value25aSave = "zSqrArtSpecz439";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs439").src = tripleZeroA;
};

function squareToSzzZValue440(){
    value25aSave = "zSqrArtSpecz440";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs440").src = tripleZeroA;
};

function squareToSzzZValue441(){
    value25aSave = "zSqrArtSpecz441";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs441").src = tripleZeroA;
};

function squareToSzzZValue442(){
    value25aSave = "zSqrArtSpecz442";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs442").src = tripleZeroA;
};

function squareToSzzZValue443(){
    value25aSave = "zSqrArtSpecz443";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs443").src = tripleZeroA;
};

function squareToSzzZValue444(){
    value25aSave = "zSqrArtSpecz444";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs444").src = tripleZeroA;
};

function squareToSzzZValue445(){
    value25aSave = "zSqrArtSpecz445";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs445").src = tripleZeroA;
};

function squareToSzzZValue446(){
    value25aSave = "zSqrArtSpecz446";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs446").src = tripleZeroA;
};

function squareToSzzZValue447(){
    value25aSave = "zSqrArtSpecz447";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs447").src = tripleZeroA;
};

function squareToSzzZValue448(){
    value25aSave = "zSqrArtSpecz448";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs448").src = tripleZeroA;
};

function squareToSzzZValue449(){
    value25aSave = "zSqrArtSpecz449";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs449").src = tripleZeroA;
};

function squareToSzzZValue450(){
    value25aSave = "zSqrArtSpecz450";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs450").src = tripleZeroA;
};

function squareToSzzZValue451(){
    value25aSave = "zSqrArtSpecz451";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs451").src = tripleZeroA;
};

function squareToSzzZValue452(){
    value25aSave = "zSqrArtSpecz452";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs452").src = tripleZeroA;
};

function squareToSzzZValue453(){
    value25aSave = "zSqrArtSpecz453";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs453").src = tripleZeroA;
};

function squareToSzzZValue454(){
    value25aSave = "zSqrArtSpecz454";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs454").src = tripleZeroA;
};

function squareToSzzZValue455(){
    value25aSave = "zSqrArtSpecz455";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs455").src = tripleZeroA;
};

function squareToSzzZValue456(){
    value25aSave = "zSqrArtSpecz456";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs456").src = tripleZeroA;
};

function squareToSzzZValue457(){
    value25aSave = "zSqrArtSpecz457";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs457").src = tripleZeroA;
};

function squareToSzzZValue458(){
    value25aSave = "zSqrArtSpecz458";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs458").src = tripleZeroA;
};

function squareToSzzZValue459(){
    value25aSave = "zSqrArtSpecz459";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs459").src = tripleZeroA;
};

function squareToSzzZValue460(){
    value25aSave = "zSqrArtSpecz460";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs460").src = tripleZeroA;
};

function squareToSzzZValue461(){
    value25aSave = "zSqrArtSpecz461";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs461").src = tripleZeroA;
};

function squareToSzzZValue462(){
    value25aSave = "zSqrArtSpecz462";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs462").src = tripleZeroA;
};

function squareToSzzZValue463(){
    value25aSave = "zSqrArtSpecz463";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs463").src = tripleZeroA;
};

function squareToSzzZValue464(){
    value25aSave = "zSqrArtSpecz464";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs464").src = tripleZeroA;
};

function squareToSzzZValue465(){
    value25aSave = "zSqrArtSpecz465";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs465").src = tripleZeroA;
};

function squareToSzzZValue466(){
    value25aSave = "zSqrArtSpecz466";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs466").src = tripleZeroA;
};

function squareToSzzZValue467(){
    value25aSave = "zSqrArtSpecz467";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs467").src = tripleZeroA;
};

function squareToSzzZValue468(){
    value25aSave = "zSqrArtSpecz468";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs468").src = tripleZeroA;
};

function squareToSzzZValue469(){
    value25aSave = "zSqrArtSpecz469";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs469").src = tripleZeroA;
};

function squareToSzzZValue470(){
    value25aSave = "zSqrArtSpecz470";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs470").src = tripleZeroA;
};

function squareToSzzZValue471(){
    value25aSave = "zSqrArtSpecz471";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs471").src = tripleZeroA;
};

function squareToSzzZValue472(){
    value25aSave = "zSqrArtSpecz472";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs472").src = tripleZeroA;
};

function squareToSzzZValue473(){
    value25aSave = "zSqrArtSpecz473";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs473").src = tripleZeroA;
};

function squareToSzzZValue474(){
    value25aSave = "zSqrArtSpecz474";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs474").src = tripleZeroA;
};

function squareToSzzZValue475(){
    value25aSave = "zSqrArtSpecz475";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs475").src = tripleZeroA;
};

function squareToSzzZValue476(){
    value25aSave = "zSqrArtSpecz476";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs476").src = tripleZeroA;
};

function squareToSzzZValue477(){
    value25aSave = "zSqrArtSpecz477";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs477").src = tripleZeroA;
};

function squareToSzzZValue478(){
    value25aSave = "zSqrArtSpecz478";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs478").src = tripleZeroA;
};

function squareToSzzZValue479(){
    value25aSave = "zSqrArtSpecz479";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs479").src = tripleZeroA;
};

function squareToSzzZValue480(){
    value25aSave = "zSqrArtSpecz480";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs480").src = tripleZeroA;
};

function squareToSzzZValue481(){
    value25aSave = "zSqrArtSpecz481";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs481").src = tripleZeroA;
};

function squareToSzzZValue482(){
    value25aSave = "zSqrArtSpecz482";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs482").src = tripleZeroA;
};

function squareToSzzZValue483(){
    value25aSave = "zSqrArtSpecz483";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs483").src = tripleZeroA;
};

function squareToSzzZValue484(){
    value25aSave = "zSqrArtSpecz484";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs484").src = tripleZeroA;
};

function squareToSzzZValue485(){
    value25aSave = "zSqrArtSpecz485";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs485").src = tripleZeroA;
};

function squareToSzzZValue486(){
    value25aSave = "zSqrArtSpecz486";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs486").src = tripleZeroA;
};

function squareToSzzZValue487(){
    value25aSave = "zSqrArtSpecz487";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs487").src = tripleZeroA;
};

function squareToSzzZValue488(){
    value25aSave = "zSqrArtSpecz488";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs488").src = tripleZeroA;
};

function squareToSzzZValue489(){
    value25aSave = "zSqrArtSpecz489";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs489").src = tripleZeroA;
};

function squareToSzzZValue490(){
    value25aSave = "zSqrArtSpecz490";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs490").src = tripleZeroA;
};

function squareToSzzZValue491(){
    value25aSave = "zSqrArtSpecz491";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs491").src = tripleZeroA;
};

function squareToSzzZValue492(){
    value25aSave = "zSqrArtSpecz492";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs492").src = tripleZeroA;
};

function squareToSzzZValue493(){
    value25aSave = "zSqrArtSpecz493";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs493").src = tripleZeroA;
};

function squareToSzzZValue494(){
    value25aSave = "zSqrArtSpecz494";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs494").src = tripleZeroA;
};

function squareToSzzZValue495(){
    value25aSave = "zSqrArtSpecz495";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs495").src = tripleZeroA;
};

function squareToSzzZValue496(){
    value25aSave = "zSqrArtSpecz496";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs496").src = tripleZeroA;
};

function squareToSzzZValue497(){
    value25aSave = "zSqrArtSpecz497";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs497").src = tripleZeroA;
};

function squareToSzzZValue498(){
    value25aSave = "zSqrArtSpecz498";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs498").src = tripleZeroA;
};

function squareToSzzZValue499(){
    value25aSave = "zSqrArtSpecz499";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs499").src = tripleZeroA;
};

function squareToSzzZValue500(){
    value25aSave = "zSqrArtSpecz500";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs500").src = tripleZeroA;
};

function squareToSzzZValue501(){
    value25aSave = "zSqrArtSpecz501";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs501").src = tripleZeroA;
};

function squareToSzzZValue502(){
    value25aSave = "zSqrArtSpecz502";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs502").src = tripleZeroA;
};

function squareToSzzZValue503(){
    value25aSave = "zSqrArtSpecz503";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs503").src = tripleZeroA;
};

function squareToSzzZValue504(){
    value25aSave = "zSqrArtSpecz504";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs504").src = tripleZeroA;
};

function squareToSzzZValue505(){
    value25aSave = "zSqrArtSpecz505";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs505").src = tripleZeroA;
};

function squareToSzzZValue506(){
    value25aSave = "zSqrArtSpecz506";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs506").src = tripleZeroA;
};

function squareToSzzZValue507(){
    value25aSave = "zSqrArtSpecz507";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs507").src = tripleZeroA;
};

function squareToSzzZValue508(){
    value25aSave = "zSqrArtSpecz508";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs508").src = tripleZeroA;
};

function squareToSzzZValue509(){
    value25aSave = "zSqrArtSpecz509";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs509").src = tripleZeroA;
};

function squareToSzzZValue510(){
    value25aSave = "zSqrArtSpecz510";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs510").src = tripleZeroA;
};

function squareToSzzZValue511(){
    value25aSave = "zSqrArtSpecz511";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs511").src = tripleZeroA;
};

function squareToSzzZValue512(){
    value25aSave = "zSqrArtSpecz512";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs512").src = tripleZeroA;
};

function squareToSzzZValue513(){
    value25aSave = "zSqrArtSpecz513";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs513").src = tripleZeroA;
};

function squareToSzzZValue514(){
    value25aSave = "zSqrArtSpecz514";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs514").src = tripleZeroA;
};

function squareToSzzZValue515(){
    value25aSave = "zSqrArtSpecz515";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs515").src = tripleZeroA;
};

function squareToSzzZValue516(){
    value25aSave = "zSqrArtSpecz516";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs516").src = tripleZeroA;
};

function squareToSzzZValue517(){
    value25aSave = "zSqrArtSpecz517";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs517").src = tripleZeroA;
};

function squareToSzzZValue518(){
    value25aSave = "zSqrArtSpecz518";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs518").src = tripleZeroA;
};

function squareToSzzZValue519(){
    value25aSave = "zSqrArtSpecz519";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs519").src = tripleZeroA;
};

function squareToSzzZValue520(){
    value25aSave = "zSqrArtSpecz520";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs520").src = tripleZeroA;
};

function squareToSzzZValue521(){
    value25aSave = "zSqrArtSpecz521";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs521").src = tripleZeroA;
};

function squareToSzzZValue522(){
    value25aSave = "zSqrArtSpecz522";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs522").src = tripleZeroA;
};

function squareToSzzZValue523(){
    value25aSave = "zSqrArtSpecz523";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs523").src = tripleZeroA;
};

function squareToSzzZValue524(){
    value25aSave = "zSqrArtSpecz524";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs524").src = tripleZeroA;
};

function squareToSzzZValue525(){
    value25aSave = "zSqrArtSpecz525";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs525").src = tripleZeroA;
};

function squareToSzzZValue526(){
    value25aSave = "zSqrArtSpecz526";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs526").src = tripleZeroA;
};

function squareToSzzZValue527(){
    value25aSave = "zSqrArtSpecz527";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs527").src = tripleZeroA;
};

function squareToSzzZValue528(){
    value25aSave = "zSqrArtSpecz528";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs528").src = tripleZeroA;
};

function squareToSzzZValue529(){
    value25aSave = "zSqrArtSpecz529";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs529").src = tripleZeroA;
};

function squareToSzzZValue530(){
    value25aSave = "zSqrArtSpecz530";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs530").src = tripleZeroA;
};

function squareToSzzZValue531(){
    value25aSave = "zSqrArtSpecz531";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs531").src = tripleZeroA;
};

function squareToSzzZValue532(){
    value25aSave = "zSqrArtSpecz532";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs532").src = tripleZeroA;
};

function squareToSzzZValue533(){
    value25aSave = "zSqrArtSpecz533";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs533").src = tripleZeroA;
};

function squareToSzzZValue534(){
    value25aSave = "zSqrArtSpecz534";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs534").src = tripleZeroA;
};

function squareToSzzZValue535(){
    value25aSave = "zSqrArtSpecz535";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs535").src = tripleZeroA;
};

function squareToSzzZValue536(){
    value25aSave = "zSqrArtSpecz536";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs536").src = tripleZeroA;
};

function squareToSzzZValue537(){
    value25aSave = "zSqrArtSpecz537";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs537").src = tripleZeroA;
};

function squareToSzzZValue538(){
    value25aSave = "zSqrArtSpecz538";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs538").src = tripleZeroA;
};

function squareToSzzZValue539(){
    value25aSave = "zSqrArtSpecz539";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs539").src = tripleZeroA;
};

function squareToSzzZValue540(){
    value25aSave = "zSqrArtSpecz540";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs540").src = tripleZeroA;
};

function squareToSzzZValue541(){
    value25aSave = "zSqrArtSpecz541";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs541").src = tripleZeroA;
};

function squareToSzzZValue542(){
    value25aSave = "zSqrArtSpecz542";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs542").src = tripleZeroA;
};

function squareToSzzZValue543(){
    value25aSave = "zSqrArtSpecz543";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs543").src = tripleZeroA;
};

function squareToSzzZValue544(){
    value25aSave = "zSqrArtSpecz544";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs544").src = tripleZeroA;
};

function squareToSzzZValue545(){
    value25aSave = "zSqrArtSpecz545";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs545").src = tripleZeroA;
};

function squareToSzzZValue546(){
    value25aSave = "zSqrArtSpecz546";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs546").src = tripleZeroA;
};

function squareToSzzZValue547(){
    value25aSave = "zSqrArtSpecz547";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs547").src = tripleZeroA;
};

function squareToSzzZValue548(){
    value25aSave = "zSqrArtSpecz548";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs548").src = tripleZeroA;
};

function squareToSzzZValue549(){
    value25aSave = "zSqrArtSpecz549";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs549").src = tripleZeroA;
};

function squareToSzzZValue550(){
    value25aSave = "zSqrArtSpecz550";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs550").src = tripleZeroA;
};

function squareToSzzZValue551(){
    value25aSave = "zSqrArtSpecz551";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs551").src = tripleZeroA;
};

function squareToSzzZValue552(){
    value25aSave = "zSqrArtSpecz552";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs552").src = tripleZeroA;
};

function squareToSzzZValue553(){
    value25aSave = "zSqrArtSpecz553";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs553").src = tripleZeroA;
};

function squareToSzzZValue554(){
    value25aSave = "zSqrArtSpecz554";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs554").src = tripleZeroA;
};

function squareToSzzZValue555(){
    value25aSave = "zSqrArtSpecz555";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs555").src = tripleZeroA;
};

function squareToSzzZValue556(){
    value25aSave = "zSqrArtSpecz556";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs556").src = tripleZeroA;
};

function squareToSzzZValue557(){
    value25aSave = "zSqrArtSpecz557";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs557").src = tripleZeroA;
};

function squareToSzzZValue558(){
    value25aSave = "zSqrArtSpecz558";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs558").src = tripleZeroA;
};

function squareToSzzZValue559(){
    value25aSave = "zSqrArtSpecz559";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs559").src = tripleZeroA;
};

function squareToSzzZValue560(){
    value25aSave = "zSqrArtSpecz560";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs560").src = tripleZeroA;
};

function squareToSzzZValue561(){
    value25aSave = "zSqrArtSpecz561";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs561").src = tripleZeroA;
};

function squareToSzzZValue562(){
    value25aSave = "zSqrArtSpecz562";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs562").src = tripleZeroA;
};

function squareToSzzZValue563(){
    value25aSave = "zSqrArtSpecz563";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs563").src = tripleZeroA;
};

function squareToSzzZValue564(){
    value25aSave = "zSqrArtSpecz564";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs564").src = tripleZeroA;
};

function squareToSzzZValue565(){
    value25aSave = "zSqrArtSpecz565";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs565").src = tripleZeroA;
};

function squareToSzzZValue566(){
    value25aSave = "zSqrArtSpecz566";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs566").src = tripleZeroA;
};

function squareToSzzZValue567(){
    value25aSave = "zSqrArtSpecz567";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs567").src = tripleZeroA;
};

function squareToSzzZValue568(){
    value25aSave = "zSqrArtSpecz568";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs568").src = tripleZeroA;
};

function squareToSzzZValue569(){
    value25aSave = "zSqrArtSpecz569";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs569").src = tripleZeroA;
};

function squareToSzzZValue570(){
    value25aSave = "zSqrArtSpecz570";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs570").src = tripleZeroA;
};

function squareToSzzZValue571(){
    value25aSave = "zSqrArtSpecz571";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs571").src = tripleZeroA;
};

function squareToSzzZValue572(){
    value25aSave = "zSqrArtSpecz572";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs572").src = tripleZeroA;
};

function squareToSzzZValue573(){
    value25aSave = "zSqrArtSpecz573";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs573").src = tripleZeroA;
};

function squareToSzzZValue574(){
    value25aSave = "zSqrArtSpecz574";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs574").src = tripleZeroA;
};

function squareToSzzZValue575(){
    value25aSave = "zSqrArtSpecz575";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs575").src = tripleZeroA;
};

function squareToSzzZValue576(){
    value25aSave = "zSqrArtSpecz576";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs576").src = tripleZeroA;
};

function squareToSzzZValue577(){
    value25aSave = "zSqrArtSpecz577";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs577").src = tripleZeroA;
};

function squareToSzzZValue578(){
    value25aSave = "zSqrArtSpecz578";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs578").src = tripleZeroA;
};

function squareToSzzZValue579(){
    value25aSave = "zSqrArtSpecz579";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs579").src = tripleZeroA;
};

function squareToSzzZValue580(){
    value25aSave = "zSqrArtSpecz580";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs580").src = tripleZeroA;
};

function squareToSzzZValue581(){
    value25aSave = "zSqrArtSpecz581";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs581").src = tripleZeroA;
};

function squareToSzzZValue582(){
    value25aSave = "zSqrArtSpecz582";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs582").src = tripleZeroA;
};

function squareToSzzZValue583(){
    value25aSave = "zSqrArtSpecz583";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs583").src = tripleZeroA;
};

function squareToSzzZValue584(){
    value25aSave = "zSqrArtSpecz584";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs584").src = tripleZeroA;
};

function squareToSzzZValue585(){
    value25aSave = "zSqrArtSpecz585";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs585").src = tripleZeroA;
};

function squareToSzzZValue586(){
    value25aSave = "zSqrArtSpecz586";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs586").src = tripleZeroA;
};

function squareToSzzZValue587(){
    value25aSave = "zSqrArtSpecz587";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs587").src = tripleZeroA;
};

function squareToSzzZValue588(){
    value25aSave = "zSqrArtSpecz588";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs588").src = tripleZeroA;
};

function squareToSzzZValue589(){
    value25aSave = "zSqrArtSpecz589";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs589").src = tripleZeroA;
};

function squareToSzzZValue590(){
    value25aSave = "zSqrArtSpecz590";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs590").src = tripleZeroA;
};

function squareToSzzZValue591(){
    value25aSave = "zSqrArtSpecz591";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs591").src = tripleZeroA;
};

function squareToSzzZValue592(){
    value25aSave = "zSqrArtSpecz592";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs592").src = tripleZeroA;
};

function squareToSzzZValue593(){
    value25aSave = "zSqrArtSpecz593";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs593").src = tripleZeroA;
};

function squareToSzzZValue594(){
    value25aSave = "zSqrArtSpecz594";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs594").src = tripleZeroA;
};

function squareToSzzZValue595(){
    value25aSave = "zSqrArtSpecz595";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs595").src = tripleZeroA;
};

function squareToSzzZValue596(){
    value25aSave = "zSqrArtSpecz596";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs596").src = tripleZeroA;
};

function squareToSzzZValue597(){
    value25aSave = "zSqrArtSpecz597";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs597").src = tripleZeroA;
};

function squareToSzzZValue598(){
    value25aSave = "zSqrArtSpecz598";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs598").src = tripleZeroA;
};

function squareToSzzZValue599(){
    value25aSave = "zSqrArtSpecz599";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs599").src = tripleZeroA;
};

function squareToSzzZValue600(){
    value25aSave = "zSqrArtSpecz600";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs600").src = tripleZeroA;
};

function squareToSzzZValue601(){
    value25aSave = "zSqrArtSpecz601";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs601").src = tripleZeroA;
};

function squareToSzzZValue602(){
    value25aSave = "zSqrArtSpecz602";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs602").src = tripleZeroA;
};

function squareToSzzZValue603(){
    value25aSave = "zSqrArtSpecz603";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs603").src = tripleZeroA;
};

function squareToSzzZValue604(){
    value25aSave = "zSqrArtSpecz604";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs604").src = tripleZeroA;
};

function squareToSzzZValue605(){
    value25aSave = "zSqrArtSpecz605";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs605").src = tripleZeroA;
};

function squareToSzzZValue606(){
    value25aSave = "zSqrArtSpecz606";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs606").src = tripleZeroA;
};

function squareToSzzZValue607(){
    value25aSave = "zSqrArtSpecz607";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs607").src = tripleZeroA;
};

function squareToSzzZValue608(){
    value25aSave = "zSqrArtSpecz608";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs608").src = tripleZeroA;
};

function squareToSzzZValue609(){
    value25aSave = "zSqrArtSpecz609";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs609").src = tripleZeroA;
};

function squareToSzzZValue610(){
    value25aSave = "zSqrArtSpecz610";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs610").src = tripleZeroA;
};

function squareToSzzZValue611(){
    value25aSave = "zSqrArtSpecz611";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs611").src = tripleZeroA;
};

function squareToSzzZValue612(){
    value25aSave = "zSqrArtSpecz612";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs612").src = tripleZeroA;
};

function squareToSzzZValue613(){
    value25aSave = "zSqrArtSpecz613";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs613").src = tripleZeroA;
};

function squareToSzzZValue614(){
    value25aSave = "zSqrArtSpecz614";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs614").src = tripleZeroA;
};

function squareToSzzZValue615(){
    value25aSave = "zSqrArtSpecz615";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs615").src = tripleZeroA;
};

function squareToSzzZValue616(){
    value25aSave = "zSqrArtSpecz616";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs616").src = tripleZeroA;
};

function squareToSzzZValue617(){
    value25aSave = "zSqrArtSpecz617";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs617").src = tripleZeroA;
};

function squareToSzzZValue618(){
    value25aSave = "zSqrArtSpecz618";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs618").src = tripleZeroA;
};

function squareToSzzZValue619(){
    value25aSave = "zSqrArtSpecz619";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs619").src = tripleZeroA;
};

function squareToSzzZValue620(){
    value25aSave = "zSqrArtSpecz620";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs620").src = tripleZeroA;
};

function squareToSzzZValue621(){
    value25aSave = "zSqrArtSpecz621";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs621").src = tripleZeroA;
};

function squareToSzzZValue622(){
    value25aSave = "zSqrArtSpecz622";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs622").src = tripleZeroA;
};

function squareToSzzZValue623(){
    value25aSave = "zSqrArtSpecz623";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs623").src = tripleZeroA;
};

function squareToSzzZValue624(){
    value25aSave = "zSqrArtSpecz624";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs624").src = tripleZeroA;
};

function squareToSzzZValue625(){
    value25aSave = "zSqrArtSpecz625";
    var tripleZeroA = localStorage.getItem(value25aSave);
    document.getElementById("imgSqrs625").src = tripleZeroA;
};


function getDThis(){
    squareToSzzZValue1()

    squareToSzzZValue2()

    squareToSzzZValue3()

    squareToSzzZValue4()

    squareToSzzZValue5()

    squareToSzzZValue6()

    squareToSzzZValue7()

    squareToSzzZValue8()

    squareToSzzZValue9()

    squareToSzzZValue10()

    squareToSzzZValue11()

    squareToSzzZValue12()

    squareToSzzZValue13()

    squareToSzzZValue14()

    squareToSzzZValue15()

    squareToSzzZValue16()

    squareToSzzZValue17()

    squareToSzzZValue18()

    squareToSzzZValue19()

    squareToSzzZValue20()

    squareToSzzZValue21()

    squareToSzzZValue22()

    squareToSzzZValue23()

    squareToSzzZValue24()

    squareToSzzZValue25()

    squareToSzzZValue26()

    squareToSzzZValue27()

    squareToSzzZValue28()

    squareToSzzZValue29()

    squareToSzzZValue30()

    squareToSzzZValue31()

    squareToSzzZValue32()

    squareToSzzZValue33()

    squareToSzzZValue34()

    squareToSzzZValue35()

    squareToSzzZValue36()

    squareToSzzZValue37()

    squareToSzzZValue38()

    squareToSzzZValue39()

    squareToSzzZValue40()

    squareToSzzZValue41()

    squareToSzzZValue42()

    squareToSzzZValue43()

    squareToSzzZValue44()

    squareToSzzZValue45()

    squareToSzzZValue46()

    squareToSzzZValue47()

    squareToSzzZValue48()

    squareToSzzZValue49()

    squareToSzzZValue50()

    squareToSzzZValue51()

    squareToSzzZValue52()

    squareToSzzZValue53()

    squareToSzzZValue54()

    squareToSzzZValue55()

    squareToSzzZValue56()

    squareToSzzZValue57()

    squareToSzzZValue58()

    squareToSzzZValue59()

    squareToSzzZValue60()

    squareToSzzZValue61()

    squareToSzzZValue62()

    squareToSzzZValue63()

    squareToSzzZValue64()

    squareToSzzZValue65()

    squareToSzzZValue66()

    squareToSzzZValue67()

    squareToSzzZValue68()

    squareToSzzZValue69()

    squareToSzzZValue70()

    squareToSzzZValue71()

    squareToSzzZValue72()

    squareToSzzZValue73()

    squareToSzzZValue74()

    squareToSzzZValue75()

    squareToSzzZValue76()

    squareToSzzZValue77()

    squareToSzzZValue78()

    squareToSzzZValue79()

    squareToSzzZValue80()

    squareToSzzZValue81()

    squareToSzzZValue82()

    squareToSzzZValue83()

    squareToSzzZValue84()

    squareToSzzZValue85()

    squareToSzzZValue86()

    squareToSzzZValue87()

    squareToSzzZValue88()

    squareToSzzZValue89()

    squareToSzzZValue90()

    squareToSzzZValue91()

    squareToSzzZValue92()

    squareToSzzZValue93()

    squareToSzzZValue94()

    squareToSzzZValue95()

    squareToSzzZValue96()

    squareToSzzZValue97()

    squareToSzzZValue98()

    squareToSzzZValue99()

    squareToSzzZValue100()

    squareToSzzZValue101()

    squareToSzzZValue102()

    squareToSzzZValue103()

    squareToSzzZValue104()

    squareToSzzZValue105()

    squareToSzzZValue106()

    squareToSzzZValue107()

    squareToSzzZValue108()

    squareToSzzZValue109()

    squareToSzzZValue110()

    squareToSzzZValue111()

    squareToSzzZValue112()

    squareToSzzZValue113()

    squareToSzzZValue114()

    squareToSzzZValue115()

    squareToSzzZValue116()

    squareToSzzZValue117()

    squareToSzzZValue118()

    squareToSzzZValue119()

    squareToSzzZValue120()

    squareToSzzZValue121()

    squareToSzzZValue122()

    squareToSzzZValue123()

    squareToSzzZValue124()

    squareToSzzZValue125()

    squareToSzzZValue126()

    squareToSzzZValue127()

    squareToSzzZValue128()

    squareToSzzZValue129()

    squareToSzzZValue130()

    squareToSzzZValue131()

    squareToSzzZValue132()

    squareToSzzZValue133()

    squareToSzzZValue134()

    squareToSzzZValue135()

    squareToSzzZValue136()

    squareToSzzZValue137()

    squareToSzzZValue138()

    squareToSzzZValue139()

    squareToSzzZValue140()

    squareToSzzZValue141()

    squareToSzzZValue142()

    squareToSzzZValue143()

    squareToSzzZValue144()

    squareToSzzZValue145()

    squareToSzzZValue146()

    squareToSzzZValue147()

    squareToSzzZValue148()

    squareToSzzZValue149()

    squareToSzzZValue150()

    squareToSzzZValue151()

    squareToSzzZValue152()

    squareToSzzZValue153()

    squareToSzzZValue154()

    squareToSzzZValue155()

    squareToSzzZValue156()

    squareToSzzZValue157()

    squareToSzzZValue158()

    squareToSzzZValue159()

    squareToSzzZValue160()

    squareToSzzZValue161()

    squareToSzzZValue162()

    squareToSzzZValue163()

    squareToSzzZValue164()

    squareToSzzZValue165()

    squareToSzzZValue166()

    squareToSzzZValue167()

    squareToSzzZValue168()

    squareToSzzZValue169()

    squareToSzzZValue170()

    squareToSzzZValue171()

    squareToSzzZValue172()

    squareToSzzZValue173()

    squareToSzzZValue174()

    squareToSzzZValue175()

    squareToSzzZValue176()

    squareToSzzZValue177()

    squareToSzzZValue178()

    squareToSzzZValue179()

    squareToSzzZValue180()

    squareToSzzZValue181()

    squareToSzzZValue182()

    squareToSzzZValue183()

    squareToSzzZValue184()

    squareToSzzZValue185()

    squareToSzzZValue186()

    squareToSzzZValue187()

    squareToSzzZValue188()

    squareToSzzZValue189()

    squareToSzzZValue190()

    squareToSzzZValue191()

    squareToSzzZValue192()

    squareToSzzZValue193()

    squareToSzzZValue194()

    squareToSzzZValue195()

    squareToSzzZValue196()

    squareToSzzZValue197()

    squareToSzzZValue198()

    squareToSzzZValue199()

    squareToSzzZValue200()

    squareToSzzZValue201()

    squareToSzzZValue202()

    squareToSzzZValue203()

    squareToSzzZValue204()

    squareToSzzZValue205()

    squareToSzzZValue206()

    squareToSzzZValue207()

    squareToSzzZValue208()

    squareToSzzZValue209()

    squareToSzzZValue210()

    squareToSzzZValue211()

    squareToSzzZValue212()

    squareToSzzZValue213()

    squareToSzzZValue214()

    squareToSzzZValue215()

    squareToSzzZValue216()

    squareToSzzZValue217()

    squareToSzzZValue218()

    squareToSzzZValue219()

    squareToSzzZValue220()

    squareToSzzZValue221()

    squareToSzzZValue222()

    squareToSzzZValue223()

    squareToSzzZValue224()

    squareToSzzZValue225()

    squareToSzzZValue226()

    squareToSzzZValue227()

    squareToSzzZValue228()

    squareToSzzZValue229()

    squareToSzzZValue230()

    squareToSzzZValue231()

    squareToSzzZValue232()

    squareToSzzZValue233()

    squareToSzzZValue234()

    squareToSzzZValue235()

    squareToSzzZValue236()

    squareToSzzZValue237()

    squareToSzzZValue238()

    squareToSzzZValue239()

    squareToSzzZValue240()

    squareToSzzZValue241()

    squareToSzzZValue242()

    squareToSzzZValue243()

    squareToSzzZValue244()

    squareToSzzZValue245()

    squareToSzzZValue246()

    squareToSzzZValue247()

    squareToSzzZValue248()

    squareToSzzZValue249()

    squareToSzzZValue250()

    squareToSzzZValue251()

    squareToSzzZValue252()

    squareToSzzZValue253()

    squareToSzzZValue254()

    squareToSzzZValue255()

    squareToSzzZValue256()

    squareToSzzZValue257()

    squareToSzzZValue258()

    squareToSzzZValue259()

    squareToSzzZValue260()

    squareToSzzZValue261()

    squareToSzzZValue262()

    squareToSzzZValue263()

    squareToSzzZValue264()

    squareToSzzZValue265()

    squareToSzzZValue266()

    squareToSzzZValue267()

    squareToSzzZValue268()

    squareToSzzZValue269()

    squareToSzzZValue270()

    squareToSzzZValue271()

    squareToSzzZValue272()

    squareToSzzZValue273()

    squareToSzzZValue274()

    squareToSzzZValue275()

    squareToSzzZValue276()

    squareToSzzZValue277()

    squareToSzzZValue278()

    squareToSzzZValue279()

    squareToSzzZValue280()

    squareToSzzZValue281()

    squareToSzzZValue282()

    squareToSzzZValue283()

    squareToSzzZValue284()

    squareToSzzZValue285()

    squareToSzzZValue286()

    squareToSzzZValue287()

    squareToSzzZValue288()

    squareToSzzZValue289()

    squareToSzzZValue290()

    squareToSzzZValue291()

    squareToSzzZValue292()

    squareToSzzZValue293()

    squareToSzzZValue294()

    squareToSzzZValue295()

    squareToSzzZValue296()

    squareToSzzZValue297()

    squareToSzzZValue298()

    squareToSzzZValue299()

    squareToSzzZValue300()

    squareToSzzZValue301()

    squareToSzzZValue302()

    squareToSzzZValue303()

    squareToSzzZValue304()

    squareToSzzZValue305()

    squareToSzzZValue306()

    squareToSzzZValue307()

    squareToSzzZValue308()

    squareToSzzZValue309()

    squareToSzzZValue310()

    squareToSzzZValue311()

    squareToSzzZValue312()

    squareToSzzZValue313()

    squareToSzzZValue314()

    squareToSzzZValue315()

    squareToSzzZValue316()

    squareToSzzZValue317()

    squareToSzzZValue318()

    squareToSzzZValue319()

    squareToSzzZValue320()

    squareToSzzZValue321()

    squareToSzzZValue322()

    squareToSzzZValue323()

    squareToSzzZValue324()

    squareToSzzZValue325()

    squareToSzzZValue326()

    squareToSzzZValue327()

    squareToSzzZValue328()

    squareToSzzZValue329()

    squareToSzzZValue330()

    squareToSzzZValue331()

    squareToSzzZValue332()

    squareToSzzZValue333()

    squareToSzzZValue334()

    squareToSzzZValue335()

    squareToSzzZValue336()

    squareToSzzZValue337()

    squareToSzzZValue338()

    squareToSzzZValue339()

    squareToSzzZValue340()

    squareToSzzZValue341()

    squareToSzzZValue342()

    squareToSzzZValue343()

    squareToSzzZValue344()

    squareToSzzZValue345()

    squareToSzzZValue346()

    squareToSzzZValue347()

    squareToSzzZValue348()

    squareToSzzZValue349()

    squareToSzzZValue350()

    squareToSzzZValue351()

    squareToSzzZValue352()

    squareToSzzZValue353()

    squareToSzzZValue354()

    squareToSzzZValue355()

    squareToSzzZValue356()

    squareToSzzZValue357()

    squareToSzzZValue358()

    squareToSzzZValue359()

    squareToSzzZValue360()

    squareToSzzZValue361()

    squareToSzzZValue362()

    squareToSzzZValue363()

    squareToSzzZValue364()

    squareToSzzZValue365()

    squareToSzzZValue366()

    squareToSzzZValue367()

    squareToSzzZValue368()

    squareToSzzZValue369()

    squareToSzzZValue370()

    squareToSzzZValue371()

    squareToSzzZValue372()

    squareToSzzZValue373()

    squareToSzzZValue374()

    squareToSzzZValue375()

    squareToSzzZValue376()

    squareToSzzZValue377()

    squareToSzzZValue378()

    squareToSzzZValue379()

    squareToSzzZValue380()

    squareToSzzZValue381()

    squareToSzzZValue382()

    squareToSzzZValue383()

    squareToSzzZValue384()

    squareToSzzZValue385()

    squareToSzzZValue386()

    squareToSzzZValue387()

    squareToSzzZValue388()

    squareToSzzZValue389()

    squareToSzzZValue390()

    squareToSzzZValue391()

    squareToSzzZValue392()

    squareToSzzZValue393()

    squareToSzzZValue394()

    squareToSzzZValue395()

    squareToSzzZValue396()

    squareToSzzZValue397()

    squareToSzzZValue398()

    squareToSzzZValue399()

    squareToSzzZValue400()

    squareToSzzZValue401()

    squareToSzzZValue402()

    squareToSzzZValue403()

    squareToSzzZValue404()

    squareToSzzZValue405()

    squareToSzzZValue406()

    squareToSzzZValue407()

    squareToSzzZValue408()

    squareToSzzZValue409()

    squareToSzzZValue410()

    squareToSzzZValue411()

    squareToSzzZValue412()

    squareToSzzZValue413()

    squareToSzzZValue414()

    squareToSzzZValue415()

    squareToSzzZValue416()

    squareToSzzZValue417()

    squareToSzzZValue418()

    squareToSzzZValue419()

    squareToSzzZValue420()

    squareToSzzZValue421()

    squareToSzzZValue422()

    squareToSzzZValue423()

    squareToSzzZValue424()

    squareToSzzZValue425()

    squareToSzzZValue426()

    squareToSzzZValue427()

    squareToSzzZValue428()

    squareToSzzZValue429()

    squareToSzzZValue430()

    squareToSzzZValue431()

    squareToSzzZValue432()

    squareToSzzZValue433()

    squareToSzzZValue434()

    squareToSzzZValue435()

    squareToSzzZValue436()

    squareToSzzZValue437()

    squareToSzzZValue438()

    squareToSzzZValue439()

    squareToSzzZValue440()

    squareToSzzZValue441()

    squareToSzzZValue442()

    squareToSzzZValue443()

    squareToSzzZValue444()

    squareToSzzZValue445()

    squareToSzzZValue446()

    squareToSzzZValue447()

    squareToSzzZValue448()

    squareToSzzZValue449()

    squareToSzzZValue450()

    squareToSzzZValue451()

    squareToSzzZValue452()

    squareToSzzZValue453()

    squareToSzzZValue454()

    squareToSzzZValue455()

    squareToSzzZValue456()

    squareToSzzZValue457()

    squareToSzzZValue458()

    squareToSzzZValue459()

    squareToSzzZValue460()

    squareToSzzZValue461()

    squareToSzzZValue462()

    squareToSzzZValue463()

    squareToSzzZValue464()

    squareToSzzZValue465()

    squareToSzzZValue466()

    squareToSzzZValue467()

    squareToSzzZValue468()

    squareToSzzZValue469()

    squareToSzzZValue470()

    squareToSzzZValue471()

    squareToSzzZValue472()

    squareToSzzZValue473()

    squareToSzzZValue474()

    squareToSzzZValue475()

    squareToSzzZValue476()

    squareToSzzZValue477()

    squareToSzzZValue478()

    squareToSzzZValue479()

    squareToSzzZValue480()

    squareToSzzZValue481()

    squareToSzzZValue482()

    squareToSzzZValue483()

    squareToSzzZValue484()

    squareToSzzZValue485()

    squareToSzzZValue486()

    squareToSzzZValue487()

    squareToSzzZValue488()

    squareToSzzZValue489()

    squareToSzzZValue490()

    squareToSzzZValue491()

    squareToSzzZValue492()

    squareToSzzZValue493()

    squareToSzzZValue494()

    squareToSzzZValue495()

    squareToSzzZValue496()

    squareToSzzZValue497()

    squareToSzzZValue498()

    squareToSzzZValue499()

    squareToSzzZValue500()

    squareToSzzZValue501()

    squareToSzzZValue502()

    squareToSzzZValue503()

    squareToSzzZValue504()

    squareToSzzZValue505()

    squareToSzzZValue506()

    squareToSzzZValue507()

    squareToSzzZValue508()

    squareToSzzZValue509()

    squareToSzzZValue510()

    squareToSzzZValue511()

    squareToSzzZValue512()

    squareToSzzZValue513()

    squareToSzzZValue514()

    squareToSzzZValue515()

    squareToSzzZValue516()

    squareToSzzZValue517()

    squareToSzzZValue518()

    squareToSzzZValue519()

    squareToSzzZValue520()

    squareToSzzZValue521()

    squareToSzzZValue522()

    squareToSzzZValue523()

    squareToSzzZValue524()

    squareToSzzZValue525()

    squareToSzzZValue526()

    squareToSzzZValue527()

    squareToSzzZValue528()

    squareToSzzZValue529()

    squareToSzzZValue530()

    squareToSzzZValue531()

    squareToSzzZValue532()

    squareToSzzZValue533()

    squareToSzzZValue534()

    squareToSzzZValue535()

    squareToSzzZValue536()

    squareToSzzZValue537()

    squareToSzzZValue538()

    squareToSzzZValue539()

    squareToSzzZValue540()

    squareToSzzZValue541()

    squareToSzzZValue542()

    squareToSzzZValue543()

    squareToSzzZValue544()

    squareToSzzZValue545()

    squareToSzzZValue546()

    squareToSzzZValue547()

    squareToSzzZValue548()

    squareToSzzZValue549()

    squareToSzzZValue550()

    squareToSzzZValue551()

    squareToSzzZValue552()

    squareToSzzZValue553()

    squareToSzzZValue554()

    squareToSzzZValue555()

    squareToSzzZValue556()

    squareToSzzZValue557()

    squareToSzzZValue558()

    squareToSzzZValue559()

    squareToSzzZValue560()

    squareToSzzZValue561()

    squareToSzzZValue562()

    squareToSzzZValue563()

    squareToSzzZValue564()

    squareToSzzZValue565()

    squareToSzzZValue566()

    squareToSzzZValue567()

    squareToSzzZValue568()

    squareToSzzZValue569()

    squareToSzzZValue570()

    squareToSzzZValue571()

    squareToSzzZValue572()

    squareToSzzZValue573()

    squareToSzzZValue574()

    squareToSzzZValue575()

    squareToSzzZValue576()

    squareToSzzZValue577()

    squareToSzzZValue578()

    squareToSzzZValue579()

    squareToSzzZValue580()

    squareToSzzZValue581()

    squareToSzzZValue582()

    squareToSzzZValue583()

    squareToSzzZValue584()

    squareToSzzZValue585()

    squareToSzzZValue586()

    squareToSzzZValue587()

    squareToSzzZValue588()

    squareToSzzZValue589()

    squareToSzzZValue590()

    squareToSzzZValue591()

    squareToSzzZValue592()

    squareToSzzZValue593()

    squareToSzzZValue594()

    squareToSzzZValue595()

    squareToSzzZValue596()

    squareToSzzZValue597()

    squareToSzzZValue598()

    squareToSzzZValue599()

    squareToSzzZValue600()

    squareToSzzZValue601()

    squareToSzzZValue602()

    squareToSzzZValue603()

    squareToSzzZValue604()

    squareToSzzZValue605()

    squareToSzzZValue606()

    squareToSzzZValue607()

    squareToSzzZValue608()

    squareToSzzZValue609()

    squareToSzzZValue610()

    squareToSzzZValue611()

    squareToSzzZValue612()

    squareToSzzZValue613()

    squareToSzzZValue614()

    squareToSzzZValue615()

    squareToSzzZValue616()

    squareToSzzZValue617()

    squareToSzzZValue618()

    squareToSzzZValue619()

    squareToSzzZValue620()

    squareToSzzZValue621()

    squareToSzzZValue622()

    squareToSzzZValue623()

    squareToSzzZValue624()

    squareToSzzZValue625()

    alert("Your art has been loaded successfully from your browser's local browser storage.");

};

function squareNull(){
    valueSave = 'zSqrArtSpecz0';
    var tripleZeroA = localStorage.getItem(valueSave);
    if(tripleZeroA == null){
        setAThis();
    }else{
        getBThis();
    };
};