@echo off
setlocal
cd /d "%~dp0"
if not exist "WritersJumbler\index.html" (
  echo WritersJumbler\index.html is missing.
  echo Run setup_offline.bat first.
  pause
  exit /b 1
)
py -m pip install -r requirements.txt
if errorlevel 1 goto :failed
py "%~dp0writers_jumbler_offline_viewer_function_buttons_v2_repeat_fixed.py"
if errorlevel 1 goto :failed
exit /b 0
:failed
echo.
echo Viewer error. Copy all text shown above.
pause
exit /b 1
