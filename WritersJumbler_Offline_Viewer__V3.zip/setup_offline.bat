@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "DEST=%~dp0WritersJumbler"
if exist "%DEST%" rmdir /s /q "%DEST%"
mkdir "%DEST%"
if errorlevel 1 goto :failed
for %%Z in (WJpart1.zip WJpart2.zip WJpart3.zip WJpart4.zip WJpart5.zip) do (
  if not exist "%%Z" (
    echo [ERROR] Missing %%Z
    goto :failed
  )
  echo Extracting %%Z...
  tar -xf "%%Z" -C "%DEST%"
  if errorlevel 1 goto :failed
)
if not exist "%DEST%\index.html" (
  echo [WARNING] WritersJumbler\index.html was not found.
)
echo Offline WritersJumbler assembled in "%DEST%"
pause
exit /b 0
:failed
echo Setup failed.
pause
exit /b 1
