import json
import sys
import time
from pathlib import Path

from PIL import Image

from PySide6.QtCore import QElapsedTimer, QRect, Qt, QTimer, QUrl
from PySide6.QtGui import QGuiApplication, QPainter, QPixmap
from PySide6.QtWidgets import (
    QApplication, QComboBox, QDoubleSpinBox, QFileDialog, QHBoxLayout,
    QLabel, QMainWindow, QMessageBox, QProgressBar, QPushButton,
    QRubberBand, QSpinBox, QVBoxLayout, QWidget,
)
from PySide6.QtWebEngineCore import QWebEngineScript
from PySide6.QtWebEngineWidgets import QWebEngineView


# =====================================================================
# PATHS
# =====================================================================

ROOT = Path(__file__).resolve().parent
OFFLINE_ROOT = ROOT / "WritersJumbler"
OFFLINE_INDEX = OFFLINE_ROOT / "index.html"
HOME = QUrl.fromLocalFile(str(OFFLINE_INDEX))

DATA_ROOT = Path.home() / ".writers_jumbler_viewer"
SESSIONS = DATA_ROOT / "sessions"
SESSIONS.mkdir(parents=True, exist_ok=True)

BOTTOM_JS = r"""
window.scrollTo(
    0,
    Math.max(
        document.body?.scrollHeight || 0,
        document.documentElement?.scrollHeight || 0
    )
);
"""


# =====================================================================
# SCREENSHOT OVERLAY
# =====================================================================

class ScreenshotOverlay(QWidget):
    def __init__(self):
        flags = (
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool
        )
        super().__init__(None, flags)

        screens = QGuiApplication.screens()
        if not screens:
            self.close()
            return

        geometry = screens[0].geometry()
        for screen in screens[1:]:
            geometry = geometry.united(screen.geometry())

        self.desktop = QPixmap(geometry.size())
        self.desktop.fill(Qt.GlobalColor.black)

        painter = QPainter(self.desktop)
        for screen in screens:
            offset = screen.geometry().topLeft() - geometry.topLeft()
            painter.drawPixmap(offset, screen.grabWindow(0))
        painter.end()

        self.setGeometry(geometry)
        self.setWindowOpacity(0.28)
        self.setStyleSheet("background: black;")

        self.rubber = QRubberBand(QRubberBand.Shape.Rectangle, self)
        self.origin = None

    def mousePressEvent(self, event):
        self.origin = event.position().toPoint()
        self.rubber.setGeometry(QRect(self.origin, self.origin))
        self.rubber.show()

    def mouseMoveEvent(self, event):
        if self.origin is None:
            return
        rectangle = QRect(self.origin, event.position().toPoint()).normalized()
        self.rubber.setGeometry(rectangle)

    def mouseReleaseEvent(self, event):
        if self.origin is None:
            return

        rectangle = QRect(self.origin, event.position().toPoint()).normalized()
        self.hide()

        if rectangle.width() > 2 and rectangle.height() > 2:
            path, _ = QFileDialog.getSaveFileName(
                self,
                "Save screenshot",
                "screenshot.png",
                "PNG (*.png);;JPEG (*.jpg *.jpeg)",
            )
            if path:
                self.desktop.copy(rectangle).save(path)

        self.close()

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Escape:
            self.close()
            return
        super().keyPressEvent(event)


# =====================================================================
# MAIN WINDOW
# =====================================================================

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("WritersJumbler.com Offline Viewer")
        self.resize(1380, 900)

        # Session
        self.session = SESSIONS / time.strftime("%Y%m%d-%H%M%S")
        self.session.mkdir(parents=True, exist_ok=True)
        self.manifest = self.session / "recording.json"
        self.write_records([])

        # Recording state
        self.recording = False
        self.record_interval_ms = 100
        self.capture_target = 0
        self.capture_done = 0

        # Existing autoA/autoB state
        self.button_running = False
        self.button_remaining = 0
        self.button_delay_ms = 250
        self.button_requested = 0
        self.button_completed = 0
        self.active_page_function = ""
        self.button_clock = QElapsedTimer()

        # New offline animation state
        self.animation_running = False
        self.animation_direction = ""
        self.animation_set_size = 0
        self.animation_position = 0
        self.animation_completed = 0
        self.animation_buttons = []

        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)

        # Navigation
        nav = QHBoxLayout()
        layout.addLayout(nav)
        navigation_buttons = [
            ("Home", self.home),
            ("Back", self.back),
            ("Forward", self.forward),
            ("Refresh", self.refresh_page),
            ("Stop Page", self.stop_page),
            ("Go Top", self.go_top),
            ("Go Bottom", self.go_bottom),
            ("Zoom Out", self.zoom_out),
            ("Zoom Reset", self.zoom_reset),
            ("Screenshot", self.screenshot),
        ]
        for text, callback in navigation_buttons:
            button = QPushButton(text)
            button.clicked.connect(callback)
            nav.addWidget(button)

        # Recording controls
        record = QHBoxLayout()
        layout.addLayout(record)
        record.addWidget(QLabel("Frames:"))

        self.frame_count = QSpinBox()
        self.frame_count.setRange(1, 100000)
        self.frame_count.setValue(100)
        record.addWidget(self.frame_count)

        record.addWidget(QLabel("Every:"))
        self.interval = QDoubleSpinBox()
        self.interval.setRange(1, 3600000)
        self.interval.setDecimals(0)
        self.interval.setValue(100)
        record.addWidget(self.interval)

        self.interval_unit = QComboBox()
        self.interval_unit.addItems(["milliseconds", "seconds"])
        record.addWidget(self.interval_unit)

        self.start_record_button = QPushButton("Start Recording")
        self.start_record_button.clicked.connect(self.start_recording)
        record.addWidget(self.start_record_button)

        self.stop_record_button = QPushButton("Stop Recording")
        self.stop_record_button.clicked.connect(lambda: self.stop_recording(False))
        self.stop_record_button.setEnabled(False)
        record.addWidget(self.stop_record_button)

        self.save_gif_button = QPushButton("Save GIF")
        self.save_gif_button.clicked.connect(self.save_gif)
        self.save_gif_button.setEnabled(False)
        record.addWidget(self.save_gif_button)

        self.gif_progress = QProgressBar()
        self.gif_progress.setRange(0, 100)
        self.gif_progress.setVisible(False)
        record.addWidget(self.gif_progress)

        # Repeat controls
        repeat = QHBoxLayout()
        layout.addLayout(repeat)
        repeat.addWidget(QLabel("Function button repeats:"))

        self.auto_count = QSpinBox()
        self.auto_count.setRange(1, 100000)
        self.auto_count.setValue(1)
        repeat.addWidget(self.auto_count)

        repeat.addWidget(QLabel("Delay ms:"))
        self.auto_delay = QSpinBox()
        self.auto_delay.setRange(1, 600000)
        self.auto_delay.setValue(250)
        repeat.addWidget(self.auto_delay)

        self.stop_auto_button = QPushButton("Stop Function")
        self.stop_auto_button.clicked.connect(self.stop_all_sequences)
        self.stop_auto_button.setEnabled(False)
        repeat.addWidget(self.stop_auto_button)

        self.press_counter = QLabel("Pressed: 0 / 0")
        repeat.addWidget(self.press_counter)
        repeat.addStretch(1)

        # Existing New/Erase plus six new animation buttons
        functions = QHBoxLayout()
        layout.addLayout(functions)
        functions.addWidget(QLabel("Page commands:"))

        self.auto_a_button = QPushButton("New")
        self.auto_a_button.setToolTip('Run commands attached to id="autoA"')
        self.auto_a_button.clicked.connect(lambda: self.start_page_function("autoA"))
        functions.addWidget(self.auto_a_button)

        self.auto_b_button = QPushButton("Erase")
        self.auto_b_button.setToolTip('Run commands attached to id="autoB"')
        self.auto_b_button.clicked.connect(lambda: self.start_page_function("autoB"))
        functions.addWidget(self.auto_b_button)

        animation_specs = [
            ("X 20", "X", 20), ("Y 20", "Y", 20),
            ("X 25", "X", 25), ("Y 25", "Y", 25),
            ("X 30", "X", 30), ("Y 30", "Y", 30),
        ]
        for label, direction, count in animation_specs:
            button = QPushButton(label)
            prefix = "scO" if direction == "X" else "ssO"
            button.setToolTip(
                f"Run the {count}-button {direction} animation set ({prefix} functions)"
            )
            button.clicked.connect(
                lambda checked=False, d=direction, c=count:
                self.start_animation_sequence(d, c)
            )
            functions.addWidget(button)
            self.animation_buttons.append(button)

        functions.addStretch(1)

        self.status = QLabel("Ready")
        layout.addWidget(self.status)

        # Timers
        self.record_timer = QTimer(self)
        self.record_timer.setTimerType(Qt.TimerType.PreciseTimer)
        self.record_timer.timeout.connect(self.capture_frame)

        self.auto_timer = QTimer(self)
        self.auto_timer.setSingleShot(True)
        self.auto_timer.setTimerType(Qt.TimerType.PreciseTimer)
        self.auto_timer.timeout.connect(self.press_once)

        self.animation_timer = QTimer(self)
        self.animation_timer.setSingleShot(True)
        self.animation_timer.setTimerType(Qt.TimerType.PreciseTimer)
        self.animation_timer.timeout.connect(self.animation_press_once)

        # Web engine
        self.view = QWebEngineView()
        layout.addWidget(self.view, 1)
        self.view.loadFinished.connect(self.page_loaded)
        self.view.setUrl(HOME)

        if not OFFLINE_INDEX.exists():
            QTimer.singleShot(
                0,
                lambda: QMessageBox.critical(
                    self,
                    "Offline files missing",
                    "WritersJumbler\\index.html is missing. Run setup_offline.bat first.",
                ),
            )

    # Recording manifest
    def records(self):
        try:
            data = json.loads(self.manifest.read_text(encoding="utf-8"))
            return data if isinstance(data, list) else []
        except Exception:
            return []

    def write_records(self, records):
        self.manifest.write_text(
            json.dumps(records, indent=2),
            encoding="utf-8",
        )

    def clear_frames(self):
        for record in self.records():
            try:
                file_name = record.get("file")
                if file_name:
                    Path(file_name).unlink(missing_ok=True)
            except Exception:
                pass
        self.write_records([])

    # Recording
    def start_recording(self):
        if self.recording:
            return

        self.clear_frames()
        self.capture_target = self.frame_count.value()
        self.capture_done = 0
        value = float(self.interval.value())
        if self.interval_unit.currentText() == "seconds":
            value *= 1000
        self.record_interval_ms = max(1, int(value))

        self.recording = True
        self.start_record_button.setEnabled(False)
        self.stop_record_button.setEnabled(True)
        self.save_gif_button.setEnabled(False)
        self.capture_frame()
        if self.recording:
            self.record_timer.start(self.record_interval_ms)

    def capture_frame(self):
        if not self.recording:
            return

        pixmap = self.view.grab()
        if not pixmap.isNull():
            records = self.records()
            path = self.session / f"{len(records) + 1:06d}.png"
            if pixmap.save(str(path), "PNG"):
                records.append({
                    "file": str(path),
                    "interval_ms": self.record_interval_ms,
                })
                self.write_records(records)
                self.capture_done += 1

        self.status.setText(
            f"Recording {self.capture_done}/{self.capture_target}"
        )
        if self.capture_done >= self.capture_target:
            self.stop_recording(True)

    def stop_recording(self, completed=False):
        self.record_timer.stop()
        self.recording = False
        self.start_record_button.setEnabled(True)
        self.stop_record_button.setEnabled(False)
        self.save_gif_button.setEnabled(bool(self.records()))
        label = "Recording complete" if completed else "Recording stopped"
        self.status.setText(f"{label}: {self.capture_done} frames")

    # GIF creation
    def save_gif(self):
        records = self.records()
        if not records:
            return

        path, _ = QFileDialog.getSaveFileName(
            self,
            "Save GIF",
            "writers-jumbler-recording.gif",
            "GIF (*.gif)",
        )
        if not path:
            return

        self.gif_progress.setVisible(True)
        self.gif_progress.setValue(0)
        self.save_gif_button.setEnabled(False)
        frames = []

        for index, record in enumerate(records, 1):
            try:
                with Image.open(record["file"]) as image:
                    converted = image.convert(
                        "P",
                        palette=Image.Palette.ADAPTIVE,
                    )
                    frames.append(converted.copy())
            except Exception:
                pass

            self.gif_progress.setValue(int(index / len(records) * 90))
            QApplication.processEvents()

        if frames:
            duration = int(records[0].get("interval_ms", self.record_interval_ms))
            self.gif_progress.setValue(95)
            QApplication.processEvents()
            try:
                frames[0].save(
                    path,
                    save_all=True,
                    append_images=frames[1:],
                    duration=duration,
                    loop=0,
                    optimize=True,
                )
                self.gif_progress.setValue(100)
                self.status.setText(f"GIF saved: {duration} ms/frame")
            except Exception as error:
                QMessageBox.critical(self, "GIF save failed", str(error))
                self.status.setText("GIF save failed")
        else:
            QMessageBox.warning(
                self,
                "No frames",
                "No valid frames could be loaded.",
            )
            self.status.setText("No valid GIF frames found")

        self.save_gif_button.setEnabled(True)
        QTimer.singleShot(1200, lambda: self.gif_progress.setVisible(False))

    # Shared sequence controls
    def set_animation_buttons_enabled(self, enabled):
        for button in self.animation_buttons:
            button.setEnabled(enabled)

    def set_command_buttons_enabled(self, enabled):
        self.auto_a_button.setEnabled(enabled)
        self.auto_b_button.setEnabled(enabled)
        self.set_animation_buttons_enabled(enabled)

    def stop_all_sequences(self):
        if self.animation_running:
            self.stop_animation_sequence(False)
        elif self.button_running:
            self.stop_auto_button_sequence(False)

    # New six-button offline animation system
    def start_animation_sequence(self, direction, set_size):
        if self.button_running:
            self.stop_auto_button_sequence(False)
        if self.animation_running:
            self.stop_animation_sequence(False)

        self.animation_direction = direction
        self.animation_set_size = set_size
        self.animation_position = 0
        self.animation_completed = 0
        self.button_delay_ms = self.auto_delay.value()
        self.animation_running = True

        self.set_command_buttons_enabled(False)
        self.stop_auto_button.setEnabled(True)
        self.press_counter.setText(f"Animation: 0 / {set_size}")
        self.status.setText(
            f"{direction} {set_size}: finding the matching offline animation set..."
        )
        self.animation_press_once()

    def animation_press_once(self):
        if not self.animation_running:
            return
        if self.animation_position >= self.animation_set_size:
            self.stop_animation_sequence(True)
            return

        script = r"""
((direction, setSize, position) => {
    try {
        const prefix = direction === 'Y' ? 'ssO' : 'scO';
        const all = Array.from(document.querySelectorAll('button'));
        const candidates = all.filter(button => {
            const handler = String(button.getAttribute('onclick') || '').trim();
            return handler.startsWith(prefix);
        });

        /*
         * Split matching buttons into animation sets. A new set begins
         * whenever its visible number returns to 00 or decreases.
         * This lets pages contain separate 20, 25 and 30 button sets.
         */
        const groups = [];
        let group = [];
        let previousNumber = -1;

        for (const button of candidates) {
            const text = String(button.textContent || '').trim();
            const number = /^\d+$/.test(text) ? Number(text) : group.length;

            if (group.length && (number === 0 || number <= previousNumber)) {
                groups.push(group);
                group = [];
            }

            group.push(button);
            previousNumber = number;
        }
        if (group.length) groups.push(group);

        let selected = groups.find(items => items.length === setSize);

        /* Fallback for pages containing only one applicable set. */
        if (!selected && candidates.length === setSize) {
            selected = candidates;
        }

        if (!selected) {
            return JSON.stringify({
                ok: false,
                reason:
                    'Could not find a separate ' + direction + ' set with ' +
                    setSize + ' buttons. Detected set sizes: ' +
                    (groups.map(items => items.length).join(', ') || 'none'),
                detectedSetSizes: groups.map(items => items.length)
            });
        }

        if (position < 0 || position >= selected.length) {
            return JSON.stringify({
                ok: false,
                reason: 'Animation position is outside the selected set.'
            });
        }

        const button = selected[position];
        const functionText = String(button.getAttribute('onclick') || '').trim();
        const buttonText = String(button.textContent || '').trim();

        if (typeof button.click !== 'function') {
            return JSON.stringify({
                ok: false,
                reason: 'Selected animation button cannot be clicked.'
            });
        }

        button.click();

        return JSON.stringify({
            ok: true,
            direction: direction,
            selectedSetSize: selected.length,
            position: position,
            buttonText: buttonText,
            functionText: functionText
        });
    } catch (error) {
        return JSON.stringify({
            ok: false,
            reason: String(error && error.message ? error.message : error)
        });
    }
})(%s, %d, %d)
""" % (
            json.dumps(self.animation_direction),
            self.animation_set_size,
            self.animation_position,
        )

        self.view.page().runJavaScript(
            script,
            QWebEngineScript.ScriptWorldId.MainWorld,
            self.animation_press_result,
        )

    def animation_press_result(self, result):
        if not self.animation_running:
            return

        try:
            data = result if isinstance(result, dict) else json.loads(result)
            if not isinstance(data, dict):
                raise ValueError("Animation result is not an object")
        except Exception as error:
            print("ANIMATION RESULT ERROR:", error, "RAW:", repr(result))
            self.stop_animation_sequence(
                False,
                "Animation JavaScript error. See console.",
            )
            return

        if not data.get("ok"):
            reason = str(data.get("reason", "Animation button failed"))
            print("ANIMATION BUTTON ERROR:", reason, data)
            self.stop_animation_sequence(False, reason)
            return

        button_text = str(data.get("buttonText", self.animation_position))
        function_text = str(data.get("functionText", ""))
        self.animation_completed += 1
        self.animation_position += 1

        print(
            f"Animation {self.animation_direction} {self.animation_set_size}: "
            f"button {button_text!r}, function {function_text!r}"
        )

        self.press_counter.setText(
            f"Animation: {self.animation_completed} / {self.animation_set_size}"
        )
        self.status.setText(
            f"{self.animation_direction} {self.animation_set_size}: "
            f"button {button_text}, "
            f"{self.animation_completed}/{self.animation_set_size}"
        )

        if self.animation_position < self.animation_set_size:
            self.animation_timer.start(self.button_delay_ms)
        else:
            self.stop_animation_sequence(True)

    def stop_animation_sequence(self, completed=False, status_override=None):
        self.animation_timer.stop()
        was_running = self.animation_running
        self.animation_running = False
        self.set_command_buttons_enabled(True)
        self.stop_auto_button.setEnabled(False)

        if status_override:
            self.status.setText(status_override)
            return
        if not was_running:
            return

        state = "complete" if completed else "stopped"
        self.status.setText(
            f"{self.animation_direction} {self.animation_set_size} {state}: "
            f"{self.animation_completed}/{self.animation_set_size}"
        )

    # Existing autoA/autoB system
    def start_page_function(self, element_id):
        if self.animation_running:
            self.stop_animation_sequence(False)
        if self.button_running:
            self.stop_auto_button_sequence(False)

        self.active_page_function = element_id
        self.button_requested = self.auto_count.value()
        self.button_completed = 0
        self.button_remaining = self.button_requested
        self.button_delay_ms = self.auto_delay.value()
        self.button_running = True
        self.button_clock.start()

        self.press_counter.setText(f"Pressed: 0 / {self.button_requested}")
        self.stop_auto_button.setEnabled(True)
        self.set_command_buttons_enabled(False)
        self.status.setText(f"{self.active_page_function}: starting...")
        self.press_once()

    def press_once(self, target_id=None):
        if not self.button_running:
            return
        if target_id is not None:
            self.active_page_function = target_id
        if self.button_remaining <= 0:
            self.stop_auto_button_sequence(True)
            return

        element_id = self.active_page_function
        script = r"""
((wantedId) => {
    try {
        const allIdElements = Array.from(document.querySelectorAll('[id]'));
        const allIds = allIdElements.map(element => element.id);
        const elements = allIdElements.filter(element => element.id === wantedId);

        if (elements.length === 0) {
            return JSON.stringify({
                ok: false,
                reason: 'id="' + wantedId + '" was not found.',
                allIds: allIds
            });
        }

        let executed = 0;
        let skipped = 0;
        const executedElements = [];

        for (let index = 0; index < elements.length; index++) {
            const element = elements[index];
            try {
                if (typeof element.click === 'function') {
                    element.click();
                    executed++;
                    executedElements.push({
                        index: index,
                        tagName: String(element.tagName || ''),
                        onclick: String(element.getAttribute('onclick') || '')
                    });
                } else {
                    skipped++;
                }
            } catch (elementError) {
                skipped++;
                console.error('Error executing id="' + wantedId + '":', elementError);
            }
        }

        return JSON.stringify({
            ok: executed > 0,
            id: wantedId,
            totalIdsFound: allIds.length,
            allIds: allIds,
            matched: elements.length,
            executed: executed,
            skipped: skipped,
            executedElements: executedElements,
            reason: executed > 0 ? '' : 'No matching elements could be executed'
        });
    } catch (error) {
        return JSON.stringify({
            ok: false,
            reason: String(error && error.message ? error.message : error)
        });
    }
})(%s)
""" % json.dumps(element_id)

        self.view.page().runJavaScript(
            script,
            QWebEngineScript.ScriptWorldId.MainWorld,
            self.press_result,
        )

    def press_result(self, result):
        if not self.button_running:
            return

        try:
            data = result if isinstance(result, dict) else json.loads(result)
            if not isinstance(data, dict):
                raise ValueError("JavaScript result is not an object")
        except Exception as error:
            print("JAVASCRIPT RESULT ERROR:", error, "RAW:", repr(result))
            self.stop_auto_button_sequence(
                False,
                "JavaScript error. See console.",
            )
            return

        all_ids = data.get("allIds", [])
        print("=" * 70)
        print("ALL IDs FOUND IN PAGE")
        for index, item_id in enumerate(all_ids, 1):
            marker = "  <-- TARGET" if item_id == self.active_page_function else ""
            print(f"{index:5d}: {item_id!r}{marker}")
        print("=" * 70)

        if not data.get("ok"):
            reason = str(data.get("reason", "Page command failed"))
            print("PAGE COMMAND ERROR:", reason, data)
            self.stop_auto_button_sequence(
                False,
                "Page command failed. See console.",
            )
            return

        self.button_completed += 1
        self.button_remaining = self.button_requested - self.button_completed
        executed = data.get("executed", 0)

        self.press_counter.setText(
            f"Pressed: {self.button_completed} / {self.button_requested}"
        )
        self.status.setText(
            f"{self.active_page_function}: {executed} executed, repeat "
            f"{self.button_completed}/{self.button_requested}"
        )

        if self.button_remaining > 0:
            self.auto_timer.start(self.button_delay_ms)
        else:
            self.stop_auto_button_sequence(True)

    def stop_auto_button_sequence(
        self,
        completed=False,
        status_override=None,
    ):
        self.auto_timer.stop()
        was_running = self.button_running
        self.button_running = False
        self.stop_auto_button.setEnabled(False)
        self.set_command_buttons_enabled(True)

        if status_override:
            self.status.setText(status_override)
            return
        if not was_running and not self.button_requested:
            return

        if completed:
            self.status.setText(
                f"{self.active_page_function} complete: "
                f"{self.button_completed}/{self.button_requested} confirmed executions"
            )
        elif self.button_requested:
            self.status.setText(
                f"{self.active_page_function} stopped: "
                f"{self.button_completed}/{self.button_requested} confirmed executions"
            )

    # Page loading
    def page_loaded(self, ok):
        if not ok:
            self.status.setText("Page failed to load")
            return

        url = self.view.url()
        local_path = None
        if url.isLocalFile():
            try:
                local_path = Path(url.toLocalFile()).resolve()
            except Exception:
                local_path = None

        if OFFLINE_INDEX.exists():
            try:
                offline_root = OFFLINE_ROOT.resolve()
                inside_offline_root = (
                    local_path is not None
                    and (
                        local_path == offline_root
                        or offline_root in local_path.parents
                    )
                )
                if not inside_offline_root:
                    self.view.setUrl(HOME)
                    return
            except Exception:
                pass

        self.status.setText("Page loaded")

    # Navigation
    def stop_running_sequences(self):
        if self.animation_running:
            self.stop_animation_sequence(False)
        if self.button_running:
            self.stop_auto_button_sequence(False)

    def home(self):
        self.stop_running_sequences()
        self.view.setUrl(HOME)

    def back(self):
        self.stop_running_sequences()
        self.view.back()

    def forward(self):
        self.stop_running_sequences()
        self.view.forward()

    def refresh_page(self):
        self.stop_running_sequences()
        self.view.reload()

    def stop_page(self):
        self.view.stop()

    # Scroll
    def go_top(self):
        self.view.page().runJavaScript(
            "window.scrollTo(0, 0);",
            QWebEngineScript.ScriptWorldId.MainWorld,
        )

    def go_bottom(self):
        self.view.page().runJavaScript(
            BOTTOM_JS,
            QWebEngineScript.ScriptWorldId.MainWorld,
        )

    # Zoom
    def zoom_out(self):
        zoom = max(0.25, round(self.view.zoomFactor() - 0.10, 2))
        self.view.setZoomFactor(zoom)
        self.status.setText(f"Zoom: {int(round(zoom * 100))}%")

    def zoom_reset(self):
        self.view.setZoomFactor(1.0)
        self.status.setText("Zoom: 100%")

    # Screenshot
    def screenshot(self):
        self.overlay = ScreenshotOverlay()
        self.overlay.show()
        self.overlay.activateWindow()
        self.overlay.raise_()

    # Close
    def closeEvent(self, event):
        self.record_timer.stop()
        self.auto_timer.stop()
        self.animation_timer.stop()
        self.recording = False
        self.button_running = False
        self.animation_running = False
        event.accept()


# =====================================================================
# START
# =====================================================================

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
