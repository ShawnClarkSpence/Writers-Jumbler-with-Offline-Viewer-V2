Writers Jumbler Offline Viewer - Function Buttons v2 Repeat Fixed

Fix for "Page button activation failed":
The repeat timer no longer searches for or clicks an HTML page button after the first AutoA/AutoB selection. The AutoA/AutoB viewer button already supplies the exact function name, so each timer tick calls that selected function directly in the page MainWorld.

Example:
- Repeats = 50
- Delay = 100 ms
- Click AutoA20 once
- AutoA20() is called once immediately, then again after each 100 ms delay until 50 confirmed function calls are completed.

The counter shows Called: 0 / 50 through Called: 50 / 50.

GIF recording/save is independent and unchanged from the existing viewer. The repeat code does not start, stop, or save GIFs. No HTML files are modified.
